/**
 * AEROTWIN AI - Full-Stack Express Server & Gemini API Gateway
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize Gemini client
let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!geminiClient && process.env.GEMINI_API_KEY) {
    geminiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return geminiClient;
}

// 1. API Health
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    system: 'AEROTWIN AI Hybrid Digital Twin',
    geminiConfigured: !!process.env.GEMINI_API_KEY,
    timestamp: Date.now()
  });
});

// 2. AI Diagnostics Endpoint
app.post('/api/ai-diagnostics', async (req, res) => {
  try {
    const { telemetry, physics, detectedFault, confidence, componentHealth } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Return structured fallback response if Gemini key is not set
      return res.json({
        available: false,
        source: 'local_ml_hybrid',
        message: 'Local physics-ML hybrid inference active (GEMINI_API_KEY not configured)'
      });
    }

    const prompt = `You are the chief aerospace propulsion and digital twin AI diagnostics expert for an advanced twin-cylinder UAV 150cc EFI internal combustion engine.
Analyze the following real-time telemetry and physics digital twin data:
- Engine RPM: ${telemetry?.rpm} RPM
- Engine Temperature: ${telemetry?.engineTemp}°C (Expected: ${physics?.expectedEngineTemp}°C, Deviation: ${physics?.tempDeviation}°C)
- Oil Pressure: ${telemetry?.oilPressure} PSI (Expected: ${physics?.expectedOilPressure} PSI, Deviation: ${physics?.pressureDeviation} PSI)
- Oil Temperature: ${telemetry?.oilTemp}°C
- Mechanical Vibration: ${telemetry?.vibration} mm/s RMS (Expected: ${physics?.expectedVibration} mm/s)
- Fuel Flow: ${telemetry?.fuelFlow} L/h (Expected: ${physics?.expectedFuelFlow} L/h)
- Cylinder Head Temperature: ${telemetry?.cylinderHeadTemp}°C
- Exhaust Gas Temperature: ${telemetry?.exhaustGasTemp}°C
- Inferred Fault: ${detectedFault} (${confidence}% confidence)
- Component Health: Overall ${componentHealth?.overallScore}%, Lubrication ${componentHealth?.lubricationSystem?.healthScore}%, Bearings ${componentHealth?.bearingSystem?.healthScore}%, Cylinders ${componentHealth?.cylinderSystem?.healthScore}%

Provide a concise, high-level aerospace technical assessment (max 3 short paragraphs) explaining:
1. Root thermo-mechanical or hydrodynamic cause.
2. Immediate operational risk to UAV airframe/mission.
3. Specific actionable operator and ground maintenance recommendation.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    const aiText = response.text || '';
    return res.json({
      available: true,
      source: 'gemini_2_5_flash',
      diagnosticInsight: aiText,
    });
  } catch (error: any) {
    console.error('Error in Gemini diagnostics:', error);
    res.status(200).json({
      available: false,
      source: 'local_ml_hybrid',
      error: error.message || 'Gemini inference failed; fallback to local model.',
    });
  }
});

// 3. AI Report Executive Summary Endpoint
app.post('/api/ai-report-summary', async (req, res) => {
  try {
    const { missionName, duration, healthEnd, faults, decisionsCount } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        available: false,
        summary: `Mission "${missionName}" completed. Final propulsion health logged at ${healthEnd}%. ${faults?.length ? `Detected fault patterns: ${faults.join(', ')}.` : 'Nominal flight envelope maintained throughout.'}`
      });
    }

    const prompt = `Write a brief, authoritative 2-paragraph Defence/Aerospace UAV Propulsion Digital Twin Executive Summary for Mission "${missionName}".
Details:
- Duration: ${duration} minutes
- Engine Health at Mission End: ${healthEnd}%
- Faults Flagged: ${faults?.join(', ') || 'None'}
- Operator Interventions Logged: ${decisionsCount}
Format as:
1. Operational Summary
2. Airworthiness & Next Maintenance Requirement`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return res.json({
      available: true,
      summary: response.text || '',
    });
  } catch (error: any) {
    return res.status(200).json({
      available: false,
      summary: `Mission "${req.body.missionName}" logged. Final engine health: ${req.body.healthEnd}%.`,
    });
  }
});

// Vite middleware & Static Serving
async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AEROTWIN AI Server running at http://0.0.0.0:${PORT}`);
  });
}

start();
