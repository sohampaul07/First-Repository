/**
 * AEROTWIN AI - Type Definitions
 * Core data models for UAV Engine Hybrid Digital Twin
 */

export type SeverityLevel = 'healthy' | 'monitor' | 'warning' | 'critical';

export interface TelemetryData {
  timestamp: number;
  rpm: number; // RPM (normal: 4000-5800, max: 6800)
  engineTemp: number; // °C (normal: 85-105, critical: >125)
  oilTemp: number; // °C (normal: 75-95, critical: >115)
  oilPressure: number; // PSI (normal: 45-75, critical: <25 or >90)
  vibration: number; // mm/s RMS (normal: 1.2-3.8, critical: >7.5)
  fuelFlow: number; // L/h (normal: 4.5-8.2, critical: >12.0)
  cylinderHeadTemp: number; // CHT °C (normal: 130-175, critical: >210)
  exhaustGasTemp: number; // EGT °C (normal: 650-780, critical: >860)
  throttle: number; // % (0 - 100)
  ambientTemp: number; // °C
  altitude: number; // ft
  manifoldPressure: number; // inHg
}

export interface PhysicsExpectedValues {
  expectedEngineTemp: number;
  expectedOilTemp: number;
  expectedOilPressure: number;
  expectedVibration: number;
  expectedFuelFlow: number;
  expectedCHT: number;
  expectedEGT: number;
  tempDeviation: number;
  pressureDeviation: number;
  vibrationDeviation: number;
  fuelDeviation: number;
  thermalEfficiency: number; // %
  stressFactor: number; // 0 - 1
}

export interface ComponentHealth {
  id: string;
  name: string;
  category: 'mechanical' | 'fluid' | 'thermal' | 'electrical';
  healthScore: number; // 0 - 100%
  status: SeverityLevel;
  faultProbability: number; // 0 - 100%
  degradationRate: number; // % per flight hour
  estimatedRULHours: number; // hours
  currentMetricLabel: string;
  currentMetricValue: string;
  expectedMetricValue: string;
  maintenancePriority: 'URGENT' | 'HIGH' | 'MEDIUM' | 'LOW' | 'NORMAL';
  recommendedAction: string;
  subcomponents?: {
    name: string;
    health: number;
    status: SeverityLevel;
  }[];
}

export interface EngineHealthHierarchy {
  overallScore: number; // 0 - 100
  status: SeverityLevel;
  cylinderSystem: ComponentHealth;
  bearingSystem: ComponentHealth;
  fuelSystem: ComponentHealth;
  lubricationSystem: ComponentHealth;
  coolingSystem: ComponentHealth;
  ignitionSystem: ComponentHealth;
}

export interface FeatureImportance {
  feature: string;
  displayName: string;
  importance: number; // 0 - 100%
  value: number;
  unit: string;
  deviation: number;
  contributionDirection: 'increases_risk' | 'normal' | 'decreases_risk';
}

export interface AIAnalysisResult {
  detectedFault: string;
  confidence: number; // % (e.g. 91.8%)
  anomalyScore: number; // 0 - 100
  probableRootCause: string;
  aiReasoningSummary: string;
  affectedComponents: string[];
  recommendedMitigation: string;
  featureImportances: FeatureImportance[];
  detectedPatterns: string[];
  urgency: 'IMMEDIATE' | 'HIGH' | 'MONITOR' | 'NOMINAL';
  isGeminiGenerated?: boolean;
}

export type FaultPresetType = 'oil_leak' | 'bearing_wear' | 'overheating' | 'cooling_failure' | 'fuel_restriction' | 'compound_fault';

export interface RULPredictionData {
  remainingFlightHours: number;
  nominalRULHours: number;
  confidenceRangeMin: number;
  confidenceRangeMax: number;
  currentDegradationRate?: number;
  estimatedDaysToMaintenance?: number;
  healthDegradationTrend: {
    hourOffset: number;
    healthPercentage: number;
    confidenceUpper: number;
    confidenceLower: number;
    projectedStress: number;
  }[];
  predictedFailureMode: string;
  failureThresholdHours: number;
  degradationAccelerationFactor: number;
}

export interface UAVMissionState {
  missionId: string;
  missionName: string;
  status: 'PRE_FLIGHT' | 'ACTIVE' | 'RETURNING_TO_BASE' | 'COMPLETED' | 'ABORTED' | 'EMERGENCY_LANDED';
  progressPercentage: number; // 0 - 100
  currentWaypointIndex: number;
  totalWaypoints: number;
  currentLocationName: string;
  latitude: number;
  longitude: number;
  altitudeFt: number;
  groundSpeedKnots: number;
  headingDeg?: number;
  distanceCoveredKm: number;
  totalDistanceKm: number;
  distanceToBaseKm: number;
  etaMinutes: number;
  fuelRemainingLiters: number;
  fuelRemainingPercentage: number;
  batteryReservePercentage: number;
  returnToBaseRisk: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  missionRiskLevel: 'LOW' | 'MODERATE' | 'ELEVATED' | 'HIGH' | 'CRITICAL';
  operatorOverrideAction?: OperatorAction;
}

export type OperatorAction = 
  | 'CONTINUE_MISSION'
  | 'REDUCE_LOAD'
  | 'RETURN_TO_BASE'
  | 'EMERGENCY_LANDING'
  | 'INCREASE_COOLING'
  | 'ACTIVATE_BACKUP_PUMP';

export interface OperatorDecisionLog {
  id: string;
  timestamp: string;
  action: OperatorAction;
  triggeringAlert: string;
  engineHealthAtDecision: number;
  aiRecommendation: string;
  operatorNotes?: string;
  outcomeResult: string;
}

export interface AlertItem {
  id: string;
  timestamp: string;
  timestampMs: number;
  title: string;
  sensorOrComponent: string;
  currentValue: string;
  safeRange: string;
  severity: SeverityLevel;
  recommendedAction: string;
  acknowledged: boolean;
  resolved: boolean;
  category: 'Thermal' | 'Hydraulic' | 'Mechanical' | 'Combustion' | 'Electrical' | 'Mission';
}

export interface FaultInjectionState {
  oilPressureOverride: number | null; // PSI
  engineTempOverride: number | null; // °C
  oilTempOverride: number | null; // °C
  vibrationOverride: number | null; // mm/s
  rpmOverride: number | null; // RPM
  fuelFlowOverride: number | null; // L/h
  activePresets: {
    oilLeak: boolean;
    bearingWear: boolean;
    overheating: boolean;
    coolingSystemFailure: boolean;
    fuelSystemFailure: boolean;
    sensorDrift: boolean;
    ignitionMisfire: boolean;
  };
}

export interface MissionConfig {
  name: string;
  type: 'Surveillance' | 'Search & Rescue' | 'Mapping & Recon' | 'Perimeter Patrol' | 'Cargo Transit';
  distanceKm: number;
  targetAltitudeFt: number;
  expectedDurationHours: number;
  payloadWeightKg: number;
  cruiseSpeedKnots: number;
  environmentalConditions: 'Clear & Calm' | 'High Ambient Heat' | 'Turbulent & Gusty' | 'High Altitude Cold' | 'Humid Coastal';
}

export interface MissionFeasibilityResult {
  missionName: string;
  currentEngineHealth: number;
  predictedFuelRequirementPercent: number;
  estimatedEngineStress: number;
  missionSuccessProbability: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  predictedRULAfterMission: number;
  recommendedAction: 'APPROVED_FOR_LAUNCH' | 'PROCEED_WITH_CAUTION' | 'MAINTENANCE_REQUIRED_BEFORE_FLIGHT' | 'MISSION_ABORT_RECOMMENDED';
  analysisNotes: string[];
}

export interface SavedMissionRecord {
  id: string;
  missionName: string;
  dateStr: string;
  durationMinutes: number;
  engineHealthEnd: number;
  faultsDetected: string[];
  missionResult: 'SUCCESS' | 'COMPLETED_WITH_WARNINGS' | 'ABORTED' | 'EMERGENCY_RTB';
  finalRULHours: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  distanceCoveredKm: number;
  alertsCount: number;
  operatorDecisionsCount: number;
  telemetrySnapshot?: TelemetryData;
}
