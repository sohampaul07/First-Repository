/**
 * AEROTWIN AI - AI-Powered Hybrid Digital Twin for UAV Engine Health Monitoring
 */

import React from 'react';
import { SimulationProvider, useSimulation } from './context/SimulationContext';
import { Header } from './components/common/Header';
import { Sidebar } from './components/common/Sidebar';

// 16 Core Section Views
import { DashboardView } from './components/dashboard/DashboardView';
import { LiveTelemetryView } from './components/telemetry/LiveTelemetryView';
import { DigitalTwinView } from './components/digitaltwin/DigitalTwinView';
import { EngineHealthView } from './components/enginehealth/EngineHealthView';
import { AIIntelligenceView } from './components/aiintelligence/AIIntelligenceView';
import { FaultPredictionView } from './components/faultprediction/FaultPredictionView';
import { RULPredictionView } from './components/rul/RULPredictionView';
import { MaintenanceCenterView } from './components/maintenance/MaintenanceCenterView';
import { MissionMapView } from './components/mission/MissionMapView';
import { MissionPlannerView } from './components/mission/MissionPlannerView';
import { AnalyticsView } from './components/analytics/AnalyticsView';
import { FaultInjectionLabView } from './components/faultinjection/FaultInjectionLabView';
import { MissionHistoryView } from './components/history/MissionHistoryView';
import { AlertCenterView } from './components/alerts/AlertCenterView';
import { ReportsView } from './components/reports/ReportsView';
import { AboutProjectView } from './components/about/AboutProjectView';

const MainContent: React.FC = () => {
  const { activeView } = useSimulation();

  const renderActiveView = () => {
    switch (activeView) {
      case 'dashboard':
        return <DashboardView />;
      case 'telemetry':
        return <LiveTelemetryView />;
      case 'digital_twin':
        return <DigitalTwinView />;
      case 'engine_health':
        return <EngineHealthView />;
      case 'ai_intelligence':
        return <AIIntelligenceView />;
      case 'fault_prediction':
        return <FaultPredictionView />;
      case 'rul_prediction':
        return <RULPredictionView />;
      case 'maintenance_center':
        return <MaintenanceCenterView />;
      case 'mission_map':
        return <MissionMapView />;
      case 'mission_planner':
        return <MissionPlannerView />;
      case 'analytics':
        return <AnalyticsView />;
      case 'fault_injection':
        return <FaultInjectionLabView />;
      case 'mission_history':
        return <MissionHistoryView />;
      case 'alert_center':
        return <AlertCenterView />;
      case 'reports':
        return <ReportsView />;
      case 'about_project':
        return <AboutProjectView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#0A0A0B] text-[#E2E8F0] min-h-screen">
      <div className="max-w-7xl mx-auto">
        {renderActiveView()}
      </div>
    </div>
  );
};

export default function App() {
  return (
    <SimulationProvider>
      <div className="flex flex-col min-h-screen bg-[#0A0A0B] text-[#E2E8F0] selection:bg-blue-600 selection:text-white">
        <Header />
        <div className="flex flex-1 overflow-hidden">
          <Sidebar />
          <MainContent />
        </div>
      </div>
    </SimulationProvider>
  );
}
