/**
 * AEROTWIN AI - Centralized Shared Simulation Engine Context
 * 
 * Drives the closed-loop cause-and-effect digital twin simulation:
 * Fault Injection -> Sensor Telemetry -> Physics Model -> AI Anomaly Detection ->
 * Component Health -> RUL Update -> Mission Risk -> Operator Decision Support -> UI
 */

import React, { createContext, useContext, useState, useEffect, useRef, useCallback } from 'react';
import { 
  TelemetryData, 
  PhysicsExpectedValues, 
  AIAnalysisResult, 
  EngineHealthHierarchy, 
  RULPredictionData, 
  UAVMissionState, 
  FaultInjectionState, 
  AlertItem, 
  OperatorDecisionLog, 
  OperatorAction, 
  SavedMissionRecord,
  MissionConfig
} from '../types';
import { PhysicsEngine } from '../services/physicsEngine';
import { MLEngine } from '../services/mlEngine';

interface SimulationContextType {
  telemetry: TelemetryData;
  telemetryHistory: TelemetryData[];
  physics: PhysicsExpectedValues;
  aiAnalysis: AIAnalysisResult;
  componentHealth: EngineHealthHierarchy;
  rul: RULPredictionData;
  missionState: UAVMissionState;
  faultInjection: FaultInjectionState;
  alerts: AlertItem[];
  alertHistory: AlertItem[];
  operatorDecisions: OperatorDecisionLog[];
  savedMissions: SavedMissionRecord[];
  simulationSpeed: number;
  isPaused: boolean;
  operatorLoadFactor: number;
  activeView: string;
  setActiveView: (view: string) => void;
  setFaultOverride: (field: keyof Omit<FaultInjectionState, 'activePresets'>, value: number | null) => void;
  toggleFaultPreset: (presetName: keyof FaultInjectionState['activePresets']) => void;
  applyRandomFaultScenario: () => void;
  resetSimulation: () => void;
  setSimulationSpeed: (speed: number) => void;
  togglePause: () => void;
  executeOperatorAction: (action: OperatorAction, notes?: string) => void;
  acknowledgeAlert: (alertId: string) => void;
  resolveAlert: (alertId: string) => void;
  launchMissionFromPlanner: (config: MissionConfig) => void;
  saveCurrentMissionRecord: (result?: SavedMissionRecord['missionResult']) => void;
}

const SimulationContext = createContext<SimulationContextType | null>(null);

// Initial Seed Data
const initialFaultState: FaultInjectionState = {
  oilPressureOverride: null,
  engineTempOverride: null,
  oilTempOverride: null,
  vibrationOverride: null,
  rpmOverride: null,
  fuelFlowOverride: null,
  activePresets: {
    oilLeak: false,
    bearingWear: false,
    overheating: false,
    coolingSystemFailure: false,
    fuelSystemFailure: false,
    sensorDrift: false,
    ignitionMisfire: false,
  },
};

const initialSavedMissions: SavedMissionRecord[] = [
  {
    id: 'UAV-MSN-2026-089',
    missionName: 'Border Surveillance Sector Alpha',
    dateStr: '2026-08-27 14:15 UTC',
    durationMinutes: 145,
    engineHealthEnd: 94,
    faultsDetected: [],
    missionResult: 'SUCCESS',
    finalRULHours: 328.5,
    riskLevel: 'LOW',
    distanceCoveredKm: 340,
    alertsCount: 0,
    operatorDecisionsCount: 0,
  },
  {
    id: 'UAV-MSN-2026-088',
    missionName: 'Maritime Patrol Coastal Route',
    dateStr: '2026-08-26 09:30 UTC',
    durationMinutes: 180,
    engineHealthEnd: 88,
    faultsDetected: ['Minor CHT thermal gradient'],
    missionResult: 'COMPLETED_WITH_WARNINGS',
    finalRULHours: 295.0,
    riskLevel: 'MEDIUM',
    distanceCoveredKm: 420,
    alertsCount: 2,
    operatorDecisionsCount: 1,
  },
  {
    id: 'UAV-MSN-2026-087',
    missionName: 'Mountain Recon Target Grid 4',
    dateStr: '2026-08-24 16:50 UTC',
    durationMinutes: 72,
    engineHealthEnd: 42,
    faultsDetected: ['Oil pump cavitation', 'Bearing micro-wear'],
    missionResult: 'ABORTED',
    finalRULHours: 48.0,
    riskLevel: 'HIGH',
    distanceCoveredKm: 165,
    alertsCount: 6,
    operatorDecisionsCount: 2,
  },
];

export const SimulationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeView, setActiveView] = useState<string>('dashboard');
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);
  const [operatorLoadFactor, setOperatorLoadFactor] = useState<number>(1.0);
  const [faultInjection, setFaultInjection] = useState<FaultInjectionState>(initialFaultState);
  
  // Mission state
  const [missionState, setMissionState] = useState<UAVMissionState>({
    missionId: 'UAV-MSN-2026-090',
    missionName: 'Tactical Recon Mission 09',
    status: 'ACTIVE',
    progressPercentage: 42,
    currentWaypointIndex: 4,
    totalWaypoints: 9,
    currentLocationName: 'Waypoint 4 (Corridor Bravo)',
    latitude: 34.0522,
    longitude: -118.2437,
    altitudeFt: 12500,
    groundSpeedKnots: 115,
    distanceCoveredKm: 142.5,
    totalDistanceKm: 340.0,
    distanceToBaseKm: 142.5,
    etaMinutes: 68,
    fuelRemainingLiters: 16.4,
    fuelRemainingPercentage: 74,
    batteryReservePercentage: 98,
    returnToBaseRisk: 'LOW',
    missionRiskLevel: 'LOW',
  });

  // Telemetry state
  const [telemetry, setTelemetry] = useState<TelemetryData>(() => {
    const baseRPM = 5200;
    const baseThrottle = 75;
    return {
      timestamp: Date.now(),
      rpm: baseRPM,
      engineTemp: 92.4,
      oilTemp: 84.1,
      oilPressure: 56.5,
      vibration: 2.15,
      fuelFlow: 6.2,
      cylinderHeadTemp: 154.2,
      exhaustGasTemp: 712.0,
      throttle: baseThrottle,
      ambientTemp: 22.0,
      altitude: 12500,
      manifoldPressure: 28.4,
    };
  });

  const [telemetryHistory, setTelemetryHistory] = useState<TelemetryData[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [alertHistory, setAlertHistory] = useState<AlertItem[]>([]);
  const [operatorDecisions, setOperatorDecisions] = useState<OperatorDecisionLog[]>([]);
  const [savedMissions, setSavedMissions] = useState<SavedMissionRecord[]>(initialSavedMissions);

  // Computed state caches
  const physicsRef = useRef<PhysicsExpectedValues>(PhysicsEngine.compareActualVsExpected(telemetry, operatorLoadFactor));
  const aiRef = useRef<AIAnalysisResult>(MLEngine.analyzeTelemetry(telemetry, physicsRef.current, faultInjection));
  const healthRef = useRef<EngineHealthHierarchy>(MLEngine.calculateComponentHierarchy(telemetry, physicsRef.current, aiRef.current));
  const rulRef = useRef<RULPredictionData>(MLEngine.calculateRUL(healthRef.current, physicsRef.current, aiRef.current));

  const [physics, setPhysics] = useState<PhysicsExpectedValues>(physicsRef.current);
  const [aiAnalysis, setAiAnalysis] = useState<AIAnalysisResult>(aiRef.current);
  const [componentHealth, setComponentHealth] = useState<EngineHealthHierarchy>(healthRef.current);
  const [rul, setRul] = useState<RULPredictionData>(rulRef.current);

  // Time & Simulation Step
  const stepCountRef = useRef<number>(0);

  // Core Simulation Loop
  useEffect(() => {
    if (isPaused) return;

    const intervalMs = Math.max(100, Math.floor(1000 / (10 * Math.min(simulationSpeed, 5))));

    const timer = setInterval(() => {
      stepCountRef.current += 1;
      const step = stepCountRef.current;
      const now = Date.now();

      // 1. Calculate base mechanical parameters
      let targetRPM = 5100 + Math.sin(step * 0.05) * 80 + (Math.random() - 0.5) * 30;
      let targetThrottle = 72 + Math.sin(step * 0.03) * 4;

      // Modulate with operator load factor
      targetThrottle *= operatorLoadFactor;
      targetRPM *= (0.6 + 0.4 * operatorLoadFactor);

      // 2. Apply Fault Presets / Overrides
      let activeOilPressure = 55.0 + (targetRPM / 5000) * 4.5 + (Math.random() - 0.5) * 0.8;
      let activeEngineTemp = 91.5 + (targetRPM / 5000) * 3.5 + (Math.random() - 0.5) * 0.4;
      let activeOilTemp = 83.2 + (targetRPM / 5000) * 2.8 + (Math.random() - 0.5) * 0.4;
      let activeVibration = 2.10 + (targetRPM / 5000) * 0.4 + (Math.random() - 0.5) * 0.15;
      let activeFuelFlow = 5.8 + (targetThrottle / 100) * 2.2 + (Math.random() - 0.5) * 0.2;
      let activeCHT = 152.0 + (targetRPM / 5000) * 6.0 + (Math.random() - 0.5) * 0.8;
      let activeEGT = 705.0 + (targetThrottle / 100) * 35.0 + (Math.random() - 0.5) * 2.5;

      const p = faultInjection.activePresets;

      if (p.oilLeak) {
        activeOilPressure = Math.max(16.0, activeOilPressure - 36.0 - Math.sin(step * 0.1) * 2.5);
        activeOilTemp += 18.5;
        activeEngineTemp += 9.0;
      }
      if (p.bearingWear) {
        activeVibration = Math.max(6.8, activeVibration + 4.8 + Math.sin(step * 0.2) * 0.8);
        activeEngineTemp += 6.5;
      }
      if (p.overheating || p.coolingSystemFailure) {
        activeEngineTemp = Math.max(118.5, activeEngineTemp + 28.0 + Math.sin(step * 0.08) * 3.0);
        activeCHT = Math.max(208.0, activeCHT + 45.0);
        activeOilTemp += 16.0;
      }
      if (p.fuelSystemFailure) {
        activeFuelFlow = Math.max(10.8, activeFuelFlow + 4.5);
        activeEGT += 85.0;
      }
      if (p.ignitionMisfire) {
        activeVibration += 2.8;
        activeEGT -= 60.0;
        targetRPM -= 400;
      }
      if (p.sensorDrift) {
        activeOilPressure = 92.0; // unphysical transducer spike
      }

      // Manual Slider Overrides
      if (faultInjection.oilPressureOverride !== null) activeOilPressure = faultInjection.oilPressureOverride;
      if (faultInjection.engineTempOverride !== null) activeEngineTemp = faultInjection.engineTempOverride;
      if (faultInjection.oilTempOverride !== null) activeOilTemp = faultInjection.oilTempOverride;
      if (faultInjection.vibrationOverride !== null) activeVibration = faultInjection.vibrationOverride;
      if (faultInjection.rpmOverride !== null) targetRPM = faultInjection.rpmOverride;
      if (faultInjection.fuelFlowOverride !== null) activeFuelFlow = faultInjection.fuelFlowOverride;

      const newTelemetry: TelemetryData = {
        timestamp: now,
        rpm: Math.round(targetRPM),
        engineTemp: Math.round(activeEngineTemp * 10) / 10,
        oilTemp: Math.round(activeOilTemp * 10) / 10,
        oilPressure: Math.round(activeOilPressure * 10) / 10,
        vibration: Math.round(activeVibration * 100) / 100,
        fuelFlow: Math.round(activeFuelFlow * 10) / 10,
        cylinderHeadTemp: Math.round(activeCHT * 10) / 10,
        exhaustGasTemp: Math.round(activeEGT * 10) / 10,
        throttle: Math.round(targetThrottle),
        ambientTemp: 22.0,
        altitude: 12500,
        manifoldPressure: Math.round((26.0 + (targetThrottle / 100) * 4.0) * 10) / 10,
      };

      setTelemetry(newTelemetry);
      setTelemetryHistory(prev => {
        const next = [...prev, newTelemetry];
        return next.slice(-80); // keep rolling 80 frames
      });

      // 3. Run Physics Model
      const newPhysics = PhysicsEngine.compareActualVsExpected(newTelemetry, operatorLoadFactor);
      setPhysics(newPhysics);
      physicsRef.current = newPhysics;

      // 4. Run AI / ML Inference & Feature Importance
      const newAI = MLEngine.analyzeTelemetry(newTelemetry, newPhysics, faultInjection);
      setAiAnalysis(newAI);
      aiRef.current = newAI;

      // 5. Compute Component Hierarchy
      const newHealth = MLEngine.calculateComponentHierarchy(newTelemetry, newPhysics, newAI);
      setComponentHealth(newHealth);
      healthRef.current = newHealth;

      // 6. Compute Remaining Useful Life (RUL)
      const newRul = MLEngine.calculateRUL(newHealth, newPhysics, newAI);
      setRul(newRul);
      rulRef.current = newRul;

      // 7. Update Mission State
      setMissionState(prev => {
        if (prev.status !== 'ACTIVE' && prev.status !== 'RETURNING_TO_BASE') return prev;

        const deltaProg = 0.05 * simulationSpeed;
        let nextProg = Math.min(100, prev.progressPercentage + deltaProg);
        let nextStatus = prev.status;

        if (nextProg >= 100) {
          nextStatus = 'COMPLETED';
        }

        const currentWp = Math.min(prev.totalWaypoints, Math.floor((nextProg / 100) * prev.totalWaypoints) + 1);
        const fuelConsumptionPerTick = (newTelemetry.fuelFlow / 3600) * (intervalMs / 1000) * simulationSpeed;
        const nextFuel = Math.max(0.2, prev.fuelRemainingLiters - fuelConsumptionPerTick);
        const fuelPct = Math.round((nextFuel / 22.0) * 100);

        // Mission Risk & RTB Risk connected directly to engine health
        let returnToBaseRisk: UAVMissionState['returnToBaseRisk'] = 'LOW';
        let missionRiskLevel: UAVMissionState['missionRiskLevel'] = 'LOW';

        if (newHealth.overallScore < 45 || newTelemetry.oilPressure < 25 || newTelemetry.engineTemp > 115) {
          returnToBaseRisk = 'CRITICAL';
          missionRiskLevel = 'CRITICAL';
        } else if (newHealth.overallScore < 70 || newAI.anomalyScore > 40) {
          returnToBaseRisk = 'HIGH';
          missionRiskLevel = 'ELEVATED';
        } else if (newHealth.overallScore < 85) {
          returnToBaseRisk = 'MEDIUM';
          missionRiskLevel = 'MODERATE';
        }

        // Distance covered and base calculations
        const distanceCovered = Math.round((nextProg / 100) * prev.totalDistanceKm * 10) / 10;
        const distToBase = prev.status === 'RETURNING_TO_BASE'
          ? Math.max(0, prev.distanceToBaseKm - (0.4 * simulationSpeed))
          : Math.min(220, 40 + Math.sin(nextProg * 0.03) * 160);

        return {
          ...prev,
          status: nextStatus,
          progressPercentage: Math.round(nextProg * 10) / 10,
          currentWaypointIndex: currentWp,
          currentLocationName: `Waypoint ${currentWp} (${currentWp === prev.totalWaypoints ? 'Target Ingress' : 'Corridor Sector ' + String.fromCharCode(64 + currentWp)})`,
          distanceCoveredKm: distanceCovered,
          distanceToBaseKm: Math.round(distToBase * 10) / 10,
          fuelRemainingLiters: Math.round(nextFuel * 100) / 100,
          fuelRemainingPercentage: fuelPct,
          returnToBaseRisk,
          missionRiskLevel,
          groundSpeedKnots: Math.round(105 + (newTelemetry.throttle / 100) * 25),
        };
      });

      // 8. Auto-Trigger Dynamic Alerts
      if (newTelemetry.oilPressure < 25) {
        triggerAlert({
          id: `alert-oil-${Math.floor(now / 15000)}`,
          timestamp: new Date().toLocaleTimeString(),
          timestampMs: now,
          title: 'CRITICAL: Oil Pressure Below Hydraulic Safety Limit',
          sensorOrComponent: 'Lubrication System (Oil Pressure)',
          currentValue: `${newTelemetry.oilPressure.toFixed(1)} PSI`,
          safeRange: '45.0 – 75.0 PSI',
          severity: 'critical',
          category: 'Hydraulic',
          recommendedAction: 'Reduce engine throttle to 40% immediately. Execute Return-to-Base (RTB) protocol.',
          acknowledged: false,
          resolved: false,
        });
      } else if (newTelemetry.engineTemp > 115) {
        triggerAlert({
          id: `alert-temp-${Math.floor(now / 15000)}`,
          timestamp: new Date().toLocaleTimeString(),
          timestampMs: now,
          title: 'CRITICAL: Cylinder Block Core Thermal Runaway',
          sensorOrComponent: 'Cooling / Engine Block',
          currentValue: `${newTelemetry.engineTemp.toFixed(1)}°C`,
          safeRange: '80.0 – 105.0°C',
          severity: 'critical',
          category: 'Thermal',
          recommendedAction: 'Increase airspeed for ram-air cooling; reduce climb throttle.',
          acknowledged: false,
          resolved: false,
        });
      } else if (newTelemetry.vibration > 6.0) {
        triggerAlert({
          id: `alert-vib-${Math.floor(now / 15000)}`,
          timestamp: new Date().toLocaleTimeString(),
          timestampMs: now,
          title: 'WARNING: Elevated High-Frequency Bearing Vibration Harmonic',
          sensorOrComponent: 'Crankshaft Main Bearings',
          currentValue: `${newTelemetry.vibration.toFixed(2)} mm/s RMS`,
          safeRange: '1.20 – 3.80 mm/s',
          severity: 'warning',
          category: 'Mechanical',
          recommendedAction: 'Avoid high RPM oscillations; schedule borescope clearance measurement upon landing.',
          acknowledged: false,
          resolved: false,
        });
      }

    }, intervalMs);

    return () => clearInterval(timer);
  }, [isPaused, simulationSpeed, operatorLoadFactor, faultInjection]);

  // Helper to trigger alerts deduplicated by ID
  const triggerAlert = useCallback((newAlert: AlertItem) => {
    setAlerts(prev => {
      if (prev.some(a => a.id === newAlert.id)) return prev;
      return [newAlert, ...prev.slice(0, 8)];
    });
    setAlertHistory(prev => {
      if (prev.some(a => a.id === newAlert.id)) return prev;
      return [newAlert, ...prev.slice(0, 50)];
    });
  }, []);

  // Fault injection controls
  const setFaultOverride = useCallback((field: keyof Omit<FaultInjectionState, 'activePresets'>, value: number | null) => {
    setFaultInjection(prev => ({
      ...prev,
      [field]: value,
    }));
  }, []);

  const toggleFaultPreset = useCallback((presetName: keyof FaultInjectionState['activePresets']) => {
    setFaultInjection(prev => ({
      ...prev,
      activePresets: {
        ...prev.activePresets,
        [presetName]: !prev.activePresets[presetName],
      },
    }));
  }, []);

  const applyRandomFaultScenario = useCallback(() => {
    const scenarios: (keyof FaultInjectionState['activePresets'])[][] = [
      ['oilLeak'],
      ['bearingWear'],
      ['overheating', 'coolingSystemFailure'],
      ['oilLeak', 'bearingWear', 'overheating'], // compound multi-fault
      ['fuelSystemFailure'],
      ['ignitionMisfire'],
    ];
    const picked = scenarios[Math.floor(Math.random() * scenarios.length)];
    
    setFaultInjection({
      oilPressureOverride: null,
      engineTempOverride: null,
      oilTempOverride: null,
      vibrationOverride: null,
      rpmOverride: null,
      fuelFlowOverride: null,
      activePresets: {
        oilLeak: picked.includes('oilLeak'),
        bearingWear: picked.includes('bearingWear'),
        overheating: picked.includes('overheating'),
        coolingSystemFailure: picked.includes('coolingSystemFailure'),
        fuelSystemFailure: picked.includes('fuelSystemFailure'),
        sensorDrift: picked.includes('sensorDrift'),
        ignitionMisfire: picked.includes('ignitionMisfire'),
      },
    });
  }, []);

  const resetSimulation = useCallback(() => {
    setFaultInjection(initialFaultState);
    setOperatorLoadFactor(1.0);
    setAlerts([]);
  }, []);

  const togglePause = useCallback(() => {
    setIsPaused(prev => !prev);
  }, []);

  // Operator Decisions Support Actions
  const executeOperatorAction = useCallback((action: OperatorAction, notes?: string) => {
    const timestamp = new Date().toLocaleTimeString();
    let outcome = '';

    if (action === 'CONTINUE_MISSION') {
      outcome = 'Operator accepted risk and elected to continue mission at nominal profile.';
    } else if (action === 'REDUCE_LOAD') {
      setOperatorLoadFactor(0.65);
      outcome = 'Engine throttle and power output derated by 35%. Thermal and mechanical degradation rate reduced.';
    } else if (action === 'RETURN_TO_BASE') {
      setMissionState(prev => ({
        ...prev,
        status: 'RETURNING_TO_BASE',
        currentLocationName: 'RTB Transit Vector (Vectoring to Base Grid)',
      }));
      setOperatorLoadFactor(0.75);
      outcome = 'UAV aborted primary route and initiated Return-to-Base (RTB) navigation on minimum-stress flight vector.';
    } else if (action === 'EMERGENCY_LANDING') {
      setMissionState(prev => ({
        ...prev,
        status: 'EMERGENCY_LANDED',
        currentLocationName: 'Emergency Landing Site (Field Bravo-7)',
      }));
      setOperatorLoadFactor(0.2);
      outcome = 'UAV executed controlled emergency touchdown at nearest designated safe alternate landing zone.';
    }

    const decisionLog: OperatorDecisionLog = {
      id: `dec-${Date.now()}`,
      timestamp,
      action,
      triggeringAlert: aiRef.current.detectedFault,
      engineHealthAtDecision: healthRef.current.overallScore,
      aiRecommendation: aiRef.current.recommendedMitigation,
      operatorNotes: notes,
      outcomeResult: outcome,
    };

    setOperatorDecisions(prev => [decisionLog, ...prev]);
  }, []);

  const acknowledgeAlert = useCallback((alertId: string) => {
    setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, acknowledged: true } : a));
  }, []);

  const resolveAlert = useCallback((alertId: string) => {
    setAlerts(prev => prev.filter(a => a.id !== alertId));
  }, []);

  const launchMissionFromPlanner = useCallback((config: MissionConfig) => {
    setMissionState({
      missionId: `UAV-MSN-${Math.floor(1000 + Math.random() * 9000)}`,
      missionName: config.name,
      status: 'ACTIVE',
      progressPercentage: 0,
      currentWaypointIndex: 1,
      totalWaypoints: 8,
      currentLocationName: 'Waypoint 1 (Takeoff & Climb Corridor)',
      latitude: 34.0522,
      longitude: -118.2437,
      altitudeFt: config.targetAltitudeFt,
      groundSpeedKnots: config.cruiseSpeedKnots,
      distanceCoveredKm: 0,
      totalDistanceKm: config.distanceKm,
      distanceToBaseKm: 0,
      etaMinutes: Math.round((config.distanceKm / (config.cruiseSpeedKnots * 1.852)) * 60),
      fuelRemainingLiters: 22.0,
      fuelRemainingPercentage: 100,
      batteryReservePercentage: 100,
      returnToBaseRisk: 'LOW',
      missionRiskLevel: 'LOW',
    });
    resetSimulation();
    setActiveView('mission_map');
  }, [resetSimulation]);

  const saveCurrentMissionRecord = useCallback((customResult?: SavedMissionRecord['missionResult']) => {
    const result = customResult || (missionState.status === 'COMPLETED' ? 'SUCCESS' : missionState.status === 'EMERGENCY_LANDED' ? 'EMERGENCY_RTB' : 'ABORTED');
    const newRecord: SavedMissionRecord = {
      id: missionState.missionId,
      missionName: missionState.missionName,
      dateStr: new Date().toISOString().replace('T', ' ').substring(0, 16) + ' UTC',
      durationMinutes: Math.round(missionState.distanceCoveredKm / 2.5) || 45,
      engineHealthEnd: componentHealth.overallScore,
      faultsDetected: aiAnalysis.detectedFault !== 'Nominal Operational State' ? [aiAnalysis.detectedFault] : [],
      missionResult: result,
      finalRULHours: rul.remainingFlightHours,
      riskLevel: missionState.missionRiskLevel === 'CRITICAL' ? 'CRITICAL' : missionState.missionRiskLevel === 'HIGH' ? 'HIGH' : missionState.missionRiskLevel === 'ELEVATED' ? 'MEDIUM' : 'LOW',
      distanceCoveredKm: missionState.distanceCoveredKm,
      alertsCount: alertHistory.length,
      operatorDecisionsCount: operatorDecisions.length,
      telemetrySnapshot: { ...telemetry },
    };

    setSavedMissions(prev => [newRecord, ...prev]);
  }, [missionState, componentHealth, aiAnalysis, rul, alertHistory, operatorDecisions, telemetry]);

  return (
    <SimulationContext.Provider
      value={{
        telemetry,
        telemetryHistory,
        physics,
        aiAnalysis,
        componentHealth,
        rul,
        missionState,
        faultInjection,
        alerts,
        alertHistory,
        operatorDecisions,
        savedMissions,
        simulationSpeed,
        isPaused,
        operatorLoadFactor,
        activeView,
        setActiveView,
        setFaultOverride,
        toggleFaultPreset,
        applyRandomFaultScenario,
        resetSimulation,
        setSimulationSpeed,
        togglePause,
        executeOperatorAction,
        acknowledgeAlert,
        resolveAlert,
        launchMissionFromPlanner,
        saveCurrentMissionRecord,
      }}
    >
      {children}
    </SimulationContext.Provider>
  );
};

export const useSimulation = (): SimulationContextType => {
  const context = useContext(SimulationContext);
  if (!context) {
    throw new Error('useSimulation must be used within a SimulationProvider');
  }
  return context;
};
