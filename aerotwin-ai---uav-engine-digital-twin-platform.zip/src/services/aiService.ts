/**
 * AEROTWIN AI - Frontend AI Client Service
 */

import { 
  TelemetryData, 
  PhysicsExpectedValues, 
  AIAnalysisResult, 
  EngineHealthHierarchy, 
  UAVMissionState 
} from '../types';

export interface GeminiDiagnosticResponse {
  available: boolean;
  source: 'gemini_2_5_flash' | 'local_ml_hybrid';
  diagnosticInsight?: string;
  error?: string;
}

export interface GeminiReportResponse {
  executiveSummary: string;
  subsystemRisks: string[];
  maintenanceDirectives: string[];
}

export class AIService {
  public static async fetchDeepDiagnostics(
    telemetry: TelemetryData,
    physics: PhysicsExpectedValues,
    aiAnalysis: AIAnalysisResult,
    componentHealth: EngineHealthHierarchy
  ): Promise<GeminiDiagnosticResponse> {
    try {
      const response = await fetch('/api/ai-diagnostics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          telemetry,
          physics,
          detectedFault: aiAnalysis.detectedFault,
          confidence: aiAnalysis.confidence,
          componentHealth,
        }),
      });

      if (!response.ok) {
        return {
          available: false,
          source: 'local_ml_hybrid',
          diagnosticInsight: aiAnalysis.aiReasoningSummary,
        };
      }

      const data = await response.json();
      return data;
    } catch {
      return {
        available: false,
        source: 'local_ml_hybrid',
        diagnosticInsight: aiAnalysis.aiReasoningSummary,
      };
    }
  }

  public static async generateMissionReport(
    telemetry: TelemetryData,
    physics: PhysicsExpectedValues,
    aiAnalysis: AIAnalysisResult,
    componentHealth: EngineHealthHierarchy,
    missionState: UAVMissionState
  ): Promise<GeminiReportResponse> {
    try {
      const response = await fetch('/api/ai-report-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          missionName: missionState.missionName,
          duration: missionState.progressPercentage,
          healthEnd: componentHealth.overallScore,
          faults: [aiAnalysis.detectedFault],
          decisionsCount: 1,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.summary) {
          return {
            executiveSummary: data.summary,
            subsystemRisks: [aiAnalysis.detectedFault, `Anomaly score: ${aiAnalysis.anomalyScore}%`],
            maintenanceDirectives: [aiAnalysis.recommendedMitigation],
          };
        }
      }
    } catch (e) {
      console.warn('Fallback local summary report:', e);
    }

    return {
      executiveSummary: `Propulsion health audit for UAV call-sign ${missionState.missionId} during operation "${missionState.missionName}". 
Digital Twin physical kinematics indicate overall propulsion condition score of ${componentHealth.overallScore}%. 
${aiAnalysis.detectedFault !== 'Nominal Operational State' ? `Transducer deviations confirm ${aiAnalysis.detectedFault} (Confidence: ${aiAnalysis.confidence}%). Root cause is attributed to: ${aiAnalysis.probableRootCause}.` : 'All 6 critical subsystems exhibit nominal thermodynamic and mechanical stability.'}`,
      subsystemRisks: [aiAnalysis.detectedFault],
      maintenanceDirectives: [aiAnalysis.recommendedMitigation],
    };
  }

  public static async generateReportSummary(
    missionName: string,
    duration: number,
    healthEnd: number,
    faults: string[],
    decisionsCount: number
  ): Promise<string> {
    const rep = await this.generateMissionReport(
      {} as any,
      {} as any,
      { detectedFault: faults[0] || 'Nominal', confidence: 95, anomalyScore: 10, probableRootCause: 'None', recommendedMitigation: 'None' } as any,
      { overallScore: healthEnd } as any,
      { missionId: 'UAV-150', missionName, progressPercentage: duration } as any
    );
    return rep.executiveSummary;
  }
}
