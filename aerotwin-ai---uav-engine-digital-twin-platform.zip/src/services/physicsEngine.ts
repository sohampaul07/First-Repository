/**
 * AEROTWIN AI - Physics-Based Engine Modeling Service
 * 
 * Implements thermo-mechanical, fluid dynamic, and acoustic vibration physics
 * for a high-performance twin-cylinder UAV internal combustion engine (150cc EFI).
 */

import { TelemetryData, PhysicsExpectedValues } from '../types';

export class PhysicsEngine {
  /**
   * Calculates theoretical baseline telemetry expected from thermodynamic
   * and mechanical physics equations given current operating state.
   */
  public static calculateExpectedValues(
    rpm: number,
    throttle: number,
    ambientTemp: number = 25,
    altitude: number = 5000,
    operatorLoadFactor: number = 1.0 // modified if operator reduced load
  ): Omit<PhysicsExpectedValues, 'tempDeviation' | 'pressureDeviation' | 'vibrationDeviation' | 'fuelDeviation'> {
    const effectiveThrottle = Math.max(10, Math.min(100, throttle * operatorLoadFactor));
    const normalizedRPM = Math.max(2000, Math.min(7000, rpm));
    
    // Altitude air density correction (barometric formula approximation)
    const airDensityRatio = Math.exp(-altitude / 28000);
    
    // 1. Thermodynamic Thermal Balance:
    // Heat Generated = Q_fuel * (1 - efficiency) * RPM_load
    // Heat Dissipated = h_cooling * (T_engine - T_ambient) * airVelocity
    // Normal thermal equilibrium:
    const baseThermalLoad = (normalizedRPM / 5000) * 55 + (effectiveThrottle / 100) * 35;
    const coolingEffect = (1 - (ambientTemp - 20) / 100) * (normalizedRPM / 5000) * 15;
    const expectedEngineTemp = Math.round((ambientTemp + baseThermalLoad - coolingEffect + 25) * 10) / 10;
    
    // Expected Oil Temperature (typically lags engine block by ~5-10°C)
    const expectedOilTemp = Math.round((expectedEngineTemp * 0.88 + ambientTemp * 0.12) * 10) / 10;
    
    // 2. Fluid Hydrodynamics (Oil Pump Positive Displacement):
    // Pressure P = k_pump * RPM - viscosity_loss(T_oil)
    // Higher temp reduces kinematic viscosity, reducing pressure slightly.
    const pumpDisplacement = (normalizedRPM / 5000) * 58; // PSI baseline
    const viscosityDamping = Math.max(0, (expectedOilTemp - 80) * 0.22);
    const expectedOilPressure = Math.round(Math.max(30, Math.min(78, pumpDisplacement + 12 - viscosityDamping)) * 10) / 10;
    
    // 3. Fuel Mass Flow Rate (Stoichiometric AFR = 14.7:1):
    // Mass_air = Displaced_volume * (RPM/2) * Volumetric_efficiency * airDensity
    // Mass_fuel = Mass_air / AFR
    const volumetricEfficiency = 0.82 + (effectiveThrottle / 100) * 0.12;
    const engineDisplacementLiters = 0.15; // 150cc
    const intakeAirVolumePerHour = (normalizedRPM * 60 / 2) * engineDisplacementLiters * volumetricEfficiency; // Liters of air
    const fuelMassFlowRateLitersPerHour = (intakeAirVolumePerHour * airDensityRatio) / (14.7 * 820) * 750; // gasoline density ~750 g/L
    const expectedFuelFlow = Math.round(Math.max(2.5, Math.min(11.5, fuelMassFlowRateLitersPerHour + (effectiveThrottle / 100) * 2.8)) * 10) / 10;
    
    // 4. Harmonic Mechanical Vibration:
    // Primary 1X (crankshaft rotational freq) + 2X (piston reciprocating second-order inertia)
    // RMS = sqrt(w1^2 + w2^2)
    const baseFreqHz = normalizedRPM / 60; // e.g. 80 Hz at 4800 RPM
    const unbalanceConstant = 0.032;
    const expectedVibration = Math.round(Math.max(1.0, (baseFreqHz * unbalanceConstant + (effectiveThrottle / 100) * 0.9)) * 100) / 100;
    
    // 5. Cylinder Head Temp (CHT) & Exhaust Gas Temp (EGT)
    const expectedCHT = Math.round((expectedEngineTemp * 1.55 + (effectiveThrottle / 100) * 28) * 10) / 10;
    const expectedEGT = Math.round((640 + (effectiveThrottle / 100) * 110 + (normalizedRPM / 5000) * 35) * 10) / 10;
    
    // 6. Mechanical Stress Factor & Thermal Efficiency
    const thermalEfficiency = Math.round((28.5 + (normalizedRPM / 5000) * 3.2 - (expectedEngineTemp > 110 ? 4.5 : 0)) * 10) / 10;
    const stressFactor = Math.min(1.0, (normalizedRPM / 6500) * 0.55 + (effectiveThrottle / 100) * 0.45);

    return {
      expectedEngineTemp,
      expectedOilTemp,
      expectedOilPressure,
      expectedVibration,
      expectedFuelFlow,
      expectedCHT,
      expectedEGT,
      thermalEfficiency,
      stressFactor,
    };
  }

  /**
   * Compares actual telemetry stream with the physics-based mathematical expectation
   * to extract precise physical residuals (deviations) and thermodynamic health.
   */
  public static compareActualVsExpected(
    actual: TelemetryData,
    operatorLoadFactor: number = 1.0
  ): PhysicsExpectedValues {
    const expected = this.calculateExpectedValues(
      actual.rpm,
      actual.throttle,
      actual.ambientTemp,
      actual.altitude,
      operatorLoadFactor
    );

    const tempDeviation = Math.round((actual.engineTemp - expected.expectedEngineTemp) * 10) / 10;
    const pressureDeviation = Math.round((actual.oilPressure - expected.expectedOilPressure) * 10) / 10;
    const vibrationDeviation = Math.round((actual.vibration - expected.expectedVibration) * 100) / 100;
    const fuelDeviation = Math.round((actual.fuelFlow - expected.expectedFuelFlow) * 10) / 10;

    return {
      ...expected,
      tempDeviation,
      pressureDeviation,
      vibrationDeviation,
      fuelDeviation,
    };
  }

  /**
   * Computes the physical anomaly score combining normalized Euclidean distances
   * across multiple thermodynamic and fluid sensor deviations.
   */
  public static computePhysicsAnomalyScore(deviations: {
    tempDev: number;
    pressureDev: number;
    vibDev: number;
    fuelDev: number;
  }): number {
    // Normalized weights for each deviation vector
    const normTemp = Math.min(100, (Math.abs(deviations.tempDev) / 25) * 100);
    const normPressure = Math.min(100, (Math.abs(deviations.pressureDev) / 30) * 100);
    const normVibration = Math.min(100, (Math.abs(deviations.vibDev) / 3.5) * 100);
    const normFuel = Math.min(100, (Math.abs(deviations.fuelDev) / 3.0) * 100);

    // Weighted quadratic distance
    const compositeScore = Math.sqrt(
      0.30 * Math.pow(normTemp, 2) +
      0.35 * Math.pow(normPressure, 2) +
      0.25 * Math.pow(normVibration, 2) +
      0.10 * Math.pow(normFuel, 2)
    );

    return Math.min(100, Math.round(compositeScore * 10) / 10);
  }
}
