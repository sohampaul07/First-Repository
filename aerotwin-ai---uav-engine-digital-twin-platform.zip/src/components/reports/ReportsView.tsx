/**
 * AEROTWIN AI - Aerospace Technical Report Generator
 */

import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  Sparkles, 
  ShieldCheck, 
  CheckCircle2, 
  Clock,
  Layers,
  Cpu
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { AIService, GeminiReportResponse } from '../../services/aiService';

export const ReportsView: React.FC = () => {
  const { 
    telemetry, 
    physics, 
    aiAnalysis, 
    componentHealth, 
    rul, 
    missionState 
  } = useSimulation();

  const [geminiReport, setGeminiReport] = useState<GeminiReportResponse | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  const handleGenerateAIReport = async () => {
    setIsGenerating(true);
    try {
      const rep = await AIService.generateMissionReport(
        telemetry,
        physics,
        aiAnalysis,
        componentHealth,
        missionState
      );
      setGeminiReport(rep);
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportJSON = () => {
    const reportData = {
      reportId: `AEROTWIN-REP-${Date.now()}`,
      timestamp: new Date().toISOString(),
      uavEngine: 'UAV-150cc EFI Boxer Twin',
      telemetry,
      physicsModel: physics,
      aiAnalysis,
      componentHealth,
      rul,
      missionState,
    };
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AEROTWIN_DIAGNOSTIC_REPORT_${Date.now()}.json`;
    a.click();
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              AEROSPACE PROPULSION TECHNICAL REPORT
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
              DEFENSE & FLIGHT READINESS AUDIT
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Automated technical flight audit generated from real-time Hybrid Digital Twin telemetry
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={handleExportJSON}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-mono transition-colors"
          >
            <Download className="h-4 w-4 text-cyan-400" />
            <span>EXPORT JSON</span>
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-mono transition-colors"
          >
            <Printer className="h-4 w-4 text-cyan-400" />
            <span>PRINT / PDF</span>
          </button>

          <button
            onClick={handleGenerateAIReport}
            disabled={isGenerating}
            className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/25 transition-all"
          >
            <Sparkles className="h-4 w-4" />
            <span>{isGenerating ? 'GENERATING REPORT...' : 'GENERATE AI SUMMARY'}</span>
          </button>
        </div>
      </div>

      {/* Printable Report Document Card */}
      <div id="printable-report" className="rounded-2xl border border-slate-800 bg-slate-950 p-6 sm:p-8 shadow-2xl text-slate-200 space-y-6">
        {/* Document Title Strip */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-800 gap-4">
          <div>
            <div className="text-[11px] font-mono uppercase text-cyan-400 tracking-widest font-bold">
              PROPULSION HEALTH ASSESSMENT REPORT • OFFICIAL DEBRIEF
            </div>
            <h1 className="font-display font-bold text-2xl text-slate-100 mt-1">
              UAV-150cc DIGITAL TWIN AUDIT REPORT
            </h1>
            <p className="text-xs font-mono text-slate-400 mt-1">
              Generated: {new Date().toUTCString()} • Classification: UNCLASSIFIED / TECH SPEC
            </p>
          </div>

          <div className="text-right font-mono text-xs text-slate-400 space-y-0.5">
            <div>Engine S/N: <strong className="text-slate-200">#150-EFI-8820B</strong></div>
            <div>Airframe ID: <strong className="text-slate-200">{missionState.missionId}</strong></div>
            <div>Cumulative Hours: <strong className="text-cyan-400">184.6 hrs</strong></div>
          </div>
        </div>

        {/* Executive Summary */}
        <div className="space-y-2">
          <h3 className="font-display font-bold text-sm text-cyan-400 uppercase tracking-wider">
            1. EXECUTIVE DIAGNOSTIC SUMMARY
          </h3>
          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-xs leading-relaxed font-sans text-slate-300">
            {geminiReport ? (
              <p className="whitespace-pre-line">{geminiReport.executiveSummary}</p>
            ) : (
              <p>
                The AEROTWIN Hybrid Digital Twin continuously validates multi-body thermo-mechanical kinematics against live telemetry. 
                Overall propulsion health is currently evaluated at <strong>{componentHealth.overallScore}% ({componentHealth.status.toUpperCase()})</strong>. 
                Active diagnosis: <strong>{aiAnalysis.detectedFault}</strong> with an AI confidence factor of <strong>{aiAnalysis.confidence}%</strong>.
              </p>
            )}
          </div>
        </div>

        {/* Engine Telemetry & Physics Baseline Table */}
        <div className="space-y-2">
          <h3 className="font-display font-bold text-sm text-cyan-400 uppercase tracking-wider">
            2. TELEMETRY VS. PHYSICS MODEL RESIDUALS
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs border border-slate-800 rounded-xl overflow-hidden">
              <thead className="bg-slate-900 text-slate-400 uppercase text-[10px]">
                <tr>
                  <th className="py-2.5 px-3">Transducer Channel</th>
                  <th className="py-2.5 px-3">Measured Live</th>
                  <th className="py-2.5 px-3">Physics Expected</th>
                  <th className="py-2.5 px-3">Residual Deviation</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 bg-slate-950/60">
                <tr>
                  <td className="py-2 px-3">Engine Core Speed</td>
                  <td className="py-2 px-3 text-cyan-300 font-bold">{telemetry.rpm} RPM</td>
                  <td className="py-2 px-3 text-slate-400">5100 RPM</td>
                  <td className="py-2 px-3 text-slate-400">{telemetry.rpm - 5100} RPM</td>
                  <td className="py-2 px-3 text-emerald-400">NOMINAL</td>
                </tr>
                <tr>
                  <td className="py-2 px-3">Engine Block Temp</td>
                  <td className="py-2 px-3 text-amber-300 font-bold">{telemetry.engineTemp} °C</td>
                  <td className="py-2 px-3 text-slate-400">{physics.expectedEngineTemp.toFixed(1)} °C</td>
                  <td className="py-2 px-3 text-amber-400 font-bold">+{physics.tempDeviation.toFixed(1)} °C</td>
                  <td className="py-2 px-3 text-amber-400">{telemetry.engineTemp > 105 ? 'ELEVATED' : 'NOMINAL'}</td>
                </tr>
                <tr>
                  <td className="py-2 px-3">Oil Gallery Pressure</td>
                  <td className="py-2 px-3 text-cyan-300 font-bold">{telemetry.oilPressure} PSI</td>
                  <td className="py-2 px-3 text-slate-400">{physics.expectedOilPressure.toFixed(1)} PSI</td>
                  <td className="py-2 px-3 text-rose-400 font-bold">{physics.pressureDeviation.toFixed(1)} PSI</td>
                  <td className="py-2 px-3 text-rose-400">{telemetry.oilPressure < 35 ? 'CRITICAL' : 'NOMINAL'}</td>
                </tr>
                <tr>
                  <td className="py-2 px-3">Mechanical Vibration</td>
                  <td className="py-2 px-3 text-purple-300 font-bold">{telemetry.vibration} mm/s</td>
                  <td className="py-2 px-3 text-slate-400">{physics.expectedVibration.toFixed(2)} mm/s</td>
                  <td className="py-2 px-3 text-purple-400 font-bold">+{physics.vibrationDeviation.toFixed(2)} mm/s</td>
                  <td className="py-2 px-3 text-purple-400">{telemetry.vibration > 4.5 ? 'WARNING' : 'NOMINAL'}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Explainable AI SHAP Attribution */}
        <div className="space-y-2">
          <h3 className="font-display font-bold text-sm text-cyan-400 uppercase tracking-wider">
            3. XAI FEATURE ATTRIBUTION & ROOT CAUSE
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono text-xs">
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-500 text-[10px] uppercase block mb-1">Inferred Probable Root Cause:</span>
              <p className="text-slate-300 font-sans">{aiAnalysis.probableRootCause}</p>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-500 text-[10px] uppercase block mb-1">Top SHAP Attributions:</span>
              <div className="space-y-1">
                {aiAnalysis.featureImportances.slice(0, 3).map((f, idx) => (
                  <div key={idx} className="flex justify-between">
                    <span className="text-slate-300">{f.displayName}:</span>
                    <strong className="text-cyan-400">{f.importance}%</strong>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* RUL & Maintenance Protocol */}
        <div className="space-y-2">
          <h3 className="font-display font-bold text-sm text-cyan-400 uppercase tracking-wider">
            4. PROGNOSTIC RUL & OPERATOR ACTION DIRECTIVE
          </h3>
          <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/30 font-mono text-xs space-y-2">
            <div className="flex justify-between text-slate-300">
              <span>Remaining Useful Life (RUL): <strong className="text-amber-300">{rul.remainingFlightHours} Flight Hours</strong></span>
              <span>Next Mandatory Inspection: <strong className="text-slate-200">{rul.estimatedDaysToMaintenance} cycles</strong></span>
            </div>
            <div className="pt-2 border-t border-cyan-500/20 text-slate-200 font-sans">
              <strong>Mandated Mitigation Directive:</strong> {aiAnalysis.recommendedMitigation}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
