/**
 * AEROTWIN AI - Interactive Animated Digital Twin Engine Visualization
 * 
 * High-fidelity 2D/pseudo-3D aerospace cross-section with real-time kinematic
 * simulation of pistons, crankshaft, combustion cycles, lubrication circuits,
 * thermal heatmaps, and component status highlights.
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Flame, 
  Droplet, 
  Wind, 
  Zap, 
  Activity, 
  Layers, 
  Sliders, 
  Info,
  Maximize2,
  ShieldCheck,
  AlertTriangle,
  RotateCw
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { SeverityLevel } from '../../types';

export const EngineVisualization: React.FC = () => {
  const { 
    telemetry, 
    physics, 
    componentHealth, 
    aiAnalysis, 
    faultInjection, 
    isPaused 
  } = useSimulation();

  const [crankAngle, setCrankAngle] = useState<number>(0);
  const [selectedComponent, setSelectedComponent] = useState<string>('cylinder');
  const [overlayMode, setOverlayMode] = useState<'mechanical' | 'thermal' | 'lubrication' | 'vibration'>('mechanical');
  const animRef = useRef<number | null>(null);

  // Animation Loop based on real-time RPM
  useEffect(() => {
    let lastTime = performance.now();

    const animate = (time: number) => {
      const delta = (time - lastTime) / 1000;
      lastTime = time;

      if (!isPaused) {
        // Rotational speed: RPM / 60 * 360 deg/sec
        // Scaled down visually for crisp legibility (approx 2-8 rev/sec)
        const visualSpeedScale = 0.04;
        const angleDelta = (telemetry.rpm * visualSpeedScale * 360) * delta;
        setCrankAngle(prev => (prev + angleDelta) % 360);
      }

      animRef.current = requestAnimationFrame(animate);
    };

    animRef.current = requestAnimationFrame(animate);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [telemetry.rpm, isPaused]);

  // Kinematic calculations for 2-cylinder boxer / 90-degree V configuration
  const rad = (crankAngle * Math.PI) / 180;
  const strokeLength = 32; // stroke travel in pixels
  const rodLength = 65; // connecting rod length

  // Left Piston (Cylinder 1)
  const leftPistonY = Math.cos(rad) * (strokeLength / 2);
  const isCombustionLeft = crankAngle >= 0 && crankAngle < 90;

  // Right Piston (Cylinder 2) with 180 deg phase
  const rad2 = ((crankAngle + 180) * Math.PI) / 180;
  const rightPistonY = Math.cos(rad2) * (strokeLength / 2);
  const isCombustionRight = crankAngle >= 180 && crankAngle < 270;

  // Thermal Heatmap Gradient Color
  const getThermalColor = (temp: number) => {
    if (temp < 90) return '#06b6d4'; // cyan cool
    if (temp < 105) return '#10b981'; // emerald normal
    if (temp < 118) return '#f59e0b'; // amber hot
    return '#f43f5e'; // rose critical overheat
  };

  const getStatusBorder = (status: SeverityLevel) => {
    if (status === 'critical') return 'stroke-rose-500 animate-pulse stroke-[3]';
    if (status === 'warning') return 'stroke-amber-400 stroke-[2]';
    if (status === 'monitor') return 'stroke-cyan-400 stroke-[1.5]';
    return 'stroke-emerald-400/60 stroke-[1]';
  };

  return (
    <div className="w-full bg-[#111115] rounded-xl border border-[#1E1E24] p-4 sm:p-6 shadow-md relative overflow-hidden">
      {/* Background HUD Tech Grid */}
      <div className="absolute inset-0 hud-grid opacity-20 pointer-events-none" />

      {/* Top Header & Overlay Switcher */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4 pb-3 border-b border-[#1E1E24]">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2.5 w-2.5 rounded-full bg-blue-500 animate-pulse" />
            <h2 className="font-display font-bold text-lg text-white tracking-wide flex items-center gap-2">
              UAV-150cc DIGITAL TWIN KINEMATICS
            </h2>
            <span className="px-2 py-0.5 rounded bg-blue-600/10 border border-blue-500/30 text-blue-400 text-[10px] font-mono">
              DYNAMIC CAD CROSS-SECTION
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Real-time multi-body kinematic displacement synced with {telemetry.rpm} RPM telemetry
          </p>
        </div>

        {/* Overlay Mode Switcher */}
        <div className="flex items-center bg-[#1A1A1F] border border-[#1E1E24] rounded-lg p-1 text-xs font-mono">
          <button
            id="btn-overlay-mech"
            onClick={() => setOverlayMode('mechanical')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-all ${
              overlayMode === 'mechanical' ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/30' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="h-3.5 w-3.5" />
            <span>MECHANICAL</span>
          </button>

          <button
            id="btn-overlay-thermal"
            onClick={() => setOverlayMode('thermal')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-all ${
              overlayMode === 'thermal' ? 'bg-amber-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Flame className="h-3.5 w-3.5" />
            <span>THERMAL</span>
          </button>

          <button
            id="btn-overlay-lub"
            onClick={() => setOverlayMode('lubrication')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-all ${
              overlayMode === 'lubrication' ? 'bg-blue-500 text-white font-bold shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Droplet className="h-3.5 w-3.5" />
            <span>LUBRICATION</span>
          </button>

          <button
            id="btn-overlay-vib"
            onClick={() => setOverlayMode('vibration')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-all ${
              overlayMode === 'vibration' ? 'bg-purple-500 text-white font-bold shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="h-3.5 w-3.5" />
            <span>VIBRATION</span>
          </button>
        </div>
      </div>

      {/* Main Digital Twin Interactive Stage & Component Inspector Grid */}
      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Left / Center: Interactive SVG Engine Schematic */}
        <div className="lg:col-span-8 flex flex-col items-center justify-center bg-black/40 rounded-xl border border-[#1E1E24] p-4 relative min-h-[380px]">
          {/* Real-time Status Overlay Pins */}
          <div className="absolute top-3 left-3 flex flex-wrap gap-2 text-[10px] font-mono">
            <span className="px-2 py-1 rounded bg-[#111115] border border-[#1E1E24] text-slate-300">
              CRANK ANGLE: <strong className="text-blue-400">{Math.round(crankAngle)}°</strong>
            </span>
            <span className="px-2 py-1 rounded bg-[#111115] border border-[#1E1E24] text-slate-300">
              SPEED: <strong className="text-emerald-400">{telemetry.rpm} RPM</strong>
            </span>
            <span className="px-2 py-1 rounded bg-[#111115] border border-[#1E1E24] text-slate-300">
              CORE TEMP: <strong style={{ color: getThermalColor(telemetry.engineTemp) }}>{telemetry.engineTemp}°C</strong>
            </span>
          </div>

          {/* SVG Twin Engine Cross Section */}
          <svg viewBox="0 0 520 380" className="w-full max-w-[480px] h-auto drop-shadow-2xl select-none">
            <defs>
              {/* Glow Filters */}
              <filter id="flameGlow" x="-50%" y="-50%" width="200%" height="200%">
                <feGaussianBlur stdDeviation="8" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <radialGradient id="combustionGrad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ffedd5" stopOpacity="1" />
                <stop offset="40%" stopColor="#f97316" stopOpacity="0.85" />
                <stop offset="100%" stopColor="#dc2626" stopOpacity="0" />
              </radialGradient>
              <linearGradient id="pistonGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#475569" />
                <stop offset="50%" stopColor="#64748b" />
                <stop offset="100%" stopColor="#334155" />
              </linearGradient>
              <linearGradient id="blockGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1e293b" />
                <stop offset="100%" stopColor="#0f172a" />
              </linearGradient>
              <linearGradient id="oilGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.8" />
                <stop offset="100%" stopColor="#0284c7" stopOpacity="0.4" />
              </linearGradient>
            </defs>

            {/* ENGINE BLOCK CASTING (Twin Boxer Engine Layout) */}
            <g id="engine-block" onClick={() => setSelectedComponent('cylinder')} className="cursor-pointer">
              {/* Outer crankcase */}
              <path
                d="M 190 200 L 190 320 Q 260 350 330 320 L 330 200 Z"
                fill="url(#blockGrad)"
                stroke="#475569"
                strokeWidth="2"
              />
              {/* Sump Pan */}
              <rect x="210" y="320" width="100" height="28" rx="4" fill="#0f172a" stroke="#334155" strokeWidth="1.5" />
              
              {/* Left Cylinder Barrel */}
              <rect 
                x="60" 
                y="145" 
                width="140" 
                height="100" 
                rx="6" 
                fill="url(#blockGrad)" 
                stroke={selectedComponent === 'cylinder' ? '#06b6d4' : '#475569'} 
                strokeWidth={selectedComponent === 'cylinder' ? '2.5' : '1.5'}
                className={getStatusBorder(componentHealth.cylinderSystem.status)}
              />
              {/* Left Cooling Fins */}
              {[-30, -15, 0, 15, 30].map((offset, i) => (
                <line key={`fin-l-${i}`} x1="50" y1={195 + offset} x2="60" y2={195 + offset} stroke="#64748b" strokeWidth="3" strokeLinecap="round" />
              ))}
              
              {/* Right Cylinder Barrel */}
              <rect 
                x="320" 
                y="145" 
                width="140" 
                height="100" 
                rx="6" 
                fill="url(#blockGrad)" 
                stroke={selectedComponent === 'cylinder' ? '#06b6d4' : '#475569'} 
                strokeWidth={selectedComponent === 'cylinder' ? '2.5' : '1.5'}
                className={getStatusBorder(componentHealth.cylinderSystem.status)}
              />
              {/* Right Cooling Fins */}
              {[-30, -15, 0, 15, 30].map((offset, i) => (
                <line key={`fin-r-${i}`} x1="460" y1={195 + offset} x2="470" y2={195 + offset} stroke="#64748b" strokeWidth="3" strokeLinecap="round" />
              ))}
            </g>

            {/* THERMAL HEATMAP OVERLAY MODE */}
            {overlayMode === 'thermal' && (
              <g id="thermal-overlay" opacity="0.6">
                <circle cx="110" cy="195" r="45" fill={getThermalColor(telemetry.cylinderHeadTemp)} filter="url(#flameGlow)" />
                <circle cx="410" cy="195" r="45" fill={getThermalColor(telemetry.cylinderHeadTemp)} filter="url(#flameGlow)" />
                <rect x="200" y="210" width="120" height="90" rx="8" fill={getThermalColor(telemetry.engineTemp)} filter="url(#flameGlow)" />
              </g>
            )}

            {/* LUBRICATION HYDRAULIC CIRCUIT OVERLAY */}
            {overlayMode === 'lubrication' && (
              <g id="oil-circuit">
                {/* Oil pump icon & lines */}
                <path
                  d="M 260 330 L 260 270 M 260 270 L 195 240 M 260 270 L 325 240 M 260 270 L 260 220"
                  fill="none"
                  stroke={telemetry.oilPressure < 30 ? '#f43f5e' : '#38bdf8'}
                  strokeWidth="4"
                  strokeDasharray="6 4"
                  strokeLinecap="round"
                  className="animate-pulse"
                />
                <circle cx="260" cy="330" r="8" fill="#0284c7" stroke="#38bdf8" strokeWidth="2" />
                <text x="275" y="334" fill="#38bdf8" fontSize="9" fontFamily="monospace">PUMP {telemetry.oilPressure} PSI</text>
              </g>
            )}

            {/* VIBRATION FIELD OVERLAY */}
            {overlayMode === 'vibration' && (
              <g id="vibration-overlay">
                <circle 
                  cx="260" 
                  cy="255" 
                  r={35 + telemetry.vibration * 4} 
                  fill="none" 
                  stroke={telemetry.vibration > 5.0 ? '#f43f5e' : '#a855f7'} 
                  strokeWidth="2" 
                  strokeDasharray="4 4"
                  className="animate-spin"
                />
                <circle 
                  cx="260" 
                  cy="255" 
                  r={50 + telemetry.vibration * 5} 
                  fill="none" 
                  stroke={telemetry.vibration > 5.0 ? '#f43f5e' : '#c084fc'} 
                  strokeWidth="1" 
                  opacity="0.4" 
                />
              </g>
            )}

            {/* LEFT COMBUSTION FLASH */}
            {isCombustionLeft && (
              <circle
                cx="80"
                cy="195"
                r="30"
                fill="url(#combustionGrad)"
                filter="url(#flameGlow)"
                className="animate-ping"
              />
            )}

            {/* RIGHT COMBUSTION FLASH */}
            {isCombustionRight && (
              <circle
                cx="440"
                cy="195"
                r="30"
                fill="url(#combustionGrad)"
                filter="url(#flameGlow)"
                className="animate-ping"
              />
            )}

            {/* LEFT PISTON (Reciprocates horizontally in Boxer) */}
            <g transform={`translate(${leftPistonY}, 0)`}>
              {/* Piston Head */}
              <rect
                x="85"
                y="160"
                width="48"
                height="70"
                rx="4"
                fill="url(#pistonGrad)"
                stroke="#94a3b8"
                strokeWidth="1.5"
              />
              {/* Piston Rings */}
              <line x1="90" y1="168" x2="90" y2="222" stroke="#1e293b" strokeWidth="2" />
              <line x1="96" y1="168" x2="96" y2="222" stroke="#1e293b" strokeWidth="2" />
              {/* Gudgeon Pin */}
              <circle cx="109" cy="195" r="5" fill="#cbd5e1" stroke="#475569" strokeWidth="1" />
            </g>

            {/* RIGHT PISTON (Reciprocates horizontally in Boxer) */}
            <g transform={`translate(${rightPistonY}, 0)`}>
              {/* Piston Head */}
              <rect
                x="387"
                y="160"
                width="48"
                height="70"
                rx="4"
                fill="url(#pistonGrad)"
                stroke="#94a3b8"
                strokeWidth="1.5"
              />
              {/* Piston Rings */}
              <line x1="430" y1="168" x2="430" y2="222" stroke="#1e293b" strokeWidth="2" />
              <line x1="424" y1="168" x2="424" y2="222" stroke="#1e293b" strokeWidth="2" />
              {/* Gudgeon Pin */}
              <circle cx="411" cy="195" r="5" fill="#cbd5e1" stroke="#475569" strokeWidth="1" />
            </g>

            {/* CRANKSHAFT & CONNECTING RODS */}
            <g id="crank-assembly" onClick={() => setSelectedComponent('bearing')} className="cursor-pointer">
              {/* Main Center Journal (Bearing System) */}
              <circle
                cx="260"
                cy="255"
                r="38"
                fill="#1e293b"
                stroke={selectedComponent === 'bearing' ? '#06b6d4' : '#64748b'}
                strokeWidth="2"
                className={getStatusBorder(componentHealth.bearingSystem.status)}
              />
              
              {/* Rotating Crank Web / Pin */}
              <g transform={`rotate(${crankAngle} 260 255)`}>
                {/* Crankshaft Counterweight */}
                <path
                  d="M 245 255 A 32 32 0 0 0 275 255 L 285 285 A 36 36 0 0 1 235 285 Z"
                  fill="#475569"
                  stroke="#94a3b8"
                  strokeWidth="1"
                />
                {/* Crankpin Left */}
                <circle cx="260" cy="235" r="8" fill="#e2e8f0" stroke="#0f172a" strokeWidth="1.5" />
                {/* Crankpin Right */}
                <circle cx="260" cy="275" r="8" fill="#e2e8f0" stroke="#0f172a" strokeWidth="1.5" />
              </g>

              {/* Connecting Rod Left */}
              <line
                x1={109 + leftPistonY}
                y1="195"
                x2={260 + Math.sin(rad) * (strokeLength / 2)}
                y2={255 - Math.cos(rad) * (strokeLength / 2)}
                stroke="#94a3b8"
                strokeWidth="7"
                strokeLinecap="round"
              />
              <line
                x1={109 + leftPistonY}
                y1="195"
                x2={260 + Math.sin(rad) * (strokeLength / 2)}
                y2={255 - Math.cos(rad) * (strokeLength / 2)}
                stroke="#0f172a"
                strokeWidth="2"
                strokeLinecap="round"
              />

              {/* Connecting Rod Right */}
              <line
                x1={411 + rightPistonY}
                y1="195"
                x2={260 + Math.sin(rad2) * (strokeLength / 2)}
                y2={255 - Math.cos(rad2) * (strokeLength / 2)}
                stroke="#94a3b8"
                strokeWidth="7"
                strokeLinecap="round"
              />
              <line
                x1={411 + rightPistonY}
                y1="195"
                x2={260 + Math.sin(rad2) * (strokeLength / 2)}
                y2={255 - Math.cos(rad2) * (strokeLength / 2)}
                stroke="#0f172a"
                strokeWidth="2"
                strokeLinecap="round"
              />

              {/* Center Main Journal Center Cap */}
              <circle cx="260" cy="255" r="14" fill="#0f172a" stroke="#38bdf8" strokeWidth="2" />
            </g>

            {/* FUEL INJECTOR NOZZLES (TOP CYLINDER INTAKE) */}
            <g id="fuel-injectors" onClick={() => setSelectedComponent('fuel')} className="cursor-pointer">
              {/* Left Injector */}
              <rect x="75" y="115" width="10" height="25" fill="#f59e0b" stroke="#78350f" strokeWidth="1" rx="2" />
              <path d="M 77 140 L 80 152 L 83 140 Z" fill="#fbbf24" opacity={isCombustionLeft ? '1' : '0.2'} />
              {/* Right Injector */}
              <rect x="435" y="115" width="10" height="25" fill="#f59e0b" stroke="#78350f" strokeWidth="1" rx="2" />
              <path d="M 437 140 L 440 152 L 443 140 Z" fill="#fbbf24" opacity={isCombustionRight ? '1' : '0.2'} />
            </g>

            {/* SPARK PLUGS & IGNITION COILS */}
            <g id="spark-plugs" onClick={() => setSelectedComponent('ignition')} className="cursor-pointer">
              <rect x="45" y="188" width="14" height="14" fill="#38bdf8" stroke="#0369a1" strokeWidth="1" rx="2" />
              <rect x="461" y="188" width="14" height="14" fill="#38bdf8" stroke="#0369a1" strokeWidth="1" rx="2" />
            </g>

            {/* Click Targets & Component Labels */}
            <text x="75" y="98" fill="#94a3b8" fontSize="10" fontFamily="monospace" textAnchor="middle">CYLINDER #1</text>
            <text x="445" y="98" fill="#94a3b8" fontSize="10" fontFamily="monospace" textAnchor="middle">CYLINDER #2</text>
            <text x="260" y="370" fill="#94a3b8" fontSize="10" fontFamily="monospace" textAnchor="middle">MAIN JOURNAL & SUMP</text>
          </svg>

          {/* Interactive Component Legend Bar */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-2 pt-2 border-t border-[#1E1E24] text-xs font-mono">
            <button
              onClick={() => setSelectedComponent('cylinder')}
              className={`px-2.5 py-1 rounded-md border transition-all ${
                selectedComponent === 'cylinder' ? 'bg-blue-600/20 border-blue-500 text-blue-300 font-bold' : 'border-[#1E1E24] bg-[#1A1A1F] text-slate-400 hover:text-slate-200'
              }`}
            >
              Cylinders ({componentHealth.cylinderSystem.healthScore}%)
            </button>
            <button
              onClick={() => setSelectedComponent('bearing')}
              className={`px-2.5 py-1 rounded-md border transition-all ${
                selectedComponent === 'bearing' ? 'bg-blue-600/20 border-blue-500 text-blue-300 font-bold' : 'border-[#1E1E24] bg-[#1A1A1F] text-slate-400 hover:text-slate-200'
              }`}
            >
              Bearings ({componentHealth.bearingSystem.healthScore}%)
            </button>
            <button
              onClick={() => setSelectedComponent('lubrication')}
              className={`px-2.5 py-1 rounded-md border transition-all ${
                selectedComponent === 'lubrication' ? 'bg-blue-600/20 border-blue-500 text-blue-300 font-bold' : 'border-[#1E1E24] bg-[#1A1A1F] text-slate-400 hover:text-slate-200'
              }`}
            >
              Lubrication ({componentHealth.lubricationSystem.healthScore}%)
            </button>
            <button
              onClick={() => setSelectedComponent('cooling')}
              className={`px-2.5 py-1 rounded-md border transition-all ${
                selectedComponent === 'cooling' ? 'bg-blue-600/20 border-blue-500 text-blue-300 font-bold' : 'border-[#1E1E24] bg-[#1A1A1F] text-slate-400 hover:text-slate-200'
              }`}
            >
              Cooling ({componentHealth.coolingSystem.healthScore}%)
            </button>
            <button
              onClick={() => setSelectedComponent('fuel')}
              className={`px-2.5 py-1 rounded-md border transition-all ${
                selectedComponent === 'fuel' ? 'bg-blue-600/20 border-blue-500 text-blue-300 font-bold' : 'border-[#1E1E24] bg-[#1A1A1F] text-slate-400 hover:text-slate-200'
              }`}
            >
              Fuel EFI ({componentHealth.fuelSystem.healthScore}%)
            </button>
          </div>
        </div>

        {/* Right: Selected Component Detailed Digital Twin Inspector */}
        <div className="lg:col-span-4 flex flex-col space-y-4">
          {(() => {
            const comp = 
              selectedComponent === 'cylinder' ? componentHealth.cylinderSystem :
              selectedComponent === 'bearing' ? componentHealth.bearingSystem :
              selectedComponent === 'lubrication' ? componentHealth.lubricationSystem :
              selectedComponent === 'cooling' ? componentHealth.coolingSystem :
              selectedComponent === 'fuel' ? componentHealth.fuelSystem :
              componentHealth.ignitionSystem;

            return (
              <div className="rounded-xl border border-[#1E1E24] bg-[#111115] p-4 shadow-md">
                <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
                  <div>
                    <span className="text-[10px] font-mono uppercase text-slate-400">DIGITAL TWIN INSPECTOR</span>
                    <h3 className="font-display font-bold text-base text-white">{comp.name}</h3>
                  </div>
                  <span className={`text-xs font-mono uppercase px-2 py-0.5 rounded border ${
                    comp.status === 'healthy' ? 'bg-emerald-950/40 border-emerald-900 text-emerald-400' :
                    comp.status === 'monitor' ? 'bg-blue-950/40 border-blue-900 text-blue-300' :
                    comp.status === 'warning' ? 'bg-amber-950/40 border-amber-900 text-amber-300 animate-pulse' :
                    'bg-red-950/50 border-red-900 text-red-300 font-bold animate-pulse'
                  }`}>
                    {comp.status}
                  </span>
                </div>

                {/* Health Score & Degradation */}
                <div className="grid grid-cols-2 gap-3 my-3 font-mono">
                  <div className="p-2.5 rounded-lg bg-black/30 border border-white/5">
                    <span className="text-[10px] text-slate-400 uppercase">Health Score</span>
                    <div className="text-xl font-bold font-display mt-0.5 text-emerald-400">
                      {comp.healthScore}%
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
                      <div
                        className={`h-full ${comp.healthScore > 80 ? 'bg-emerald-500' : comp.healthScore > 50 ? 'bg-amber-500' : 'bg-red-500'}`}
                        style={{ width: `${comp.healthScore}%` }}
                      />
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-black/30 border border-white/5">
                    <span className="text-[10px] text-slate-400 uppercase">RUL Estimate</span>
                    <div className="text-xl font-bold font-display mt-0.5 text-amber-400">
                      {comp.estimatedRULHours}h
                    </div>
                    <span className="text-[10px] text-slate-400">Deg: {comp.degradationRate}%/hr</span>
                  </div>
                </div>

                {/* Telemetry vs Expected */}
                <div className="space-y-2 text-xs font-mono bg-black/30 p-3 rounded-lg border border-white/5 mb-3">
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-400">{comp.currentMetricLabel}:</span>
                    <strong className="text-white">{comp.currentMetricValue}</strong>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Physics Baseline:</span>
                    <span className="text-blue-400">{comp.expectedMetricValue}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Fault Probability:</span>
                    <span className={comp.faultProbability > 40 ? 'text-red-400 font-bold' : 'text-slate-300'}>
                      {comp.faultProbability}%
                    </span>
                  </div>
                </div>

                {/* Sub-components Tree */}
                {comp.subcomponents && comp.subcomponents.length > 0 && (
                  <div className="space-y-1.5 mb-3">
                    <span className="text-[10px] font-mono uppercase text-slate-400 block">Subcomponents Hierarchy:</span>
                    {comp.subcomponents.map((sub, i) => (
                      <div key={i} className="flex items-center justify-between text-xs font-mono p-1.5 rounded bg-black/20 border border-white/5">
                        <span className="text-slate-300">{sub.name}</span>
                        <span className="text-blue-400 font-bold">{sub.health}%</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Recommended Maintenance Action */}
                <div className="p-2.5 rounded-lg bg-amber-950/20 border border-amber-900 text-xs text-amber-200 leading-relaxed font-sans">
                  <strong className="font-mono text-[10px] uppercase text-amber-400 block mb-0.5">Recommended Action:</strong>
                  {comp.recommendedAction}
                </div>
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
};
