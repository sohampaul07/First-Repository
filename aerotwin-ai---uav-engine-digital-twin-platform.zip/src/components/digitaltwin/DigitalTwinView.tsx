/**
 * AEROTWIN AI - Dedicated Digital Twin Workbench View
 */

import React from 'react';
import { 
  Settings2, 
  Layers, 
  Cpu, 
  Activity, 
  Flame, 
  Droplet, 
  Zap, 
  CheckCircle2, 
  AlertTriangle,
  ArrowRight,
  TrendingDown
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { EngineVisualization } from './EngineVisualization';

export const DigitalTwinView: React.FC = () => {
  const { telemetry, physics, componentHealth, aiAnalysis, setActiveView } = useSimulation();

  const physicsComparisonRows = [
    {
      parameter: 'Engine Core Temperature',
      actual: `${telemetry.engineTemp.toFixed(1)} °C`,
      expected: `${physics.expectedEngineTemp.toFixed(1)} °C`,
      deviation: `${physics.tempDeviation > 0 ? '+' : ''}${physics.tempDeviation.toFixed(1)} °C`,
      status: Math.abs(physics.tempDeviation) > 15 ? 'ANOMALY' : Math.abs(physics.tempDeviation) > 8 ? 'WARNING' : 'NOMINAL',
      formula: 'Q_in(RPM, throttle) - Q_cool(airflow, delta_T)',
    },
    {
      parameter: 'Oil Gallery Pressure',
      actual: `${telemetry.oilPressure.toFixed(1)} PSI`,
      expected: `${physics.expectedOilPressure.toFixed(1)} PSI`,
      deviation: `${physics.pressureDeviation > 0 ? '+' : ''}${physics.pressureDeviation.toFixed(1)} PSI`,
      status: physics.pressureDeviation < -15 ? 'ANOMALY' : physics.pressureDeviation < -8 ? 'WARNING' : 'NOMINAL',
      formula: 'k_pump * RPM - mu_viscosity(T_oil)',
    },
    {
      parameter: 'Mechanical Vibration',
      actual: `${telemetry.vibration.toFixed(2)} mm/s`,
      expected: `${physics.expectedVibration.toFixed(2)} mm/s`,
      deviation: `${physics.vibrationDeviation > 0 ? '+' : ''}${physics.vibrationDeviation.toFixed(2)} mm/s`,
      status: physics.vibrationDeviation > 2.0 ? 'ANOMALY' : physics.vibrationDeviation > 1.0 ? 'WARNING' : 'NOMINAL',
      formula: 'sqrt(w_1X^2 + w_2X^2) unbalance spectrum',
    },
    {
      parameter: 'Fuel Mass Flow Rate',
      actual: `${telemetry.fuelFlow.toFixed(1)} L/h`,
      expected: `${physics.expectedFuelFlow.toFixed(1)} L/h`,
      deviation: `${physics.fuelDeviation > 0 ? '+' : ''}${physics.fuelDeviation.toFixed(1)} L/h`,
      status: Math.abs(physics.fuelDeviation) > 2.0 ? 'ANOMALY' : 'NOMINAL',
      formula: 'V_disp * (RPM/2) * eta_v * rho_air / AFR',
    },
    {
      parameter: 'Cylinder Head Temp (CHT)',
      actual: `${telemetry.cylinderHeadTemp.toFixed(1)} °C`,
      expected: `${physics.expectedCHT.toFixed(1)} °C`,
      deviation: `${(telemetry.cylinderHeadTemp - physics.expectedCHT).toFixed(1)} °C`,
      status: telemetry.cylinderHeadTemp > 185 ? 'ANOMALY' : 'NOMINAL',
      formula: 'Combustion envelope localized dissipation',
    },
    {
      parameter: 'Exhaust Gas Temp (EGT)',
      actual: `${telemetry.exhaustGasTemp.toFixed(0)} °C`,
      expected: `${physics.expectedEGT.toFixed(0)} °C`,
      deviation: `${(telemetry.exhaustGasTemp - physics.expectedEGT).toFixed(0)} °C`,
      status: telemetry.exhaustGasTemp > 820 ? 'WARNING' : 'NOMINAL',
      formula: 'Isochoric flame temperature model',
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner Overview */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              PHYSICS + AI HYBRID DIGITAL TWIN
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
              CLOSED-LOOP TELEMETRY TWIN
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Continuous cross-correlation between physical mathematical models and machine learning inference
          </p>
        </div>

        {/* Efficiency & Stress Gauges */}
        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center space-x-2">
            <span className="text-slate-400">Thermal Efficiency:</span>
            <strong className="text-cyan-400 font-display text-sm">{physics.thermalEfficiency}%</strong>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center space-x-2">
            <span className="text-slate-400">Stress Index:</span>
            <strong className={physics.stressFactor > 0.75 ? 'text-amber-400 font-display text-sm' : 'text-emerald-400 font-display text-sm'}>
              {(physics.stressFactor * 100).toFixed(0)}%
            </strong>
          </div>
        </div>
      </div>

      {/* Main Kinematic Visualization */}
      <EngineVisualization />

      {/* Actual vs Expected Digital Twin Physics Comparison Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Layers className="h-4 w-4" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base text-slate-100">
                ACTUAL SENSORS VS. PHYSICS DIGITAL TWIN BASELINE
              </h3>
              <p className="text-xs font-mono text-slate-400">
                Mathematical residual computation powering AI anomaly detection
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveView('ai_intelligence')}
            className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            <span>VIEW XAI INFERENCE</span>
            <ArrowRight className="h-3 w-3" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-slate-800/80 text-slate-400 uppercase text-[10px]">
                <th className="pb-3 px-3">Telemetry Parameter</th>
                <th className="pb-3 px-3">Live Actual</th>
                <th className="pb-3 px-3">Physics Expected</th>
                <th className="pb-3 px-3">Residual (Δ Delta)</th>
                <th className="pb-3 px-3">Twin Status</th>
                <th className="pb-3 px-3">Governing Physical Law / Model</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {physicsComparisonRows.map((row, i) => (
                <tr key={i} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3 px-3 font-semibold text-slate-200">{row.parameter}</td>
                  <td className="py-3 px-3 text-cyan-300 font-bold">{row.actual}</td>
                  <td className="py-3 px-3 text-slate-400">{row.expected}</td>
                  <td className={`py-3 px-3 font-bold ${
                    row.status === 'ANOMALY' ? 'text-rose-400' : row.status === 'WARNING' ? 'text-amber-400' : 'text-emerald-400'
                  }`}>
                    {row.deviation}
                  </td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded-full border text-[10px] ${
                      row.status === 'ANOMALY' ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse font-bold' :
                      row.status === 'WARNING' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' :
                      'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                    }`}>
                      {row.status}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-[11px] text-slate-500 italic truncate max-w-xs">
                    {row.formula}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
