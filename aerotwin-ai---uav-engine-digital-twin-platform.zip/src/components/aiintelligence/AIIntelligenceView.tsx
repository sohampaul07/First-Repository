/**
 * AEROTWIN AI - Explainable AI (XAI) Intelligence Center
 */

import React, { useState } from 'react';
import { 
  BrainCircuit, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  HelpCircle, 
  Layers, 
  Cpu, 
  RefreshCw, 
  Sliders, 
  ArrowRight,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { AIService, GeminiDiagnosticResponse } from '../../services/aiService';

export const AIIntelligenceView: React.FC = () => {
  const { 
    telemetry, 
    physics, 
    aiAnalysis, 
    componentHealth, 
    setActiveView 
  } = useSimulation();

  const [geminiResult, setGeminiResult] = useState<GeminiDiagnosticResponse | null>(null);
  const [isLoadingGemini, setIsLoadingGemini] = useState<boolean>(false);

  const handleFetchGeminiDiagnostics = async () => {
    setIsLoadingGemini(true);
    try {
      const res = await AIService.fetchDeepDiagnostics(
        telemetry,
        physics,
        aiAnalysis,
        componentHealth
      );
      setGeminiResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingGemini(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-purple-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              EXPLAINABLE AI (XAI) REASONING CENTER
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 border border-purple-500/40 text-purple-300">
              SHAP ATTRIBUTION & ROOT CAUSE
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Transparent algorithmic reasoning, feature importance ranking, and physics-model cross validation
          </p>
        </div>

        <button
          id="btn-gemini-deep-diagnostics"
          onClick={handleFetchGeminiDiagnostics}
          disabled={isLoadingGemini}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-purple-950/50 transition-all shrink-0"
        >
          {isLoadingGemini ? (
            <>
              <RefreshCw className="h-4 w-4 animate-spin" />
              <span>QUERYING GEMINI 2.5 FLASH...</span>
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4" />
              <span>REQUEST GEMINI AEROSPACE DIAGNOSTICS</span>
            </>
          )}
        </button>
      </div>

      {/* Main 2-Column Grid: AI Conclusion + Feature Importance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: AI Conclusion & Detected Pattern */}
        <div className="lg:col-span-7 space-y-5">
          {/* Main Conclusion Box */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 backdrop-blur-md shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
                  <BrainCircuit className="h-4 w-4" />
                </div>
                <h3 className="font-display font-bold text-base text-slate-100">
                  AI DIAGNOSTIC CONCLUSION
                </h3>
              </div>
              <span className={`text-xs font-mono uppercase px-3 py-1 rounded-full border font-bold ${
                aiAnalysis.urgency === 'NOMINAL' ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300' :
                aiAnalysis.urgency === 'MONITOR' ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300' :
                aiAnalysis.urgency === 'HIGH' ? 'bg-amber-500/20 border-amber-500/40 text-amber-300' :
                'bg-rose-500/30 border-rose-500/50 text-rose-300 animate-pulse'
              }`}>
                {aiAnalysis.confidence}% CONFIDENCE
              </span>
            </div>

            <div className="my-4">
              <span className="text-[10px] font-mono uppercase text-slate-400">Classified Fault State:</span>
              <div className="font-display text-2xl font-bold text-slate-100 mt-0.5">
                {aiAnalysis.detectedFault}
              </div>
            </div>

            {/* Detected Pattern Bullets */}
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2 mb-4">
              <span className="text-xs font-mono font-semibold text-cyan-400 uppercase block">
                Detected Telemetry Patterns & Physics Deviations:
              </span>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {aiAnalysis.detectedPatterns.map((pat, i) => (
                  <li key={i} className="flex items-start space-x-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                    <span>{pat}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Root Cause Reasoning */}
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
              <span className="text-xs font-mono font-semibold text-purple-300 uppercase block">
                Probable Thermo-Mechanical Root Cause:
              </span>
              <p className="text-xs text-slate-300 leading-relaxed font-sans">
                {aiAnalysis.probableRootCause}
              </p>
            </div>

            {/* Affected Subsystems */}
            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400">Affected Nodes:</span>
              <div className="flex flex-wrap gap-1.5">
                {aiAnalysis.affectedComponents.map((comp, i) => (
                  <span key={i} className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 text-[11px]">
                    {comp}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Gemini AI Live Diagnostics Output Box */}
          {geminiResult && (
            <div className="rounded-2xl border border-purple-500/40 bg-gradient-to-br from-purple-950/40 to-slate-900/90 p-5 backdrop-blur-md shadow-xl animate-in fade-in">
              <div className="flex items-center justify-between pb-3 border-b border-purple-500/30">
                <div className="flex items-center space-x-2">
                  <Sparkles className="h-4 w-4 text-purple-400" />
                  <h3 className="font-display font-bold text-sm text-purple-200">
                    GEMINI 2.5 FLASH AEROSPACE REASONING
                  </h3>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-900/60 text-purple-300 border border-purple-500/40">
                  {geminiResult.source}
                </span>
              </div>
              <div className="mt-3 text-xs text-slate-200 leading-relaxed space-y-2 font-sans whitespace-pre-line">
                {geminiResult.diagnosticInsight}
              </div>
            </div>
          )}
        </div>

        {/* Right: SHAP Feature Importance Ranking */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-800 bg-slate-900/90 p-5 backdrop-blur-md shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div className="flex items-center space-x-2">
                <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  <Layers className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-base text-slate-100">
                    FEATURE IMPORTANCE ATTRIBUTION
                  </h3>
                  <span className="text-[10px] font-mono text-slate-400">
                    SHAP Anomaly Contribution Ranking
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              {aiAnalysis.featureImportances.map((feat, i) => (
                <div key={feat.feature} className="space-y-1.5 font-mono text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">
                      {i + 1}. {feat.displayName}
                    </span>
                    <div className="flex items-center space-x-2">
                      <span className="text-slate-400">
                        {feat.value} {feat.unit}
                      </span>
                      <strong className={
                        feat.contributionDirection === 'increases_risk' ? 'text-amber-400 font-bold' : 'text-slate-300'
                      }>
                        {feat.importance}%
                      </strong>
                    </div>
                  </div>

                  {/* Horizontal Bar */}
                  <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full transition-all duration-500 ${
                        feat.importance > 35 ? 'bg-gradient-to-r from-amber-500 to-rose-500' :
                        feat.importance > 20 ? 'bg-gradient-to-r from-cyan-500 to-blue-500' :
                        'bg-slate-600'
                      }`}
                      style={{ width: `${feat.importance}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">Explore in Simulation Lab:</span>
            <button
              onClick={() => setActiveView('fault_injection')}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 font-bold text-xs transition-colors"
            >
              Adjust Feature Sliders →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
