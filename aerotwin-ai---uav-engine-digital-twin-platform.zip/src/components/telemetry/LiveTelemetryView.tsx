/**
 * AEROTWIN AI - Live Telemetry Page
 * 
 * Multi-channel streaming telemetry studio with oscilloscope line charts,
 * physical limit indicators, pause/resume, speed selection, and individual sensor deep inspection.
 */

import React, { useState } from 'react';
import { 
  Activity, 
  Flame, 
  Droplet, 
  Zap, 
  Fuel, 
  Gauge, 
  Thermometer, 
  Play, 
  Pause, 
  Sliders, 
  BarChart2, 
  CheckCircle2, 
  AlertTriangle,
  ZoomIn
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { MetricCard } from '../common/MetricCard';

export const LiveTelemetryView: React.FC = () => {
  const { 
    telemetry, 
    telemetryHistory, 
    physics, 
    isPaused, 
    togglePause, 
    simulationSpeed, 
    setSimulationSpeed 
  } = useSimulation();

  const [selectedSensorKey, setSelectedSensorKey] = useState<
    'rpm' | 'engineTemp' | 'oilPressure' | 'vibration' | 'oilTemp' | 'fuelFlow' | 'cylinderHeadTemp' | 'exhaustGasTemp'
  >('engineTemp');

  const sensorDefinitions = [
    {
      key: 'rpm' as const,
      label: 'Engine RPM',
      unit: 'RPM',
      icon: Activity,
      value: telemetry.rpm,
      expected: 5100,
      minSafe: 3800,
      maxSafe: 6200,
      minGraph: 2000,
      maxGraph: 7000,
      color: '#06b6d4',
      desc: 'Rotational speed of twin crankshaft assembly measured by optical hall sensor.',
    },
    {
      key: 'engineTemp' as const,
      label: 'Engine Block Temperature',
      unit: '°C',
      icon: Flame,
      value: telemetry.engineTemp,
      expected: physics.expectedEngineTemp,
      minSafe: 80,
      maxSafe: 105,
      minGraph: 50,
      maxGraph: 140,
      color: '#f59e0b',
      desc: 'Core aluminum cylinder block temperature measured via embedded thermocouple.',
    },
    {
      key: 'oilPressure' as const,
      label: 'Oil Gallery Pressure',
      unit: 'PSI',
      icon: Droplet,
      value: telemetry.oilPressure,
      expected: physics.expectedOilPressure,
      minSafe: 40,
      maxSafe: 75,
      minGraph: 0,
      maxGraph: 100,
      color: '#38bdf8',
      desc: 'Hydrodynamic oil pressure delivered by positive displacement gear pump.',
    },
    {
      key: 'vibration' as const,
      label: 'Mechanical Vibration',
      unit: 'mm/s',
      icon: Zap,
      value: telemetry.vibration,
      expected: physics.expectedVibration,
      minSafe: 1.0,
      maxSafe: 3.8,
      minGraph: 0,
      maxGraph: 10,
      color: '#a855f7',
      desc: 'Broadband triaxial accelerometer vibration spectrum (1X/2X shaft harmonics).',
    },
    {
      key: 'oilTemp' as const,
      label: 'Oil Sump Temperature',
      unit: '°C',
      icon: Thermometer,
      value: telemetry.oilTemp,
      expected: physics.expectedOilTemp,
      minSafe: 70,
      maxSafe: 98,
      minGraph: 40,
      maxGraph: 130,
      color: '#ec4899',
      desc: 'Lubricant sump fluid temperature affecting kinematic shear viscosity.',
    },
    {
      key: 'fuelFlow' as const,
      label: 'Fuel Mass Flow Rate',
      unit: 'L/h',
      icon: Fuel,
      value: telemetry.fuelFlow,
      expected: physics.expectedFuelFlow,
      minSafe: 4.0,
      maxSafe: 8.5,
      minGraph: 0,
      maxGraph: 14,
      color: '#10b981',
      desc: 'Real-time electronic fuel injection delivery calculated from injector pulse width.',
    },
    {
      key: 'cylinderHeadTemp' as const,
      label: 'Cylinder Head Temp (CHT)',
      unit: '°C',
      icon: Gauge,
      value: telemetry.cylinderHeadTemp,
      expected: physics.expectedCHT,
      minSafe: 125,
      maxSafe: 180,
      minGraph: 100,
      maxGraph: 230,
      color: '#ef4444',
      desc: 'Combustion chamber spark plug ring gasket temperature transducer.',
    },
    {
      key: 'exhaustGasTemp' as const,
      label: 'Exhaust Gas Temp (EGT)',
      unit: '°C',
      icon: Flame,
      value: telemetry.exhaustGasTemp,
      expected: physics.expectedEGT,
      minSafe: 620,
      maxSafe: 800,
      minGraph: 500,
      maxGraph: 950,
      color: '#f97316',
      desc: 'Exhaust runner pyrometer thermocouple measuring air-fuel combustion temperature.',
    },
  ];

  const activeSensor = sensorDefinitions.find(s => s.key === selectedSensorKey)!;

  // Render SVG Line Oscilloscope Chart
  const renderOscilloscope = () => {
    if (telemetryHistory.length < 2) return null;
    const width = 760;
    const height = 240;
    const padding = { top: 20, right: 30, bottom: 30, left: 50 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    const data = telemetryHistory.map(t => t[selectedSensorKey]);
    const minVal = activeSensor.minGraph;
    const maxVal = activeSensor.maxGraph;
    const range = maxVal - minVal || 1;

    const points = data.map((val, i) => {
      const x = padding.left + (i / (data.length - 1)) * chartW;
      const y = padding.top + chartH - ((val - minVal) / range) * chartH;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');

    // Safe bounds Y coordinates
    const safeMinY = padding.top + chartH - ((activeSensor.minSafe - minVal) / range) * chartH;
    const safeMaxY = padding.top + chartH - ((activeSensor.maxSafe - minVal) / range) * chartH;

    // Expected physics baseline Y coordinate
    const expectedY = padding.top + chartH - ((activeSensor.expected - minVal) / range) * chartH;

    return (
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible select-none">
        <defs>
          <linearGradient id="scopeAreaGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor={activeSensor.color} stopOpacity="0.3" />
            <stop offset="100%" stopColor={activeSensor.color} stopOpacity="0.0" />
          </linearGradient>
        </defs>

        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((frac, idx) => {
          const y = padding.top + chartH * (1 - frac);
          const gridVal = Math.round(minVal + frac * range);
          return (
            <g key={idx}>
              <line
                x1={padding.left}
                y1={y}
                x2={padding.left + chartW}
                y2={y}
                stroke="#1e293b"
                strokeDasharray="4 4"
              />
              <text x={padding.left - 8} y={y + 3} fill="#64748b" fontSize="10" fontFamily="monospace" textAnchor="end">
                {gridVal}
              </text>
            </g>
          );
        })}

        {/* Normal Safe Operating Range Zone */}
        <rect
          x={padding.left}
          y={Math.min(safeMinY, safeMaxY)}
          width={chartW}
          height={Math.abs(safeMinY - safeMaxY)}
          fill="#10b981"
          opacity="0.06"
        />
        <line
          x1={padding.left}
          y1={safeMaxY}
          x2={padding.left + chartW}
          y2={safeMaxY}
          stroke="#10b981"
          strokeDasharray="6 3"
          strokeWidth="1"
          opacity="0.5"
        />
        <text x={padding.left + chartW - 5} y={safeMaxY - 4} fill="#10b981" fontSize="9" fontFamily="monospace" textAnchor="end">
          Safe Max: {activeSensor.maxSafe} {activeSensor.unit}
        </text>

        <line
          x1={padding.left}
          y1={safeMinY}
          x2={padding.left + chartW}
          y2={safeMinY}
          stroke="#10b981"
          strokeDasharray="6 3"
          strokeWidth="1"
          opacity="0.5"
        />
        <text x={padding.left + chartW - 5} y={safeMinY + 12} fill="#10b981" fontSize="9" fontFamily="monospace" textAnchor="end">
          Safe Min: {activeSensor.minSafe} {activeSensor.unit}
        </text>

        {/* Expected Physics Baseline Line */}
        <line
          x1={padding.left}
          y1={expectedY}
          x2={padding.left + chartW}
          y2={expectedY}
          stroke="#38bdf8"
          strokeDasharray="3 3"
          strokeWidth="1.5"
          opacity="0.8"
        />
        <text x={padding.left + 8} y={expectedY - 4} fill="#38bdf8" fontSize="9" fontFamily="monospace">
          Physics Model: {activeSensor.expected} {activeSensor.unit}
        </text>

        {/* Data Stream Area Fill */}
        <polygon
          points={`${padding.left},${padding.top + chartH} ${points} ${padding.left + chartW},${padding.top + chartH}`}
          fill="url(#scopeAreaGrad)"
        />

        {/* Data Stream Line */}
        <polyline
          points={points}
          fill="none"
          stroke={activeSensor.color}
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Current Live Value Head Point */}
        {data.length > 0 && (
          <circle
            cx={padding.left + chartW}
            cy={padding.top + chartH - ((data[data.length - 1] - minVal) / range) * chartH}
            r="4.5"
            fill={activeSensor.color}
            stroke="#0f172a"
            strokeWidth="2"
            className="animate-ping"
          />
        )}
      </svg>
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Studio Header Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              HIGH-RATE TELEMETRY & DIGITAL ACQUISITION
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
              100 Hz SAMPLING
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Streaming real-time aerodynamic and thermo-mechanical telemetry vectors
          </p>
        </div>

        {/* Stream Playback Controls */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center bg-slate-950 border border-slate-800 rounded-lg p-1 text-xs font-mono">
            <span className="px-2 text-slate-500 text-[10px]">RATE:</span>
            {[1, 2, 5, 10].map(s => (
              <button
                key={s}
                onClick={() => setSimulationSpeed(s)}
                className={`px-2 py-0.5 rounded ${simulationSpeed === s ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400'}`}
              >
                {s}x
              </button>
            ))}
          </div>

          <button
            onClick={togglePause}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border text-xs font-mono font-medium transition-all ${
              isPaused ? 'bg-amber-500/20 border-amber-500/40 text-amber-300' : 'bg-slate-950 border-slate-800 text-slate-300 hover:text-slate-100'
            }`}
          >
            {isPaused ? <Play className="h-3.5 w-3.5 fill-amber-300" /> : <Pause className="h-3.5 w-3.5" />}
            <span>{isPaused ? 'RESUME STREAM' : 'PAUSE ACQUISITION'}</span>
          </button>
        </div>
      </div>

      {/* Main Expanded Oscilloscope View */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-slate-800/80">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-cyan-400">
              {React.createElement(activeSensor.icon, { className: 'h-5 w-5' })}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-mono text-xs text-slate-400 uppercase">CHANNEL INSPECTOR:</span>
                <h3 className="font-display font-bold text-lg text-slate-100">{activeSensor.label}</h3>
              </div>
              <p className="text-xs text-slate-400 font-mono mt-0.5">{activeSensor.desc}</p>
            </div>
          </div>

          <div className="flex items-baseline space-x-2 bg-slate-900 px-4 py-2 rounded-xl border border-slate-800">
            <span className="text-xs font-mono text-slate-400">LIVE:</span>
            <span className="font-display text-2xl font-bold" style={{ color: activeSensor.color }}>
              {activeSensor.value}
            </span>
            <span className="text-xs font-mono text-slate-400">{activeSensor.unit}</span>
          </div>
        </div>

        {/* SVG Oscilloscope */}
        <div className="w-full overflow-x-auto">
          {renderOscilloscope()}
        </div>

        {/* Oscilloscope Legend */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs font-mono text-slate-400 gap-3">
          <div className="flex items-center space-x-4">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: activeSensor.color }} />
              Live Transducer Data
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-0.5 w-4 bg-cyan-400 inline-block" />
              Physics Engine Baseline
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-4 bg-emerald-500/20 border border-emerald-500/40 inline-block" />
              Certified Flight Envelope
            </span>
          </div>

          <div>
            <span>Delta vs Physics: </span>
            <strong className="text-slate-200 font-mono">
              {Math.round((activeSensor.value - activeSensor.expected) * 10) / 10} {activeSensor.unit}
            </strong>
          </div>
        </div>
      </div>

      {/* 8 Sensor Selectable Cards Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-bold text-sm text-slate-300 uppercase tracking-wider">
            ALL TELEMETRIC TRANSDUCERS (CLICK TO FOCUS)
          </h3>
          <span className="text-xs font-mono text-slate-500">8 Channels Active</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {sensorDefinitions.map(s => {
            const isSelected = selectedSensorKey === s.key;
            const spark = telemetryHistory.map(t => t[s.key]);
            const isCritical = s.value > s.maxSafe * 1.08 || s.value < s.minSafe * 0.92;
            const isWarning = s.value > s.maxSafe || s.value < s.minSafe;

            return (
              <div
                key={s.key}
                onClick={() => setSelectedSensorKey(s.key)}
                className={`cursor-pointer transition-all duration-200 rounded-xl ${
                  isSelected ? 'ring-2 ring-cyan-400 scale-[1.02]' : ''
                }`}
              >
                <MetricCard
                  title={s.label}
                  value={s.value}
                  unit={s.unit}
                  expectedValue={s.expected}
                  deviation={Math.round((s.value - s.expected) * 10) / 10}
                  status={isCritical ? 'critical' : isWarning ? 'warning' : 'healthy'}
                  icon={s.icon}
                  minSafe={s.minSafe}
                  maxSafe={s.maxSafe}
                  currentNumeric={s.value}
                  sparklineData={spark}
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
