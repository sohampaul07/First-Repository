/**
 * AEROTWIN AI - Early Fault Prediction & Prognostics View
 */

import React, { useState } from 'react';
import { 
  AlertOctagon, 
  ShieldAlert, 
  Clock, 
  TrendingUp, 
  CheckCircle2, 
  AlertTriangle, 
  Zap, 
  ArrowRight,
  Droplet,
  Flame,
  Activity,
  Fuel
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { DecisionModal } from '../common/DecisionModal';

export const FaultPredictionView: React.FC = () => {
  const { aiAnalysis, componentHealth, rul, setActiveView } = useSimulation();
  const [isDecisionOpen, setIsDecisionOpen] = useState<boolean>(false);

  const failureModes = [
    {
      id: 'fm-oil',
      name: 'Lubrication Pressure Loss & Oil Starvation',
      probability: componentHealth.lubricationSystem.faultProbability,
      severity: componentHealth.lubricationSystem.status,
      timeToFailure: `${(componentHealth.lubricationSystem.estimatedRULHours * 0.4).toFixed(1)} hrs`,
      icon: Droplet,
      symptoms: 'Oil gallery pressure drop below 38 PSI with concurrent sump temperature rise',
      mitigation: 'Reduce engine throttle to 65% power immediately; execute RTB if pressure drops below 28 PSI',
    },
    {
      id: 'fm-bearing',
      name: 'Crankshaft Main & Journal Bearing Wear',
      probability: componentHealth.bearingSystem.faultProbability,
      severity: componentHealth.bearingSystem.status,
      timeToFailure: `${(componentHealth.bearingSystem.estimatedRULHours * 0.5).toFixed(1)} hrs`,
      icon: Zap,
      symptoms: 'Elevated 1X rotational harmonic vibration exceeding 4.2 mm/s RMS',
      mitigation: 'Limit peak continuous cruise RPM to 4,800; schedule borescope and oil debris spectrometer test',
    },
    {
      id: 'fm-overheat',
      name: 'Combustion Thermal Runaway & Head Overheating',
      probability: componentHealth.coolingSystem.faultProbability,
      severity: componentHealth.coolingSystem.status,
      timeToFailure: `${(componentHealth.coolingSystem.estimatedRULHours * 0.3).toFixed(1)} hrs`,
      icon: Flame,
      symptoms: 'Cylinder Head Temperature (CHT) > 185°C, block temp > 110°C under steady airflow',
      mitigation: 'Enrich mixture by 8% to provide charge evaporative cooling; increase UAV airspeed for cooling airflow',
    },
    {
      id: 'fm-fuel',
      name: 'Electronic Fuel Injector Clogging / Lean Condition',
      probability: componentHealth.fuelSystem.faultProbability,
      severity: componentHealth.fuelSystem.status,
      timeToFailure: `${(componentHealth.fuelSystem.estimatedRULHours * 0.6).toFixed(1)} hrs`,
      icon: Fuel,
      symptoms: 'EGT pyrometer divergence > 820°C with negative fuel flow residual',
      mitigation: 'Switch to redundant secondary fuel pump circuit; purge injector rail filters upon landing',
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-rose-500 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              PROGNOSTICS & MULTI-FAULT PREDICTION
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 border border-rose-500/40 text-rose-300">
              EARLY DETECTION HORIZON
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Statistical failure mode probability forecasting and emergency mitigation routing
          </p>
        </div>

        <button
          onClick={() => setIsDecisionOpen(true)}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all shrink-0"
        >
          <span>OPEN MITIGATION PROTOCOL</span>
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>

      {/* Primary Forecast Box */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 backdrop-blur-md shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div>
            <span className="text-[10px] font-mono uppercase text-slate-400">PRIMARY ACTIVE INFERRED FAULT</span>
            <h3 className="font-display font-bold text-xl text-slate-100 mt-0.5">
              {aiAnalysis.detectedFault}
            </h3>
          </div>
          <div className="flex items-center space-x-3 font-mono text-xs">
            <div className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Anomaly Index: </span>
              <strong className={aiAnalysis.anomalyScore > 40 ? 'text-rose-400' : 'text-cyan-400'}>
                {aiAnalysis.anomalyScore}/100
              </strong>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-slate-400">Urgency: </span>
              <strong className={aiAnalysis.urgency === 'IMMEDIATE' ? 'text-rose-400 font-bold' : aiAnalysis.urgency === 'HIGH' ? 'text-amber-400 font-bold' : 'text-cyan-400'}>
                {aiAnalysis.urgency}
              </strong>
            </div>
          </div>
        </div>

        <div className="my-4 p-4 rounded-xl bg-slate-950/80 border border-slate-800 text-xs text-slate-300 leading-relaxed font-sans">
          <strong className="text-cyan-400 font-mono block mb-1 uppercase text-[10px]">
            Recommended Tactical Decision:
          </strong>
          {aiAnalysis.recommendedMitigation}
        </div>
      </div>

      {/* Failure Modes Matrix */}
      <div className="space-y-3">
        <h3 className="font-display font-bold text-sm text-slate-300 uppercase tracking-wider">
          SYSTEM FAILURE MODES PROGNOSTIC MATRIX
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {failureModes.map((fm) => {
            const Icon = fm.icon;
            const isCrit = fm.severity === 'critical';
            const isWarn = fm.severity === 'warning';

            return (
              <div
                key={fm.id}
                className={`rounded-2xl border p-4 backdrop-blur-md transition-all ${
                  isCrit ? 'border-rose-500/60 bg-rose-950/20' :
                  isWarn ? 'border-amber-500/50 bg-amber-950/15' :
                  'border-slate-800 bg-slate-900/80'
                }`}
              >
                <div className="flex items-start justify-between pb-3 border-b border-slate-800/80">
                  <div className="flex items-center space-x-2.5">
                    <div className="p-2 rounded-xl bg-slate-800 text-cyan-400">
                      <Icon className="h-4 w-4" />
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-sm text-slate-100">{fm.name}</h4>
                      <span className="text-[10px] font-mono text-slate-400">TTF Estimate: {fm.timeToFailure}</span>
                    </div>
                  </div>
                  <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-full border ${
                    isCrit ? 'bg-rose-500/30 border-rose-500/50 text-rose-300 font-bold animate-pulse' :
                    isWarn ? 'bg-amber-500/20 border-amber-500/40 text-amber-300' :
                    'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  }`}>
                    {fm.probability}% PROB
                  </span>
                </div>

                {/* Probability Bar */}
                <div className="my-3">
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full transition-all duration-500 ${
                        fm.probability > 60 ? 'bg-rose-500' :
                        fm.probability > 30 ? 'bg-amber-400' : 'bg-cyan-400'
                      }`}
                      style={{ width: `${fm.probability}%` }}
                    />
                  </div>
                </div>

                {/* Symptoms & Mitigations */}
                <div className="space-y-2 text-xs font-mono">
                  <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80">
                    <span className="text-slate-400 text-[10px] uppercase block">Key Telemetry Signature:</span>
                    <p className="text-slate-300 font-sans text-xs mt-0.5">{fm.symptoms}</p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-cyan-950/30 border border-cyan-500/20">
                    <span className="text-cyan-400 text-[10px] uppercase block">Mitigation Directive:</span>
                    <p className="text-slate-200 font-sans text-xs mt-0.5">{fm.mitigation}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <DecisionModal
        isOpen={isDecisionOpen}
        onClose={() => setIsDecisionOpen(false)}
      />
    </div>
  );
};
