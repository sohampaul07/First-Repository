/**
 * AEROTWIN AI - Historical Analytics & Telemetry Insights
 */

import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Fuel, 
  Flame, 
  Droplet, 
  Cpu, 
  Calendar, 
  Award,
  Layers
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';

export const AnalyticsView: React.FC = () => {
  const { telemetryHistory, componentHealth } = useSimulation();

  const pastMissions = [
    { id: 'MSN-398', date: '2026-08-22', duration: '5.2 hrs', avgRPM: 5120, avgTemp: '94°C', fuelUsed: '28.1 L', status: 'Optimal' },
    { id: 'MSN-399', date: '2026-08-23', duration: '3.8 hrs', avgRPM: 5240, avgTemp: '98°C', fuelUsed: '21.4 L', status: 'Optimal' },
    { id: 'MSN-400', date: '2026-08-25', duration: '6.1 hrs', avgRPM: 4980, avgTemp: '92°C', fuelUsed: '32.0 L', status: 'Optimal' },
    { id: 'MSN-401', date: '2026-08-26', duration: '4.4 hrs', avgRPM: 5310, avgTemp: '102°C', fuelUsed: '25.6 L', status: 'Warning Minor' },
    { id: 'MSN-402', date: '2026-08-28', duration: '2.5 hrs', avgRPM: 5150, avgTemp: '96°C', fuelUsed: '13.8 L', status: 'Active Live' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              HISTORICAL TELEMETRY ANALYTICS & FLEET BENCHMARKS
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
              LONGITUDINAL TRENDS
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Multi-mission propulsion health degradation curves and thermodynamic thermal efficiency analytics
          </p>
        </div>
      </div>

      {/* 4 Summary Analytics KPI Blocks */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 backdrop-blur-md">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>Cumulative Flight Hours</span>
            <Calendar className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="font-display text-3xl font-bold text-slate-100 mt-2">
            184.6 <span className="text-xs font-mono text-slate-400 font-normal">HRS</span>
          </div>
          <div className="text-[10px] font-mono text-emerald-400 mt-2 flex items-center gap-1">
            <TrendingUp className="h-3 w-3" /> +22.0 hrs this week
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 backdrop-blur-md">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>Average Specific Fuel Cons</span>
            <Fuel className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="font-display text-3xl font-bold text-slate-100 mt-2">
            5.38 <span className="text-xs font-mono text-slate-400 font-normal">L/HR</span>
          </div>
          <div className="text-[10px] font-mono text-emerald-400 mt-2 flex items-center gap-1">
            <TrendingDown className="h-3 w-3" /> 2.1% better than baseline
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 backdrop-blur-md">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>Mean Operating Temp</span>
            <Flame className="h-4 w-4 text-amber-400" />
          </div>
          <div className="font-display text-3xl font-bold text-slate-100 mt-2">
            96.4 <span className="text-xs font-mono text-slate-400 font-normal">°C</span>
          </div>
          <div className="text-[10px] font-mono text-slate-400 mt-2">
            Optimal Cruise Envelope
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 backdrop-blur-md">
          <div className="flex items-center justify-between text-xs font-mono text-slate-400">
            <span>Fleet Health Rank</span>
            <Award className="h-4 w-4 text-purple-400" />
          </div>
          <div className="font-display text-3xl font-bold text-purple-300 mt-2">
            TOP 5%
          </div>
          <div className="text-[10px] font-mono text-slate-400 mt-2">
            UAV Engine SN: #150-EFI-882
          </div>
        </div>
      </div>

      {/* Past Missions Performance Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-xl">
        <h3 className="font-display font-bold text-base text-slate-100 mb-4">
          RECENT FLIGHT MISSIONS LOG & PERFORMANCE STATS
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="pb-3 px-3">Mission ID</th>
                <th className="pb-3 px-3">Date</th>
                <th className="pb-3 px-3">Duration</th>
                <th className="pb-3 px-3">Average RPM</th>
                <th className="pb-3 px-3">Average Temp</th>
                <th className="pb-3 px-3">Total Fuel</th>
                <th className="pb-3 px-3">Outcome</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {pastMissions.map((m) => (
                <tr key={m.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3 px-3 font-semibold text-cyan-400">{m.id}</td>
                  <td className="py-3 px-3 text-slate-300">{m.date}</td>
                  <td className="py-3 px-3 text-slate-200 font-bold">{m.duration}</td>
                  <td className="py-3 px-3 text-slate-400">{m.avgRPM} RPM</td>
                  <td className="py-3 px-3 text-slate-400">{m.avgTemp}</td>
                  <td className="py-3 px-3 text-emerald-400">{m.fuelUsed}</td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded-full border text-[10px] ${
                      m.status.includes('Active') ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 animate-pulse font-bold' :
                      m.status.includes('Warning') ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' :
                      'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                    }`}>
                      {m.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
