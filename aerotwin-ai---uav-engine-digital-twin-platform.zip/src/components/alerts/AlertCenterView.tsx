/**
 * AEROTWIN AI - Tactical Alert & Alarm Center
 */

import React, { useState } from 'react';
import { 
  BellRing, 
  ShieldAlert, 
  AlertTriangle, 
  Info, 
  CheckCircle2, 
  Check, 
  X, 
  Filter, 
  Volume2, 
  VolumeX,
  Clock
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { SeverityLevel } from '../../types';

export const AlertCenterView: React.FC = () => {
  const { alerts, acknowledgeAlert, resolveAlert } = useSimulation();
  const [filterSeverity, setFilterSeverity] = useState<SeverityLevel | 'all'>('all');
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(false);

  const filteredAlerts = alerts.filter(a => filterSeverity === 'all' || a.severity === filterSeverity);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-rose-500 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              ALERT & WARNING DISPATCH CENTER
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 border border-rose-500/40 text-rose-300">
              REAL-TIME ANNUNCIATOR
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Active propulsion alarms, threshold breaches, and explainable AI warning dispatches
          </p>
        </div>

        {/* Audio Mute Toggle */}
        <button
          onClick={() => setIsAudioMuted(!isAudioMuted)}
          className={`flex items-center space-x-2 px-3 py-1.5 rounded-xl border text-xs font-mono transition-all ${
            isAudioMuted ? 'border-slate-700 bg-slate-950 text-slate-400' : 'border-cyan-500/40 bg-cyan-950/40 text-cyan-300'
          }`}
        >
          {isAudioMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          <span>{isAudioMuted ? 'AUDIO ALARMS MUTED' : 'AUDIO ANNUNCIATOR ARMED'}</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 text-xs font-mono">
        <span className="text-slate-500 flex items-center gap-1">
          <Filter className="h-3.5 w-3.5" /> Filter:
        </span>
        {['all', 'critical', 'warning', 'monitor'].map((sev) => (
          <button
            key={sev}
            onClick={() => setFilterSeverity(sev as any)}
            className={`px-3 py-1 rounded-lg uppercase transition-all ${
              filterSeverity === sev
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {sev} ({sev === 'all' ? alerts.length : alerts.filter(a => a.severity === sev).length})
          </button>
        ))}
      </div>

      {/* Alert List */}
      <div className="space-y-3">
        {filteredAlerts.length === 0 ? (
          <div className="p-8 rounded-2xl border border-slate-800 bg-slate-950 text-center">
            <CheckCircle2 className="h-10 w-10 text-emerald-400 mx-auto mb-2 opacity-80" />
            <h4 className="font-display font-bold text-base text-slate-200">NO ACTIVE PROPULSION ALARMS</h4>
            <p className="text-xs font-mono text-slate-400 mt-1">
              All engine transducers and physics residuals operating within nominal margins.
            </p>
          </div>
        ) : (
          filteredAlerts.map((alert) => {
            const isCrit = alert.severity === 'critical';
            const isWarn = alert.severity === 'warning';

            return (
              <div
                key={alert.id}
                className={`p-4 rounded-2xl border flex flex-col md:flex-row md:items-center justify-between gap-4 backdrop-blur-md transition-all ${
                  isCrit ? 'border-rose-500/60 bg-rose-950/20 shadow-lg shadow-rose-950/30' :
                  isWarn ? 'border-amber-500/50 bg-amber-950/15' :
                  'border-slate-800 bg-slate-900/80'
                }`}
              >
                <div className="flex items-start space-x-3.5">
                  <div className={`p-2.5 rounded-xl mt-0.5 ${
                    isCrit ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40' :
                    isWarn ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' :
                    'bg-slate-800 text-slate-300'
                  }`}>
                    {isCrit ? <ShieldAlert className="h-5 w-5 animate-pulse" /> : <AlertTriangle className="h-5 w-5" />}
                  </div>

                  <div>
                    <div className="flex items-center space-x-2">
                      <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-full border font-bold ${
                        isCrit ? 'bg-rose-500/30 border-rose-500/50 text-rose-300' :
                        isWarn ? 'bg-amber-500/20 border-amber-500/40 text-amber-300' :
                        'bg-slate-800 text-slate-300'
                      }`}>
                        {alert.severity}
                      </span>
                      <span className="text-xs font-mono text-cyan-400 font-bold">{alert.sensorOrComponent}</span>
                      <span className="text-[10px] font-mono text-slate-500">{alert.timestamp}</span>
                    </div>

                    <h4 className="font-display font-bold text-sm text-slate-100 mt-1">{alert.title}</h4>
                    <p className="text-xs text-slate-300 font-sans mt-0.5">
                      Measured Value: <strong className="text-rose-300 font-mono">{alert.currentValue}</strong> (Nominal Envelope: {alert.safeRange})
                    </p>
                    <p className="text-[11px] font-mono text-amber-300/90 mt-1">
                      Action Required: {alert.recommendedAction}
                    </p>
                  </div>
                </div>

                {/* Acknowledge / Resolve Buttons */}
                <div className="flex items-center space-x-2 shrink-0 self-end md:self-center font-mono text-xs">
                  {!alert.acknowledged && (
                    <button
                      onClick={() => acknowledgeAlert(alert.id)}
                      className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
                    >
                      <Check className="h-3.5 w-3.5 text-cyan-400" />
                      <span>ACKNOWLEDGE</span>
                    </button>
                  )}

                  <button
                    onClick={() => resolveAlert(alert.id)}
                    className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 transition-colors font-bold"
                  >
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>RESOLVE</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
