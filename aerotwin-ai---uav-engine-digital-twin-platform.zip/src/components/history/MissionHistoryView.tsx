/**
 * AEROTWIN AI - Historical Mission Logs & Archive View
 */

import React, { useState } from 'react';
import { 
  FolderClock, 
  Calendar, 
  Clock, 
  Fuel, 
  Flame, 
  Activity, 
  FileText, 
  Download, 
  X, 
  CheckCircle2, 
  AlertTriangle 
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';

interface SavedMission {
  id: string;
  name: string;
  date: string;
  duration: string;
  maxRPM: number;
  peakTemp: string;
  peakVib: string;
  fuelBurn: string;
  outcome: 'Completed' | 'Aborted (RTB)' | 'In Progress';
  operatorNotes: string;
}

export const MissionHistoryView: React.FC = () => {
  const { missionState } = useSimulation();

  const [missions] = useState<SavedMission[]>([
    {
      id: 'MSN-2026-0801',
      name: 'High-Altitude ISR Corridor Charlie',
      date: '2026-08-27',
      duration: '4.8 hrs',
      maxRPM: 5420,
      peakTemp: '98.5°C',
      peakVib: '2.8 mm/s',
      fuelBurn: '25.9 L',
      outcome: 'Completed',
      operatorNotes: 'Nominal cruise performance throughout. Low thermal dissipation delta.',
    },
    {
      id: 'MSN-2026-0798',
      name: 'Maritime Coastal Reconnaissance #12',
      date: '2026-08-25',
      duration: '3.2 hrs',
      maxRPM: 5890,
      peakTemp: '108.2°C',
      peakVib: '4.9 mm/s',
      fuelBurn: '18.4 L',
      outcome: 'Aborted (RTB)',
      operatorNotes: 'Preemptive return-to-base executed due to elevated vibration signature on Cylinder 2.',
    },
    {
      id: 'MSN-2026-0792',
      name: 'Border Sector 4 Night Patrol',
      date: '2026-08-23',
      duration: '6.1 hrs',
      maxRPM: 5180,
      peakTemp: '94.0°C',
      peakVib: '2.4 mm/s',
      fuelBurn: '32.8 L',
      outcome: 'Completed',
      operatorNotes: 'Optimal fuel economy with standard ambient temperatures.',
    },
    {
      id: 'MSN-2026-0785',
      name: 'Search & Rescue Escort Alpha',
      date: '2026-08-21',
      duration: '5.5 hrs',
      maxRPM: 5650,
      peakTemp: '102.1°C',
      peakVib: '3.1 mm/s',
      fuelBurn: '29.7 L',
      outcome: 'Completed',
      operatorNotes: 'High payload configuration; cooling fins maintained thermal equilibrium.',
    },
  ]);

  const [selectedMission, setSelectedMission] = useState<SavedMission | null>(null);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              MISSION ARCHIVE & DIGITAL BLACK-BOX LOGS
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
              TELEMETRIC ARCHIVE
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Historical flight records, peak parameter signatures, and pilot mission notes
          </p>
        </div>
      </div>

      {/* Mission Log Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-xl">
        <h3 className="font-display font-bold text-base text-slate-100 mb-4">
          ARCHIVED FLIGHT MISSIONS
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px]">
                <th className="pb-3 px-3">Mission ID</th>
                <th className="pb-3 px-3">Operation Title</th>
                <th className="pb-3 px-3">Date</th>
                <th className="pb-3 px-3">Flight Time</th>
                <th className="pb-3 px-3">Peak Temp</th>
                <th className="pb-3 px-3">Peak Vib</th>
                <th className="pb-3 px-3">Status</th>
                <th className="pb-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {missions.map((m) => (
                <tr key={m.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3 px-3 font-semibold text-cyan-400">{m.id}</td>
                  <td className="py-3 px-3 text-slate-200 font-sans font-medium">{m.name}</td>
                  <td className="py-3 px-3 text-slate-400">{m.date}</td>
                  <td className="py-3 px-3 text-slate-200 font-bold">{m.duration}</td>
                  <td className="py-3 px-3 text-amber-400">{m.peakTemp}</td>
                  <td className="py-3 px-3 text-purple-400">{m.peakVib}</td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded-full border text-[10px] ${
                      m.outcome === 'Completed' ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30' :
                      m.outcome === 'Aborted (RTB)' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' :
                      'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                    }`}>
                      {m.outcome}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right">
                    <button
                      onClick={() => setSelectedMission(m)}
                      className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs transition-colors"
                    >
                      Inspect Logs
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mission Detail Modal */}
      {selectedMission && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl p-6 relative">
            <button
              onClick={() => setSelectedMission(null)}
              className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                <FileText className="h-6 w-6" />
              </div>
              <div>
                <span className="text-xs font-mono text-cyan-400 uppercase">{selectedMission.id}</span>
                <h3 className="font-display font-bold text-lg text-slate-100">{selectedMission.name}</h3>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 font-mono text-xs mb-4">
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase">Date</span>
                <div className="font-bold text-slate-200">{selectedMission.date}</div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase">Duration</span>
                <div className="font-bold text-cyan-400">{selectedMission.duration}</div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase">Peak Vibration</span>
                <div className="font-bold text-purple-400">{selectedMission.peakVib}</div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-slate-500 text-[10px] uppercase">Fuel Burn</span>
                <div className="font-bold text-emerald-400">{selectedMission.fuelBurn}</div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 mb-5">
              <span className="text-[10px] font-mono uppercase text-slate-400 block mb-1">
                Post-Flight Pilot Debrief Notes:
              </span>
              <p className="text-xs text-slate-300 font-sans leading-relaxed">
                {selectedMission.operatorNotes}
              </p>
            </div>

            <button
              onClick={() => setSelectedMission(null)}
              className="w-full py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow transition-colors"
            >
              Close Record
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
