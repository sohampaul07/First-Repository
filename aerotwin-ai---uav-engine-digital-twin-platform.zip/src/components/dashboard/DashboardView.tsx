/**
 * AEROTWIN AI - Primary Executive Dashboard View
 */

import React, { useState } from 'react';
import { 
  Activity, 
  Flame, 
  Droplet, 
  Zap, 
  Cpu, 
  Hourglass, 
  ShieldAlert, 
  Compass, 
  ArrowRight, 
  TrendingUp, 
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
  MapPin,
  Clock
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { MetricCard } from '../common/MetricCard';
import { EngineVisualization } from '../digitaltwin/EngineVisualization';
import { DecisionModal } from '../common/DecisionModal';

export const DashboardView: React.FC = () => {
  const { 
    telemetry, 
    telemetryHistory, 
    physics, 
    aiAnalysis, 
    componentHealth, 
    rul, 
    missionState, 
    alerts, 
    setActiveView 
  } = useSimulation();

  const [isDecisionModalOpen, setIsDecisionModalOpen] = useState<boolean>(false);

  // Extract sparklines from history
  const rpmSparkline = telemetryHistory.map(t => t.rpm);
  const tempSparkline = telemetryHistory.map(t => t.engineTemp);
  const pressureSparkline = telemetryHistory.map(t => t.oilPressure);
  const vibSparkline = telemetryHistory.map(t => t.vibration);

  const criticalAlerts = alerts.filter(a => a.severity === 'critical');

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner Alert if Critical */}
      {criticalAlerts.length > 0 && (
        <div className="p-4 rounded-xl bg-gradient-to-r from-red-950/80 to-[#111115] border border-red-900 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-lg shadow-red-950/40 animate-pulse">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-red-900/30 border border-red-900 text-red-400">
              <ShieldAlert className="h-6 w-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-mono text-xs uppercase px-2 py-0.5 rounded bg-red-900 text-white font-bold">
                  PROPULSION ALERT
                </span>
                <span className="font-mono text-xs text-red-300">
                  {criticalAlerts[0].sensorOrComponent}
                </span>
              </div>
              <p className="text-sm font-semibold text-slate-100 mt-0.5">
                {criticalAlerts[0].title}
              </p>
            </div>
          </div>

          <button
            id="btn-dash-decision-support"
            onClick={() => setIsDecisionModalOpen(true)}
            className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-red-900 hover:bg-red-800 text-white font-bold text-xs shadow-md transition-all shrink-0"
          >
            <span>OPERATOR DECISION SUPPORT</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Top Executive KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Overall Engine Health */}
        <div className="rounded-xl border border-[#1E1E24] bg-[#111115] p-4 relative overflow-hidden shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-black/40 text-blue-400 border border-white/5">
                <Cpu className="h-4 w-4" />
              </div>
              <span className="text-xs font-mono uppercase text-slate-400">Engine Health</span>
            </div>
            <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded border ${
              componentHealth.overallScore > 85 ? 'bg-emerald-950/40 text-emerald-400 border-emerald-900' :
              componentHealth.overallScore > 65 ? 'bg-amber-950/40 text-amber-300 border-amber-900' :
              'bg-red-950/50 text-red-300 border-red-900 animate-pulse'
            }`}>
              {componentHealth.status}
            </span>
          </div>

          <div className="mt-3 flex items-baseline justify-between">
            <span className="font-display text-3xl font-bold text-emerald-400">
              {componentHealth.overallScore}%
            </span>
            <span className="text-xs font-mono text-slate-400">
              Degradation: {componentHealth.lubricationSystem.degradationRate}%/hr
            </span>
          </div>

          <div className="mt-3 w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${
                componentHealth.overallScore > 85 ? 'bg-emerald-500' :
                componentHealth.overallScore > 65 ? 'bg-amber-500' : 'bg-rose-500'
              }`}
              style={{ width: `${componentHealth.overallScore}%` }}
            />
          </div>
        </div>

        {/* 2. RUL Remaining Useful Life */}
        <div className="rounded-xl border border-[#1E1E24] bg-[#111115] p-4 relative overflow-hidden shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-black/40 text-amber-400 border border-white/5">
                <Hourglass className="h-4 w-4" />
              </div>
              <span className="text-xs font-mono uppercase text-slate-400">Remaining Life (RUL)</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400">95% CI</span>
          </div>

          <div className="mt-3 flex items-baseline justify-between">
            <div className="flex items-baseline space-x-1">
              <span className="font-display text-3xl font-bold text-amber-400">
                {rul.remainingFlightHours}
              </span>
              <span className="text-xs font-mono text-slate-400">Hours</span>
            </div>
            <span className="text-xs font-mono text-slate-400">
              [{rul.confidenceRangeMin}h - {rul.confidenceRangeMax}h]
            </span>
          </div>

          <div className="mt-2 text-[11px] font-mono text-slate-400 truncate">
            Failure Mode: <span className="text-slate-300">{rul.predictedFailureMode}</span>
          </div>
        </div>

        {/* 3. AI Anomaly Score & Inferred Fault */}
        <div className="rounded-xl border border-[#1E1E24] bg-[#111115] p-4 relative overflow-hidden shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-black/40 text-blue-400 border border-white/5">
                <Sparkles className="h-4 w-4" />
              </div>
              <span className="text-xs font-mono uppercase text-slate-400">AI Fault Inference</span>
            </div>
            <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
              aiAnalysis.urgency === 'NOMINAL' ? 'bg-emerald-950/40 text-emerald-400 border-emerald-900' :
              aiAnalysis.urgency === 'MONITOR' ? 'bg-blue-950/40 text-blue-300 border-blue-900' :
              aiAnalysis.urgency === 'HIGH' ? 'bg-amber-950/40 text-amber-300 border-amber-900' :
              'bg-red-950/50 text-red-300 border-red-900 animate-pulse font-bold'
            }`}>
              {aiAnalysis.confidence}% CONF
            </span>
          </div>

          <div className="mt-2 text-sm font-semibold text-slate-100 line-clamp-1">
            {aiAnalysis.detectedFault}
          </div>

          <div className="mt-2 flex items-center justify-between text-xs font-mono text-slate-400">
            <span>Anomaly Score:</span>
            <strong className={aiAnalysis.anomalyScore > 50 ? 'text-red-400' : 'text-blue-400'}>
              {aiAnalysis.anomalyScore}/100
            </strong>
          </div>
        </div>

        {/* 4. Active Mission Progress & Risk */}
        <div className="rounded-xl border border-[#1E1E24] bg-[#111115] p-4 relative overflow-hidden shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-black/40 text-blue-400 border border-white/5">
                <Compass className="h-4 w-4" />
              </div>
              <span className="text-xs font-mono uppercase text-slate-400">Mission Status</span>
            </div>
            <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded border ${
              missionState.returnToBaseRisk === 'LOW' ? 'bg-emerald-950/40 text-emerald-400 border-emerald-900' :
              missionState.returnToBaseRisk === 'MEDIUM' ? 'bg-blue-950/40 text-blue-300 border-blue-900' :
              missionState.returnToBaseRisk === 'HIGH' ? 'bg-amber-950/40 text-amber-300 border-amber-900' :
              'bg-red-950/50 text-red-300 border-red-900'
            }`}>
              RTB RISK: {missionState.returnToBaseRisk}
            </span>
          </div>

          <div className="mt-3 flex items-baseline justify-between">
            <div className="flex items-baseline space-x-1">
              <span className="font-display text-3xl font-bold text-slate-100">
                {missionState.progressPercentage}%
              </span>
              <span className="text-xs font-mono text-slate-400">Complete</span>
            </div>
            <span className="text-xs font-mono text-slate-400">
              Fuel: {missionState.fuelRemainingPercentage}%
            </span>
          </div>

          <div className="mt-3 w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-600 transition-all duration-300"
              style={{ width: `${missionState.progressPercentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Real-time Telemetry Mini Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          id="kpi-rpm"
          title="Engine RPM"
          value={telemetry.rpm}
          unit="RPM"
          expectedValue={physics.expectedEngineTemp > 0 ? 5100 : 5000}
          status={telemetry.rpm > 6200 ? 'warning' : 'healthy'}
          icon={Activity}
          minSafe={3000}
          maxSafe={6000}
          currentNumeric={telemetry.rpm}
          sparklineData={rpmSparkline}
          onClick={() => setActiveView('telemetry')}
        />

        <MetricCard
          id="kpi-engine-temp"
          title="Engine Block Temp"
          value={telemetry.engineTemp}
          unit="°C"
          expectedValue={physics.expectedEngineTemp}
          deviation={physics.tempDeviation}
          status={telemetry.engineTemp > 115 ? 'critical' : telemetry.engineTemp > 105 ? 'warning' : telemetry.engineTemp > 98 ? 'monitor' : 'healthy'}
          icon={Flame}
          minSafe={75}
          maxSafe={105}
          currentNumeric={telemetry.engineTemp}
          sparklineData={tempSparkline}
          onClick={() => setActiveView('telemetry')}
        />

        <MetricCard
          id="kpi-oil-pressure"
          title="Oil Pressure"
          value={telemetry.oilPressure}
          unit="PSI"
          expectedValue={physics.expectedOilPressure}
          deviation={physics.pressureDeviation}
          status={telemetry.oilPressure < 25 ? 'critical' : telemetry.oilPressure < 38 ? 'warning' : telemetry.oilPressure < 45 ? 'monitor' : 'healthy'}
          icon={Droplet}
          minSafe={40}
          maxSafe={75}
          currentNumeric={telemetry.oilPressure}
          sparklineData={pressureSparkline}
          onClick={() => setActiveView('telemetry')}
        />

        <MetricCard
          id="kpi-vibration"
          title="Mechanical Vibration"
          value={telemetry.vibration}
          unit="mm/s"
          expectedValue={physics.expectedVibration}
          deviation={physics.vibrationDeviation}
          status={telemetry.vibration > 6.5 ? 'critical' : telemetry.vibration > 4.5 ? 'warning' : telemetry.vibration > 3.2 ? 'monitor' : 'healthy'}
          icon={Zap}
          minSafe={1.0}
          maxSafe={3.8}
          currentNumeric={telemetry.vibration}
          sparklineData={vibSparkline}
          onClick={() => setActiveView('telemetry')}
        />
      </div>

      {/* Main Digital Twin Interactive Preview */}
      <EngineVisualization />

      {/* Bottom 2-Column: AI Decision Support & Mission Navigation Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: AI Decision & Explainability Summary */}
        <div className="lg:col-span-7 rounded-xl border border-[#1E1E24] bg-[#111115] p-5 shadow-md">
          <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-black/40 text-blue-400 border border-white/5">
                <Sparkles className="h-4 w-4" />
              </div>
              <div>
                <h3 className="font-display font-bold text-base text-white">
                  AI DECISION & ROOT CAUSE ANALYSIS
                </h3>
                <span className="text-[10px] font-mono text-slate-400">
                  Explainable Hybrid Digital Twin Reasoning
                </span>
              </div>
            </div>

            <button
              onClick={() => setActiveView('ai_intelligence')}
              className="text-xs font-mono text-blue-400 hover:text-blue-300 flex items-center gap-1"
            >
              <span>FULL XAI VIEW</span>
              <ArrowRight className="h-3 w-3" />
            </button>
          </div>

          {/* AI Reasoning Text */}
          <div className="my-4 p-3.5 rounded-lg bg-black/30 border border-white/5">
            <div className="text-xs font-mono text-blue-400 mb-1 font-semibold flex items-center justify-between">
              <span>DETECTED PATTERN SUMMARY:</span>
              <span className="text-slate-400">Confidence: {aiAnalysis.confidence}%</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {aiAnalysis.aiReasoningSummary}
            </p>
          </div>

          {/* Top Feature Importance Bars */}
          <div className="space-y-2">
            <span className="text-[10px] font-mono uppercase text-slate-400 block">
              Key Anomaly Attributions (SHAP Attribution Weights):
            </span>
            {aiAnalysis.featureImportances.slice(0, 3).map((feat, i) => (
              <div key={i} className="flex items-center justify-between text-xs font-mono">
                <span className="w-36 text-slate-300 truncate">{feat.displayName}</span>
                <div className="flex-1 mx-3 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full ${
                      feat.contributionDirection === 'increases_risk' ? 'bg-amber-400' : 'bg-blue-500'
                    }`}
                    style={{ width: `${feat.importance}%` }}
                  />
                </div>
                <span className="text-slate-400 w-10 text-right">{feat.importance}%</span>
              </div>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="mt-5 pt-3 border-t border-[#1E1E24] flex items-center justify-between">
            <div className="text-xs font-mono text-slate-400 truncate max-w-[280px]">
              Rec: <strong className="text-amber-300">{aiAnalysis.recommendedMitigation.substring(0, 38)}...</strong>
            </div>
            <button
              id="btn-dash-open-decision"
              onClick={() => setIsDecisionModalOpen(true)}
              className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/20 transition-all"
            >
              OPERATOR ACTION
            </button>
          </div>
        </div>

        {/* Right: Tactical Mission Snapshot & Waypoints */}
        <div className="lg:col-span-5 rounded-xl border border-[#1E1E24] bg-[#111115] p-5 shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#1E1E24]">
              <div className="flex items-center space-x-2">
                <div className="p-2 rounded-lg bg-black/40 text-blue-400 border border-white/5">
                  <MapPin className="h-4 w-4" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-base text-white">
                    TACTICAL MISSION PROFILE
                  </h3>
                  <span className="text-[10px] font-mono text-slate-400">
                    {missionState.missionName}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setActiveView('mission_map')}
                className="text-xs font-mono text-blue-400 hover:text-blue-300 flex items-center gap-1"
              >
                <span>MAP</span>
                <ArrowRight className="h-3 w-3" />
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 gap-3 my-4 font-mono text-xs">
              <div className="p-3 rounded-lg bg-black/30 border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase">Current Sector</span>
                <div className="font-bold text-white mt-0.5 truncate">
                  {missionState.currentLocationName}
                </div>
                <div className="text-[10px] text-slate-400 mt-1">
                  Alt: {missionState.altitudeFt} ft • {missionState.groundSpeedKnots} kts
                </div>
              </div>

              <div className="p-3 rounded-lg bg-black/30 border border-white/5">
                <span className="text-[10px] text-slate-400 uppercase">Distance & Recovery</span>
                <div className="font-bold text-blue-400 mt-0.5">
                  {missionState.distanceCoveredKm} / {missionState.totalDistanceKm} km
                </div>
                <div className="text-[10px] text-slate-400 mt-1">
                  Base Dist: {missionState.distanceToBaseKm} km
                </div>
              </div>
            </div>

            {/* Waypoint Step Indicator */}
            <div className="space-y-1.5 font-mono text-xs">
              <div className="flex justify-between text-slate-400 text-[10px]">
                <span>BASE AIRFIELD</span>
                <span>WP {missionState.currentWaypointIndex}/{missionState.totalWaypoints}</span>
                <span>TARGET ZONE</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-600 transition-all duration-300"
                  style={{ width: `${missionState.progressPercentage}%` }}
                />
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1E1E24] flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">
              Est. Remaining: <strong className="text-white">{missionState.etaMinutes} min</strong>
            </span>
            <button
              onClick={() => setActiveView('fault_injection')}
              className="text-blue-400 hover:text-blue-300 underline text-[11px]"
            >
              Inject Fault in Lab →
            </button>
          </div>
        </div>
      </div>

      {/* Decision Support Dialog */}
      <DecisionModal
        isOpen={isDecisionModalOpen}
        onClose={() => setIsDecisionModalOpen(false)}
      />
    </div>
  );
};
