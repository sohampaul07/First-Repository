/**
 * AEROTWIN AI - Aerospace Top Navigation Header
 */

import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  Play, 
  Pause, 
  FastForward, 
  RotateCcw, 
  AlertTriangle, 
  Radio, 
  ShieldAlert, 
  Cpu, 
  Flame,
  Zap
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';

export const Header: React.FC = () => {
  const { 
    telemetry, 
    componentHealth, 
    aiAnalysis, 
    alerts, 
    isPaused, 
    togglePause, 
    simulationSpeed, 
    setSimulationSpeed, 
    resetSimulation, 
    setActiveView, 
    operatorLoadFactor,
    executeOperatorAction
  } = useSimulation();

  const [utcTime, setUtcTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setUtcTime(now.toUTCString().slice(17, 25) + ' UTC');
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const criticalAlertCount = alerts.filter(a => a.severity === 'critical').length;
  const warningAlertCount = alerts.filter(a => a.severity === 'warning').length;

  const healthColor = 
    componentHealth.overallScore > 85 ? 'text-emerald-400 border-emerald-500/30 bg-emerald-950/40' :
    componentHealth.overallScore > 65 ? 'text-amber-400 border-amber-500/30 bg-amber-950/40' :
    'text-rose-400 border-rose-500/30 bg-rose-950/40 animate-pulse';

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#1E1E24] bg-[#0A0A0B]/80 backdrop-blur-md px-4 sm:px-6 py-2.5 flex items-center justify-between">
      {/* Brand & Mission Status */}
      <div className="flex items-center space-x-3 sm:space-x-4">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(37,99,235,0.4)]">
            <Radio className="h-5 w-5 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-base tracking-tight text-white font-display">
                AEROTWIN <span className="text-blue-400">AI</span>
              </span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-blue-600/10 border border-blue-500/30 text-blue-400">
                UAV-X42 TWIN
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse inline-block" />
              SYS STATUS: OK • {utcTime}
            </p>
          </div>
        </div>

        {/* Engine Health Pill */}
        <div className={`hidden md:flex items-center space-x-2 px-3 py-1 rounded-md border text-xs font-mono font-medium ${
          componentHealth.overallScore > 85 ? 'text-emerald-400 border-emerald-900 bg-emerald-950/40' :
          componentHealth.overallScore > 65 ? 'text-amber-400 border-amber-900 bg-amber-950/40' :
          'text-rose-400 border-rose-900 bg-rose-950/40 animate-pulse'
        }`}>
          <Cpu className="h-3.5 w-3.5" />
          <span>ENGINE HEALTH: {componentHealth.overallScore}%</span>
          <span className="text-[10px] uppercase opacity-75">({componentHealth.status})</span>
        </div>

        {/* Load Factor Warning if Derated */}
        {operatorLoadFactor < 1.0 && (
          <div className="hidden lg:flex items-center space-x-1.5 px-2.5 py-1 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono">
            <Zap className="h-3 w-3" />
            <span>LOAD DERATED ({(operatorLoadFactor * 100).toFixed(0)}%)</span>
          </div>
        )}
      </div>

      {/* Right Controls: Simulation Controls + Alerts Badge */}
      <div className="flex items-center space-x-2 sm:space-x-3">
        {/* Speed Controls */}
        <div className="flex items-center bg-[#111115] border border-[#1E1E24] rounded-lg p-0.5 text-xs font-mono">
          <button
            id="btn-speed-1x"
            onClick={() => setSimulationSpeed(1)}
            className={`px-2 py-1 rounded ${simulationSpeed === 1 ? 'bg-blue-600 text-white font-bold shadow-sm shadow-blue-600/30' : 'text-slate-400 hover:text-slate-200'}`}
          >
            1x
          </button>
          <button
            id="btn-speed-2x"
            onClick={() => setSimulationSpeed(2)}
            className={`px-2 py-1 rounded ${simulationSpeed === 2 ? 'bg-blue-600 text-white font-bold shadow-sm shadow-blue-600/30' : 'text-slate-400 hover:text-slate-200'}`}
          >
            2x
          </button>
          <button
            id="btn-speed-5x"
            onClick={() => setSimulationSpeed(5)}
            className={`px-2 py-1 rounded ${simulationSpeed === 5 ? 'bg-blue-600 text-white font-bold shadow-sm shadow-blue-600/30' : 'text-slate-400 hover:text-slate-200'}`}
          >
            5x
          </button>
          <button
            id="btn-speed-10x"
            onClick={() => setSimulationSpeed(10)}
            className={`px-2 py-1 rounded ${simulationSpeed === 10 ? 'bg-blue-600 text-white font-bold shadow-sm shadow-blue-600/30' : 'text-slate-400 hover:text-slate-200'}`}
          >
            10x
          </button>
        </div>

        {/* Pause/Play Toggle */}
        <button
          id="btn-toggle-pause"
          onClick={togglePause}
          className={`flex items-center space-x-1 px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
            isPaused
              ? 'bg-amber-500/20 border-amber-500/40 text-amber-300 hover:bg-amber-500/30'
              : 'bg-[#111115] border-[#1E1E24] text-slate-300 hover:bg-[#1A1A1F] hover:text-white'
          }`}
        >
          {isPaused ? (
            <>
              <Play className="h-3.5 w-3.5 fill-amber-300" />
              <span>RESUME</span>
            </>
          ) : (
            <>
              <Pause className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">PAUSE</span>
            </>
          )}
        </button>

        {/* Reset Simulation */}
        <button
          id="btn-reset-sim-header"
          onClick={resetSimulation}
          title="Reset Simulation State to Pristine"
          className="p-1.5 rounded-lg bg-[#111115] border border-[#1E1E24] text-slate-400 hover:text-white hover:bg-[#1A1A1F] transition-colors"
        >
          <RotateCcw className="h-4 w-4 text-blue-400" />
        </button>

        {/* Alerts Badge */}
        <button
          id="btn-header-alerts"
          onClick={() => setActiveView('alert_center')}
          className={`relative flex items-center space-x-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all ${
            criticalAlertCount > 0
              ? 'bg-red-900/30 border border-red-900 text-red-400 animate-pulse'
              : warningAlertCount > 0
              ? 'bg-amber-900/30 border border-amber-900 text-amber-400'
              : 'bg-[#111115] border-[#1E1E24] text-slate-400 hover:text-slate-200'
          }`}
        >
          <AlertTriangle className="h-3.5 w-3.5" />
          <span className="font-mono">
            {criticalAlertCount + warningAlertCount > 0 ? `${criticalAlertCount + warningAlertCount} ALERTS` : 'NOMINAL'}
          </span>
          {criticalAlertCount > 0 && (
            <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
            </span>
          )}
        </button>
      </div>
    </header>
  );
};
