/**
 * AEROTWIN AI - Reusable Telemetry & Metric Card
 */

import React from 'react';
import { SeverityLevel } from '../../types';

interface MetricCardProps {
  id?: string;
  title: string;
  value: string | number;
  unit: string;
  expectedValue?: string | number;
  deviation?: string | number;
  status: SeverityLevel;
  icon: React.ElementType;
  minSafe?: number;
  maxSafe?: number;
  currentNumeric?: number;
  sparklineData?: number[];
  onClick?: () => void;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  id,
  title,
  value,
  unit,
  expectedValue,
  deviation,
  status,
  icon: Icon,
  minSafe,
  maxSafe,
  currentNumeric,
  sparklineData,
  onClick,
}) => {
  const statusColors = {
    healthy: {
      border: 'border-[#1E1E24] hover:border-emerald-500/50',
      badge: 'bg-emerald-950/40 text-emerald-400 border-emerald-900',
      text: 'text-emerald-400',
      glow: 'group-hover:shadow-[0_0_15px_rgba(16,185,129,0.15)]',
      spark: '#10b981',
      bar: 'bg-emerald-500',
    },
    monitor: {
      border: 'border-[#1E1E24] hover:border-blue-500/50',
      badge: 'bg-blue-950/40 text-blue-300 border-blue-900',
      text: 'text-blue-400',
      glow: 'group-hover:shadow-[0_0_15px_rgba(59,130,246,0.15)]',
      spark: '#3b82f6',
      bar: 'bg-blue-500',
    },
    warning: {
      border: 'border-amber-900/60 hover:border-amber-500/70 bg-amber-950/10',
      badge: 'bg-amber-950/40 text-amber-300 border-amber-900 animate-pulse',
      text: 'text-amber-400',
      glow: 'group-hover:shadow-[0_0_15px_rgba(245,158,11,0.2)]',
      spark: '#f59e0b',
      bar: 'bg-amber-500',
    },
    critical: {
      border: 'border-red-900 hover:border-red-500/90 bg-red-950/20 animate-pulse',
      badge: 'bg-red-950/50 text-red-300 border-red-900 font-bold',
      text: 'text-red-400',
      glow: 'group-hover:shadow-[0_0_15px_rgba(239,68,68,0.25)]',
      spark: '#ef4444',
      bar: 'bg-red-500',
    },
  }[status];

  // SVG Sparkline calculation
  const renderSparkline = () => {
    if (!sparklineData || sparklineData.length < 2) return null;
    const min = Math.min(...sparklineData);
    const max = Math.max(...sparklineData);
    const range = max - min === 0 ? 1 : max - min;
    const width = 80;
    const height = 24;

    const points = sparklineData
      .map((val, idx) => {
        const x = (idx / (sparklineData.length - 1)) * width;
        const y = height - ((val - min) / range) * (height - 4) - 2;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');

    return (
      <svg width={width} height={height} className="overflow-visible">
        <polyline
          fill="none"
          stroke={statusColors.spark}
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={points}
        />
      </svg>
    );
  };

  return (
    <div
      id={id}
      onClick={onClick}
      className={`group relative rounded-xl border bg-[#111115] p-3.5 transition-all duration-200 shadow-md ${statusColors.border} ${statusColors.glow} ${
        onClick ? 'cursor-pointer hover:scale-[1.01]' : ''
      }`}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 rounded-lg bg-black/40 border border-white/5 text-slate-300 group-hover:text-blue-400 transition-colors">
            <Icon className="h-4 w-4" />
          </div>
          <div>
            <span className="text-[11px] font-mono uppercase text-slate-400 tracking-wider">
              {title}
            </span>
          </div>
        </div>

        <span className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded border ${statusColors.badge}`}>
          {status}
        </span>
      </div>

      {/* Main Metric Value */}
      <div className="mt-3 flex items-baseline justify-between">
        <div className="flex items-baseline space-x-1.5">
          <span className={`font-display text-2xl font-bold tracking-tight ${statusColors.text}`}>
            {value}
          </span>
          <span className="text-xs font-mono text-slate-400">{unit}</span>
        </div>

        {renderSparkline()}
      </div>

      {/* Physics Deviation & Expected Info */}
      {(expectedValue !== undefined || deviation !== undefined) && (
        <div className="mt-2.5 pt-2 border-t border-[#1E1E24] flex items-center justify-between text-[10px] font-mono text-slate-400">
          <span>Expected: {expectedValue} {unit}</span>
          {deviation !== undefined && (
            <span className={Number(deviation) > 0 ? 'text-amber-400' : Number(deviation) < 0 ? 'text-blue-400' : 'text-slate-400'}>
              Δ {Number(deviation) > 0 ? `+${deviation}` : deviation} {unit}
            </span>
          )}
        </div>
      )}

      {/* Safe range bar indicator */}
      {minSafe !== undefined && maxSafe !== undefined && currentNumeric !== undefined && (
        <div className="mt-2">
          <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${statusColors.bar}`}
              style={{
                width: `${Math.min(100, Math.max(5, ((currentNumeric - minSafe * 0.7) / (maxSafe * 1.3 - minSafe * 0.7)) * 100))}%`,
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};
