/**
 * AEROTWIN AI - Operator Decision Support Modal
 */

import React, { useState } from 'react';
import { ShieldAlert, AlertTriangle, CheckCircle2, X, Compass, Zap, ArrowLeftRight, PlaneLanding } from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { OperatorAction } from '../../types';

interface DecisionModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultAction?: OperatorAction;
}

export const DecisionModal: React.FC<DecisionModalProps> = ({
  isOpen,
  onClose,
  defaultAction = 'REDUCE_LOAD',
}) => {
  const { executeOperatorAction, aiAnalysis, componentHealth, missionState } = useSimulation();
  const [selectedAction, setSelectedAction] = useState<OperatorAction>(defaultAction);
  const [notes, setNotes] = useState<string>('');

  if (!isOpen) return null;

  const handleConfirm = () => {
    executeOperatorAction(selectedAction, notes);
    onClose();
  };

  const actionOptions: { action: OperatorAction; label: string; desc: string; icon: React.ElementType; color: string }[] = [
    {
      action: 'CONTINUE_MISSION',
      label: 'Continue Mission',
      desc: 'Maintain active trajectory and cruise throttle. Accept elevated thermal/mechanical stress.',
      icon: Compass,
      color: 'border-slate-700 hover:border-slate-500 text-slate-200',
    },
    {
      action: 'REDUCE_LOAD',
      label: 'Reduce Engine Load (-35%)',
      desc: 'Derate throttle to 65% power. Reduces cylinder heat generation and extends journal bearing life.',
      icon: Zap,
      color: 'border-amber-500/40 hover:border-amber-500 text-amber-300 bg-amber-950/20',
    },
    {
      action: 'RETURN_TO_BASE',
      label: 'Initiate Return-to-Base (RTB)',
      desc: 'Abort primary reconnaissance corridor and vector directly back to recovery grid.',
      icon: ArrowLeftRight,
      color: 'border-cyan-500/40 hover:border-cyan-500 text-cyan-300 bg-cyan-950/20',
    },
    {
      action: 'EMERGENCY_LANDING',
      label: 'Emergency Diversion Touchdown',
      desc: 'Immediate glide descent to designated alternate emergency airfield.',
      icon: PlaneLanding,
      color: 'border-rose-500/50 hover:border-rose-500 text-rose-300 bg-rose-950/30',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="w-full max-w-xl rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="flex items-center space-x-3 mb-4">
          <div className="p-2.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400">
            <ShieldAlert className="h-6 w-6" />
          </div>
          <div>
            <h3 className="font-display font-bold text-lg text-slate-100">
              OPERATOR MISSION DECISION SUPPORT
            </h3>
            <p className="text-xs font-mono text-slate-400">
              UAV ID: {missionState.missionId} • Engine Health: {componentHealth.overallScore}%
            </p>
          </div>
        </div>

        {/* AI Recommendation Banner */}
        <div className="p-3.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 mb-4">
          <div className="flex items-center justify-between text-xs font-mono text-cyan-300 font-semibold mb-1">
            <span>AI SYSTEM RECOMMENDATION:</span>
            <span className="text-amber-400">Confidence: {aiAnalysis.confidence}%</span>
          </div>
          <p className="text-sm text-slate-200 leading-relaxed font-sans">
            {aiAnalysis.recommendedMitigation}
          </p>
          <div className="mt-2 text-[11px] font-mono text-slate-400">
            Root Cause: <span className="text-slate-300">{aiAnalysis.probableRootCause}</span>
          </div>
        </div>

        {/* Action Selection */}
        <div className="space-y-2 mb-4">
          <label className="text-xs font-mono uppercase text-slate-400">
            Select Tactical Propulsion Response:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {actionOptions.map(opt => {
              const Icon = opt.icon;
              const isSelected = selectedAction === opt.action;
              return (
                <div
                  key={opt.action}
                  onClick={() => setSelectedAction(opt.action)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    isSelected ? 'ring-2 ring-cyan-400 ' + opt.color : 'border-slate-800 bg-slate-950/50 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-2 mb-1">
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="font-semibold text-xs tracking-wide">{opt.label}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-2 leading-tight">
                    {opt.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Operator Notes */}
        <div className="mb-5">
          <label className="text-xs font-mono uppercase text-slate-400 block mb-1">
            Operator Mission Log Notes (Optional):
          </label>
          <input
            type="text"
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder="e.g., Authorized RTB due to oil pressure transducer fluctuation..."
            className="w-full rounded-lg border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-200 placeholder-slate-600 focus:border-cyan-500 focus:outline-none"
          />
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-slate-800 text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            Cancel
          </button>
          <button
            id="btn-confirm-operator-action"
            onClick={handleConfirm}
            className="flex items-center space-x-2 px-5 py-2 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/25 transition-all"
          >
            <CheckCircle2 className="h-4 w-4" />
            <span>EXECUTE DECISION</span>
          </button>
        </div>
      </div>
    </div>
  );
};
