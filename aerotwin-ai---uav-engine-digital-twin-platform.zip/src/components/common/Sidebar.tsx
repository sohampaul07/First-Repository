/**
 * AEROTWIN AI - Collapsible Aerospace Sidebar Navigation
 */

import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Activity, 
  Settings2, 
  HeartPulse, 
  BrainCircuit, 
  AlertOctagon, 
  Hourglass, 
  Wrench, 
  Map, 
  Crosshair, 
  BarChart3, 
  Gamepad2, 
  FolderClock, 
  BellRing, 
  FileText, 
  Info,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  badge?: string | number;
  highlight?: boolean;
}

export const Sidebar: React.FC = () => {
  const { activeView, setActiveView, alerts, componentHealth, aiAnalysis } = useSimulation();
  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);

  const criticalCount = alerts.filter(a => a.severity === 'critical').length;
  const warningCount = alerts.filter(a => a.severity === 'warning').length;
  const totalAlerts = criticalCount + warningCount;

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'telemetry', label: 'Live Telemetry', icon: Activity },
    { id: 'digital_twin', label: 'Digital Twin', icon: Settings2 },
    { id: 'engine_health', label: 'Engine Health', icon: HeartPulse },
    { id: 'ai_intelligence', label: 'AI Intelligence', icon: BrainCircuit, badge: aiAnalysis.urgency !== 'NOMINAL' ? 'XAI' : undefined },
    { id: 'fault_prediction', label: 'Fault Prediction', icon: AlertOctagon, highlight: aiAnalysis.detectedFault !== 'Nominal Operational State' },
    { id: 'rul_prediction', label: 'RUL Prediction', icon: Hourglass },
    { id: 'maintenance_center', label: 'Maintenance Center', icon: Wrench },
    { id: 'mission_map', label: 'Mission Map', icon: Map },
    { id: 'mission_planner', label: 'Mission Planner', icon: Crosshair },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'fault_injection', label: 'Fault Injection Lab', icon: Gamepad2, badge: 'LAB' },
    { id: 'mission_history', label: 'Mission History', icon: FolderClock },
    { id: 'alert_center', label: 'Alert Center', icon: BellRing, badge: totalAlerts > 0 ? totalAlerts : undefined },
    { id: 'reports', label: 'Reports', icon: FileText },
    { id: 'about_project', label: 'About Project', icon: Info },
  ];

  return (
    <aside 
      className={`relative z-30 flex flex-col border-r border-[#1E1E24] bg-[#0F0F12] transition-all duration-300 ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Sidebar Header Collapse Toggle */}
      <div className="flex items-center justify-between p-4 border-b border-[#1E1E24]">
        {!isCollapsed && (
          <div className="flex items-center space-x-2 overflow-hidden">
            <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
            <span className="font-mono text-xs uppercase tracking-widest text-slate-400 font-bold truncate">
              NAVIGATION
            </span>
          </div>
        )}
        <button
          id="btn-sidebar-toggle"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-white/5 transition-colors mx-auto"
          title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
        >
          {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              id={`nav-${item.id}`}
              onClick={() => setActiveView(item.id)}
              className={`w-full flex items-center rounded-md px-3 py-2 text-xs font-medium transition-all group ${
                isActive
                  ? 'bg-blue-600/10 text-blue-400 border-l-2 border-blue-500 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
              }`}
              title={isCollapsed ? item.label : undefined}
            >
              <div className="relative flex items-center justify-center">
                <Icon className={`h-4 w-4 shrink-0 transition-transform group-hover:scale-110 ${
                  isActive ? 'text-blue-400' : 'text-slate-400 group-hover:text-slate-200'
                }`} />
                {item.highlight && isCollapsed && (
                  <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-rose-500 animate-ping" />
                )}
              </div>

              {!isCollapsed && (
                <span className="ml-3 truncate tracking-wide flex-1 text-left">
                  {item.label}
                </span>
              )}

              {!isCollapsed && item.badge !== undefined && (
                <span className={`ml-auto text-[10px] font-mono px-1.5 py-0.5 rounded ${
                  item.id === 'alert_center' && totalAlerts > 0
                    ? criticalCount > 0
                      ? 'bg-red-900/40 text-red-300 border border-red-900 animate-pulse font-bold'
                      : 'bg-amber-900/40 text-amber-300 border border-amber-900'
                    : item.id === 'fault_injection'
                    ? 'bg-red-900/20 text-red-400 border border-red-900/50'
                    : 'bg-blue-950/40 text-blue-300 border border-blue-900/50'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Operator & System Status at Bottom */}
      {!isCollapsed && (
        <div className="p-3 border-t border-[#1E1E24] space-y-2">
          {/* Subsystem Health Bar */}
          <div className="p-2.5 bg-[#1A1A1F] border border-[#1E1E24] rounded-lg text-[11px] font-mono">
            <div className="flex items-center justify-between text-slate-400 mb-1.5">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="h-3.5 w-3.5 text-blue-400" />
                SYSTEM HEALTH
              </span>
              <span className={`font-bold ${
                componentHealth.status === 'healthy' ? 'text-emerald-400' :
                componentHealth.status === 'monitor' ? 'text-blue-300' :
                componentHealth.status === 'warning' ? 'text-amber-400' : 'text-rose-400'
              }`}>
                {componentHealth.status.toUpperCase()}
              </span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
              <div 
                className={`h-full transition-all duration-500 ${
                  componentHealth.overallScore > 85 ? 'bg-emerald-500' :
                  componentHealth.overallScore > 65 ? 'bg-amber-500' : 'bg-rose-500'
                }`}
                style={{ width: `${componentHealth.overallScore}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>Score: {componentHealth.overallScore}%</span>
              <span>RUL: {componentHealth.lubricationSystem.estimatedRULHours}h</span>
            </div>
          </div>

          {/* Operator Profile */}
          <div className="flex items-center gap-2.5 p-2 bg-[#1A1A1F] border border-[#1E1E24] rounded-lg">
            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-blue-500 to-indigo-500 flex items-center justify-center text-[10px] font-bold text-white shadow-sm shrink-0">
              SC
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-xs font-semibold truncate text-white leading-tight">Dr. Sarah Chen</p>
              <p className="text-[10px] text-slate-500 truncate leading-tight">Chief Operations</p>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};
