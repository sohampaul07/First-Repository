/**
 * AEROTWIN AI - Fault Injection Simulation Lab
 * 
 * Interactive laboratory allowing engineers to manually inject multi-parameter
 * degradation, trigger rapid preset fault scenarios, and observe the live
 * Physics-AI-Alert cause-and-effect domino chain in real-time.
 */

import React from 'react';
import { 
  Gamepad2, 
  Flame, 
  Droplet, 
  Zap, 
  Fuel, 
  Activity, 
  RotateCcw, 
  ArrowRight, 
  ShieldAlert, 
  Cpu, 
  CheckCircle2,
  Sparkles,
  Layers
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { FaultInjectionState } from '../../types';

export const FaultInjectionLabView: React.FC = () => {
  const { 
    telemetry, 
    physics, 
    aiAnalysis, 
    componentHealth, 
    rul, 
    faultInjection, 
    toggleFaultPreset, 
    setFaultOverride, 
    resetSimulation,
    applyRandomFaultScenario,
    setActiveView
  } = useSimulation();

  const presets: { 
    key: keyof FaultInjectionState['activePresets']; 
    name: string; 
    desc: string; 
    icon: React.ElementType; 
    color: string 
  }[] = [
    {
      key: 'oilLeak',
      name: 'Severe Oil Gallery Leak',
      desc: 'Rapid pressure drop to ~20 PSI with oil starvation risk.',
      icon: Droplet,
      color: 'border-blue-500/50 text-blue-300 hover:border-blue-400 bg-blue-950/20',
    },
    {
      key: 'bearingWear',
      name: 'Journal Bearing Wear',
      desc: 'Severe harmonic vibration (6.5 mm/s) and friction rise.',
      icon: Zap,
      color: 'border-purple-500/50 text-purple-300 hover:border-purple-400 bg-purple-950/20',
    },
    {
      key: 'overheating',
      name: 'Thermal Runaway (125°C)',
      desc: 'Core cylinder block and CHT head thermal saturation.',
      icon: Flame,
      color: 'border-amber-500/50 text-amber-300 hover:border-amber-400 bg-amber-950/20',
    },
    {
      key: 'coolingSystemFailure',
      name: 'Cooling Duct Plenum Blockage',
      desc: 'Loss of ram-air convective heat dissipation.',
      icon: Flame,
      color: 'border-orange-500/50 text-orange-300 hover:border-orange-400 bg-orange-950/20',
    },
    {
      key: 'fuelSystemFailure',
      name: 'EFI Fuel Delivery Restriction',
      desc: 'Lean air-fuel ratio with elevated EGT pyrometer spikes.',
      icon: Fuel,
      color: 'border-emerald-500/50 text-emerald-300 hover:border-emerald-400 bg-emerald-950/20',
    },
    {
      key: 'ignitionMisfire',
      name: 'Ignition Pulse Misfire',
      desc: 'Combustion imbalance and intermittent cylinder torque drop.',
      icon: ShieldAlert,
      color: 'border-rose-500/60 text-rose-300 hover:border-rose-400 bg-rose-950/30 font-bold',
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              FAULT INJECTION & STRESS SIMULATION LAB
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
              HARDWARE-IN-THE-LOOP SIMULATOR
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Test and validate the closed-loop AI diagnostics engine by injecting anomalies in real time
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={applyRandomFaultScenario}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-purple-950/50 hover:bg-purple-900/60 text-purple-300 font-mono text-xs font-bold border border-purple-500/40 transition-all"
          >
            <Sparkles className="h-4 w-4 text-purple-400" />
            <span>RANDOM MULTI-FAULT</span>
          </button>

          <button
            id="btn-clear-faults"
            onClick={resetSimulation}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs font-bold border border-slate-700 transition-all"
          >
            <RotateCcw className="h-4 w-4 text-cyan-400" />
            <span>RESET (RESTORE NOMINAL)</span>
          </button>
        </div>
      </div>

      {/* Preset Fault Quick Buttons */}
      <div className="space-y-3">
        <h3 className="font-display font-bold text-sm text-slate-300 uppercase tracking-wider">
          RAPID FAULT SCENARIO PRESETS
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {presets.map((p) => {
            const Icon = p.icon;
            const isActive = faultInjection.activePresets[p.key];
            return (
              <button
                key={p.key}
                id={`btn-preset-${p.key}`}
                onClick={() => toggleFaultPreset(p.key)}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  isActive
                    ? 'ring-2 ring-cyan-400 scale-[1.02] ' + p.color
                    : 'border-slate-800 bg-slate-900/80 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center space-x-2.5 mb-1.5">
                  <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200">
                    <Icon className="h-4 w-4" />
                  </div>
                  <span className="font-display font-bold text-xs text-slate-100 tracking-wide">
                    {p.name}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-tight">
                  {p.desc}
                </p>
                <div className="mt-2 text-[10px] font-mono font-bold">
                  {isActive ? <span className="text-rose-400">● INJECTED (ACTIVE)</span> : <span className="text-slate-500">○ CLICK TO INJECT</span>}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Live Cause & Effect Domino Flow Visualization */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center space-x-2">
            <Layers className="h-5 w-5 text-cyan-400" />
            <h3 className="font-display font-bold text-base text-slate-100">
              REAL-TIME CAUSE-AND-EFFECT CHAIN
            </h3>
          </div>
          <span className="text-[10px] font-mono text-cyan-400 animate-pulse">
            CLOSED LOOP ACTIVE
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs font-mono">
          {/* Step 1 */}
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-500 uppercase">1. Transducer Anomaly</span>
            <div className="my-2">
              <strong className="text-slate-200 block text-xs">
                {telemetry.oilPressure < 35 ? `Oil: ${telemetry.oilPressure} PSI` :
                 telemetry.vibration > 4.5 ? `Vib: ${telemetry.vibration} mm/s` :
                 telemetry.engineTemp > 105 ? `Temp: ${telemetry.engineTemp} °C` : 'Nominal Sensors'}
              </strong>
            </div>
            <span className="text-[10px] text-slate-400">Physical signal altered</span>
          </div>

          {/* Step 2 */}
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-500 uppercase">2. Physics Model Residual</span>
            <div className="my-2">
              <strong className={Math.abs(physics.tempDeviation) > 10 || Math.abs(physics.pressureDeviation) > 10 ? 'text-amber-400' : 'text-emerald-400'}>
                Δ Residual: {physics.pressureDeviation < -5 ? `${physics.pressureDeviation.toFixed(1)} PSI` : `${physics.tempDeviation.toFixed(1)} °C`}
              </strong>
            </div>
            <span className="text-[10px] text-slate-400">Deviation from physics law</span>
          </div>

          {/* Step 3 */}
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-500 uppercase">3. AI Fault Inference</span>
            <div className="my-2">
              <strong className={aiAnalysis.anomalyScore > 40 ? 'text-rose-400 truncate block' : 'text-cyan-400 truncate block'}>
                {aiAnalysis.detectedFault}
              </strong>
            </div>
            <span className="text-[10px] text-slate-400">SHAP: {aiAnalysis.confidence}% Conf</span>
          </div>

          {/* Step 4 */}
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-500 uppercase">4. RUL Degradation</span>
            <div className="my-2">
              <strong className="text-amber-400 text-sm">
                {rul.remainingFlightHours} Flight Hours
              </strong>
            </div>
            <span className="text-[10px] text-slate-400">Weibull hazard updated</span>
          </div>

          {/* Step 5 */}
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
            <span className="text-[10px] text-slate-500 uppercase">5. Decision Protocol</span>
            <div className="my-2">
              <button
                onClick={() => setActiveView('dashboard')}
                className="w-full py-1 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-[10px] transition-colors"
              >
                VIEW MITIGATION →
              </button>
            </div>
            <span className="text-[10px] text-slate-400">Operator informed</span>
          </div>
        </div>
      </div>

      {/* Manual Fine-Tuning Sliders */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 backdrop-blur-md shadow-xl">
        <h3 className="font-display font-bold text-base text-slate-100 pb-3 border-b border-slate-800 mb-4">
          MANUAL TELEMETRY TRANSDUCER OVERRIDE SLIDERS
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 font-mono text-xs">
          {/* Oil Pressure */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="flex justify-between mb-1.5">
              <span className="text-slate-400">Oil Gallery Pressure</span>
              <strong className={telemetry.oilPressure < 35 ? 'text-rose-400' : 'text-cyan-400'}>
                {telemetry.oilPressure} PSI
              </strong>
            </div>
            <input
              type="range"
              min="10"
              max="90"
              step="1"
              value={faultInjection.oilPressureOverride ?? telemetry.oilPressure}
              onChange={e => setFaultOverride('oilPressureOverride', parseFloat(e.target.value))}
              className="w-full accent-cyan-400"
            />
          </div>

          {/* Engine Temperature */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="flex justify-between mb-1.5">
              <span className="text-slate-400">Engine Block Temp</span>
              <strong className={telemetry.engineTemp > 105 ? 'text-rose-400' : 'text-amber-400'}>
                {telemetry.engineTemp} °C
              </strong>
            </div>
            <input
              type="range"
              min="60"
              max="140"
              step="1"
              value={faultInjection.engineTempOverride ?? telemetry.engineTemp}
              onChange={e => setFaultOverride('engineTempOverride', parseFloat(e.target.value))}
              className="w-full accent-amber-400"
            />
          </div>

          {/* Vibration */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="flex justify-between mb-1.5">
              <span className="text-slate-400">Mechanical Vibration</span>
              <strong className={telemetry.vibration > 4.5 ? 'text-rose-400' : 'text-purple-400'}>
                {telemetry.vibration} mm/s
              </strong>
            </div>
            <input
              type="range"
              min="0.5"
              max="10.0"
              step="0.1"
              value={faultInjection.vibrationOverride ?? telemetry.vibration}
              onChange={e => setFaultOverride('vibrationOverride', parseFloat(e.target.value))}
              className="w-full accent-purple-400"
            />
          </div>

          {/* Engine RPM */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="flex justify-between mb-1.5">
              <span className="text-slate-400">Engine RPM</span>
              <strong className="text-emerald-400">{telemetry.rpm} RPM</strong>
            </div>
            <input
              type="range"
              min="2000"
              max="6800"
              step="50"
              value={faultInjection.rpmOverride ?? telemetry.rpm}
              onChange={e => setFaultOverride('rpmOverride', parseInt(e.target.value))}
              className="w-full accent-emerald-400"
            />
          </div>

          {/* Oil Temp */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="flex justify-between mb-1.5">
              <span className="text-slate-400">Oil Sump Temp</span>
              <strong className="text-pink-400">{telemetry.oilTemp} °C</strong>
            </div>
            <input
              type="range"
              min="50"
              max="135"
              step="1"
              value={faultInjection.oilTempOverride ?? telemetry.oilTemp}
              onChange={e => setFaultOverride('oilTempOverride', parseFloat(e.target.value))}
              className="w-full accent-pink-400"
            />
          </div>

          {/* Fuel Flow */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
            <div className="flex justify-between mb-1.5">
              <span className="text-slate-400">Fuel Mass Flow</span>
              <strong className="text-teal-400">{telemetry.fuelFlow} L/h</strong>
            </div>
            <input
              type="range"
              min="1.0"
              max="12.0"
              step="0.1"
              value={faultInjection.fuelFlowOverride ?? telemetry.fuelFlow}
              onChange={e => setFaultOverride('fuelFlowOverride', parseFloat(e.target.value))}
              className="w-full accent-teal-400"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
