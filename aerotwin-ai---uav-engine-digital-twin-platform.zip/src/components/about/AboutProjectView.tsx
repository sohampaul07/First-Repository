/**
 * AEROTWIN AI - About Project & Technical Architecture View
 */

import React from 'react';
import { 
  Info, 
  Cpu, 
  Layers, 
  BrainCircuit, 
  Flame, 
  Droplet, 
  Activity, 
  ShieldCheck, 
  Sparkles,
  BookOpen,
  Code2
} from 'lucide-react';

export const AboutProjectView: React.FC = () => {
  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              ABOUT AEROTWIN AI & SYSTEM ARCHITECTURE
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
              PROJECT OVERVIEW & RESEARCH SPEC
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            AI-Powered Hybrid Digital Twin for UAV Engine Health Monitoring and Predictive Prognostics
          </p>
        </div>
      </div>

      {/* Core Philosophy: Physics + AI Hybrid Digital Twin */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-6 shadow-xl space-y-4">
        <div className="flex items-center space-x-2">
          <BrainCircuit className="h-5 w-5 text-cyan-400" />
          <h3 className="font-display font-bold text-base text-slate-100 uppercase tracking-wide">
            THE HYBRID DIGITAL TWIN ARCHITECTURE
          </h3>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed font-sans">
          AEROTWIN AI fundamentally avoids treating the internal combustion propulsion system as a pure black-box machine learning problem. 
          Instead, it couples a <strong>first-principles Physics Engine</strong> with an <strong>Explainable Machine Learning Classifier (XAI)</strong>.
        </p>

        {/* 3 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center space-x-2 text-cyan-400 font-mono text-xs font-bold">
              <Cpu className="h-4 w-4" />
              <span>1. FIRST-PRINCIPLES PHYSICS</span>
            </div>
            <p className="text-xs text-slate-400 font-sans leading-relaxed">
              Models thermodynamics, convective heat transfer, fluid lubrication dynamics, and unbalance harmonics to compute expected nominal baselines.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center space-x-2 text-purple-400 font-mono text-xs font-bold">
              <Sparkles className="h-4 w-4" />
              <span>2. AI EXPLAINABLE RESIDUALS</span>
            </div>
            <p className="text-xs text-slate-400 font-sans leading-relaxed">
              Calculates Δ residuals between actual sensor streams and physical models, isolating failure modes using SHAP attribution feature weights.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center space-x-2 text-emerald-400 font-mono text-xs font-bold">
              <ShieldCheck className="h-4 w-4" />
              <span>3. PROGNOSTIC DECISION SUPPORT</span>
            </div>
            <p className="text-xs text-slate-400 font-sans leading-relaxed">
              Computes Remaining Useful Life (RUL) with Weibull hazard curves and guides operator tactics (load derating, return to base, or diversion).
            </p>
          </div>
        </div>
      </div>

      {/* UAV-150cc Engine Specifications Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-6 backdrop-blur-md shadow-xl">
        <h3 className="font-display font-bold text-base text-slate-100 mb-4 uppercase">
          UAV-150cc EFI BOXER TWIN SPECIFICATIONS
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 font-mono text-xs">
          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Architecture:</span>
            <strong className="text-slate-200">2-Cyl Boxer Twin</strong>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Displacement:</span>
            <strong className="text-cyan-400">150 cc (9.15 cu in)</strong>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Max Power:</span>
            <strong className="text-amber-400">14.5 HP @ 6,200 RPM</strong>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Fuel Injection:</span>
            <strong className="text-slate-200">Electronic Closed-Loop EFI</strong>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Lubrication:</span>
            <strong className="text-slate-200">Pressure Gear Pump (45-65 PSI)</strong>
          </div>

          <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex justify-between">
            <span className="text-slate-400">Telemetry Bus:</span>
            <strong className="text-emerald-400">CAN Bus @ 100 Hz</strong>
          </div>
        </div>
      </div>
    </div>
  );
};
