/**
 * AEROTWIN AI - Tactical Maintenance & Overhaul Center
 */

import React, { useState } from 'react';
import { 
  Wrench, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Calendar, 
  ShieldCheck, 
  RotateCcw, 
  CheckSquare, 
  Square,
  Sparkles
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';

export const MaintenanceCenterView: React.FC = () => {
  const { componentHealth, resetSimulation } = useSimulation();

  const [checklist, setChecklist] = useState<{ id: string; task: string; done: boolean; comp: string }[]>([
    { id: '1', task: 'Inspect oil filter mesh for ferrous particulate debris', done: false, comp: 'Lubrication' },
    { id: '2', task: 'Borescope cylinder 1 & 2 crown for carbon fouling & pre-ignition pitting', done: false, comp: 'Cylinders' },
    { id: '3', task: 'Verify oil pressure relief valve spring calibration (55 PSI target)', done: false, comp: 'Lubrication' },
    { id: '4', task: 'Torque cylinder head studs to 24 N·m in cross-pattern sequence', done: false, comp: 'Cylinders' },
    { id: '5', task: 'Ultrasonic clean electronic fuel injector nozzle orifices', done: false, comp: 'Fuel' },
    { id: '6', task: 'Perform crankcase leak-down compression test (>92% nominal)', done: false, comp: 'Cylinders' },
    { id: '7', task: 'Check ram-air cooling plenum seal and duct clearances', done: false, comp: 'Cooling' },
    { id: '8', task: 'Verify ignition coil secondary resistance (4.5 kΩ - 5.8 kΩ)', done: false, comp: 'Ignition' },
  ]);

  const [isOverhauling, setIsOverhauling] = useState<boolean>(false);

  const toggleCheck = (id: string) => {
    setChecklist(prev => prev.map(item => item.id === id ? { ...item, done: !item.done } : item));
  };

  const handlePerformFullOverhaul = () => {
    setIsOverhauling(true);
    setTimeout(() => {
      resetSimulation();
      setChecklist(prev => prev.map(item => ({ ...item, done: true })));
      setIsOverhauling(false);
    }, 1200);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              PROPULSION MAINTENANCE & OVERHAUL HUB
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
              INTERACTIVE REPAIR & OVERHAUL
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Component health checklists, work order scheduling, and maintenance reset actions
          </p>
        </div>

        <button
          id="btn-execute-overhaul"
          onClick={handlePerformFullOverhaul}
          disabled={isOverhauling}
          className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-950/40 transition-all shrink-0"
        >
          {isOverhauling ? (
            <>
              <RotateCcw className="h-4 w-4 animate-spin" />
              <span>PERFORMING 100% OVERHAUL...</span>
            </>
          ) : (
            <>
              <Wrench className="h-4 w-4" />
              <span>EXECUTE COMPLETE OVERHAUL & RESET</span>
            </>
          )}
        </button>
      </div>

      {/* Subsystem Maintenance Action Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          componentHealth.lubricationSystem,
          componentHealth.cylinderSystem,
          componentHealth.bearingSystem,
          componentHealth.coolingSystem,
          componentHealth.fuelSystem,
          componentHealth.ignitionSystem,
        ].map((comp) => (
          <div key={comp.id} className="p-4 rounded-2xl border border-slate-800 bg-slate-900/90 backdrop-blur-md flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="font-display font-bold text-sm text-slate-200">{comp.name}</span>
                <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-full border ${
                  comp.maintenancePriority === 'URGENT' ? 'bg-rose-500/30 border-rose-500/50 text-rose-300 font-bold animate-pulse' :
                  comp.maintenancePriority === 'HIGH' ? 'bg-amber-500/20 border-amber-500/40 text-amber-300' :
                  'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                }`}>
                  {comp.maintenancePriority} PRIORITY
                </span>
              </div>

              <div className="my-3 space-y-1 text-xs font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>Current Health:</span>
                  <strong className="text-slate-200">{comp.healthScore}%</strong>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>RUL Window:</span>
                  <span className="text-cyan-400">{comp.estimatedRULHours} hrs</span>
                </div>
              </div>

              <p className="text-xs text-slate-300 font-sans p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                {comp.recommendedAction}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Digital Pre-Flight & Maintenance Inspection Checklist */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="h-5 w-5 text-cyan-400" />
            <h3 className="font-display font-bold text-base text-slate-100">
              DIGITAL PROPULSION OVERHAUL CHECKLIST
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {checklist.filter(c => c.done).length} / {checklist.length} Completed
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-xs">
          {checklist.map((item) => (
            <div
              key={item.id}
              onClick={() => toggleCheck(item.id)}
              className={`p-3 rounded-xl border cursor-pointer flex items-start space-x-3 transition-all ${
                item.done
                  ? 'border-emerald-500/40 bg-emerald-950/20 text-emerald-300'
                  : 'border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700'
              }`}
            >
              {item.done ? (
                <CheckSquare className="h-4 w-4 text-emerald-400 mt-0.5 shrink-0" />
              ) : (
                <Square className="h-4 w-4 text-slate-500 mt-0.5 shrink-0" />
              )}
              <div className="flex-1">
                <span className={item.done ? 'line-through opacity-80' : ''}>{item.task}</span>
                <span className="block text-[10px] text-slate-500 mt-0.5 uppercase">Node: {item.comp}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
