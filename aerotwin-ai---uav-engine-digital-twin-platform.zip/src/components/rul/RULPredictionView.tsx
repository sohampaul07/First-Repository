/**
 * AEROTWIN AI - Remaining Useful Life (RUL) Prognostics View
 */

import React, { useState } from 'react';
import { 
  Hourglass, 
  TrendingDown, 
  Clock, 
  FastForward, 
  ShieldAlert, 
  Cpu, 
  BarChart3,
  Calendar,
  Layers,
  ArrowRight
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';

export const RULPredictionView: React.FC = () => {
  const { 
    rul, 
    componentHealth, 
    simulationSpeed, 
    setSimulationSpeed, 
    setActiveView 
  } = useSimulation();

  const [forecastHorizon, setForecastHorizon] = useState<number>(50);

  // SVG Degradation Curve & Weibull Bounds
  const renderDegradationCurve = () => {
    const width = 760;
    const height = 260;
    const padding = { top: 25, right: 30, bottom: 35, left: 50 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    const pointsCount = 40;
    const currentHealth = componentHealth.overallScore;
    const rulHours = rul.remainingFlightHours;

    // Generate Weibull degradation trajectory
    const trajectory: { h: number; nominal: number; upper: number; lower: number }[] = [];
    for (let i = 0; i <= pointsCount; i++) {
      const flightHours = (i / pointsCount) * forecastHorizon;
      const beta = 2.4; // Weibull shape parameter
      const eta = Math.max(10, rulHours * 1.3); // characteristic life
      const healthDecay = Math.exp(-Math.pow(flightHours / eta, beta));
      const nominalHealth = Math.max(0, currentHealth * healthDecay);
      
      const upper = Math.min(100, nominalHealth + (flightHours / forecastHorizon) * 8);
      const lower = Math.max(0, nominalHealth - (flightHours / forecastHorizon) * 12);

      trajectory.push({ h: flightHours, nominal: nominalHealth, upper, lower });
    }

    const nominalPoints = trajectory.map(t => {
      const x = padding.left + (t.h / forecastHorizon) * chartW;
      const y = padding.top + chartH - (t.nominal / 100) * chartH;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');

    const upperPoints = trajectory.map(t => {
      const x = padding.left + (t.h / forecastHorizon) * chartW;
      const y = padding.top + chartH - (t.upper / 100) * chartH;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });

    const lowerPointsReversed = [...trajectory].reverse().map(t => {
      const x = padding.left + (t.h / forecastHorizon) * chartW;
      const y = padding.top + chartH - (t.lower / 100) * chartH;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });

    const ciPolygonPoints = [...upperPoints, ...lowerPointsReversed].join(' ');

    // Threshold Line at 40% (Maintenance Required)
    const threshY = padding.top + chartH - (40 / 100) * chartH;

    return (
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible select-none">
        <defs>
          <linearGradient id="rulLineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#06b6d4" />
            <stop offset="60%" stopColor="#f59e0b" />
            <stop offset="100%" stopColor="#f43f5e" />
          </linearGradient>
        </defs>

        {/* Grid lines */}
        {[0, 25, 50, 75, 100].map((score) => {
          const y = padding.top + chartH - (score / 100) * chartH;
          return (
            <g key={score}>
              <line
                x1={padding.left}
                y1={y}
                x2={padding.left + chartW}
                y2={y}
                stroke="#1e293b"
                strokeDasharray="4 4"
              />
              <text x={padding.left - 8} y={y + 3} fill="#64748b" fontSize="10" fontFamily="monospace" textAnchor="end">
                {score}%
              </text>
            </g>
          );
        })}

        {/* Horizontal Hour Labels */}
        {[0, 10, 20, 30, 40, 50].map((hr) => {
          const x = padding.left + (hr / forecastHorizon) * chartW;
          return (
            <text key={hr} x={x} y={padding.top + chartH + 18} fill="#64748b" fontSize="10" fontFamily="monospace" textAnchor="middle">
              +{hr}h
            </text>
          );
        })}

        {/* 95% Confidence Interval Band */}
        <polygon points={ciPolygonPoints} fill="#38bdf8" opacity="0.12" />

        {/* Critical Maintenance Limit Threshold */}
        <line
          x1={padding.left}
          y1={threshY}
          x2={padding.left + chartW}
          y2={threshY}
          stroke="#f43f5e"
          strokeDasharray="6 3"
          strokeWidth="1.5"
          opacity="0.8"
        />
        <text x={padding.left + chartW - 5} y={threshY - 4} fill="#f43f5e" fontSize="9" fontFamily="monospace" textAnchor="end">
          Critical Replacement Threshold (40% Health)
        </text>

        {/* Nominal Degradation Line */}
        <polyline
          points={nominalPoints}
          fill="none"
          stroke="url(#rulLineGrad)"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {/* Current State Marker */}
        <circle
          cx={padding.left}
          cy={padding.top + chartH - (currentHealth / 100) * chartH}
          r="5"
          fill="#06b6d4"
          stroke="#0f172a"
          strokeWidth="2"
        />
      </svg>
    );
  };

  const componentRULs = [
    { name: 'Lubrication Pump & Bearings', rul: componentHealth.lubricationSystem.estimatedRULHours, status: componentHealth.lubricationSystem.status, rate: componentHealth.lubricationSystem.degradationRate },
    { name: 'Cylinder Block & Rings', rul: componentHealth.cylinderSystem.estimatedRULHours, status: componentHealth.cylinderSystem.status, rate: componentHealth.cylinderSystem.degradationRate },
    { name: 'Main Journal Bearings', rul: componentHealth.bearingSystem.estimatedRULHours, status: componentHealth.bearingSystem.status, rate: componentHealth.bearingSystem.degradationRate },
    { name: 'Cooling Fin Aero-Ducts', rul: componentHealth.coolingSystem.estimatedRULHours, status: componentHealth.coolingSystem.status, rate: componentHealth.coolingSystem.degradationRate },
    { name: 'EFI Fuel Injector Nozzles', rul: componentHealth.fuelSystem.estimatedRULHours, status: componentHealth.fuelSystem.status, rate: componentHealth.fuelSystem.degradationRate },
    { name: 'Ignition Coils & Plugs', rul: componentHealth.ignitionSystem.estimatedRULHours, status: componentHealth.ignitionSystem.status, rate: componentHealth.ignitionSystem.degradationRate },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-amber-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              REMAINING USEFUL LIFE (RUL) PROGNOSTICS
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 border border-amber-500/40 text-amber-300">
              WEIBULL HAZARD REGRESSION
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Statistical survival models predicting time-to-replacement and operational limits
          </p>
        </div>

        {/* Accelerated Time Controls */}
        <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl p-1 text-xs font-mono">
          <span className="px-2 text-slate-500 text-[10px] flex items-center gap-1">
            <FastForward className="h-3 w-3" />
            WARP SPEED:
          </span>
          {[1, 5, 10, 50].map((speed) => (
            <button
              key={speed}
              onClick={() => setSimulationSpeed(speed)}
              className={`px-2.5 py-1 rounded-lg ${
                simulationSpeed === speed ? 'bg-amber-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {speed}x
            </button>
          ))}
        </div>
      </div>

      {/* Main KPI Countdown Box */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 backdrop-blur-md">
          <span className="text-[10px] font-mono uppercase text-slate-400">Total System RUL</span>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="font-display text-4xl font-bold text-amber-400">
              {rul.remainingFlightHours}
            </span>
            <span className="text-sm font-mono text-slate-400">Flight Hours</span>
          </div>
          <div className="text-[11px] font-mono text-slate-400 mt-2">
            95% Range: <strong className="text-slate-200">{rul.confidenceRangeMin}h - {rul.confidenceRangeMax}h</strong>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 backdrop-blur-md">
          <span className="text-[10px] font-mono uppercase text-slate-400">Predicted Failure Limiter</span>
          <div className="font-display text-lg font-bold text-slate-100 mt-1 truncate">
            {rul.predictedFailureMode}
          </div>
          <div className="text-[11px] font-mono text-slate-400 mt-2">
            Degradation Rate: <strong className="text-amber-400">{rul.currentDegradationRate}% / hr</strong>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 backdrop-blur-md">
          <span className="text-[10px] font-mono uppercase text-slate-400">Maintenance Window</span>
          <div className="font-display text-lg font-bold text-cyan-400 mt-1">
            {rul.estimatedDaysToMaintenance} Flight Cycles
          </div>
          <div className="text-[11px] font-mono text-slate-400 mt-2">
            Status: <span className="text-emerald-400 font-bold uppercase">{componentHealth.status}</span>
          </div>
        </div>
      </div>

      {/* Degradation Trajectory Chart */}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-5 shadow-xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div>
            <h3 className="font-display font-bold text-base text-slate-100">
              DEGRADATION TRAJECTORY & WEIBULL PROGNOSTIC CURVE
            </h3>
            <span className="text-xs font-mono text-slate-400">
              Projected Health Index vs. Additional Flight Hours with 95% Confidence Bounds
            </span>
          </div>

          <div className="flex items-center space-x-2 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-slate-400">
              <span className="h-2 w-4 bg-cyan-500/30 border border-cyan-400 inline-block rounded" />
              95% Confidence Interval
            </span>
          </div>
        </div>

        {/* SVG Curve */}
        <div className="w-full overflow-x-auto">
          {renderDegradationCurve()}
        </div>
      </div>

      {/* Component RUL Breakdown Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 backdrop-blur-md">
        <h3 className="font-display font-bold text-base text-slate-100 mb-3">
          SUBSYSTEM REMAINING USEFUL LIFE MATRIX
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 font-mono text-xs">
          {componentRULs.map((c, i) => (
            <div key={i} className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-semibold text-slate-200 block truncate">{c.name}</span>
                <span className="text-[10px] text-slate-400">Decay: {c.rate}%/hr</span>
              </div>
              <div className="text-right">
                <span className="font-display text-base font-bold text-cyan-400 block">{c.rul}h</span>
                <span className={`text-[9px] uppercase px-1.5 py-0.2 rounded ${
                  c.status === 'critical' ? 'bg-rose-500/20 text-rose-300' :
                  c.status === 'warning' ? 'bg-amber-500/20 text-amber-300' :
                  'bg-emerald-500/10 text-emerald-300'
                }`}>
                  {c.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
