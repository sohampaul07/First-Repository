/**
 * AEROTWIN AI - Component-Level Engine Health Hierarchy View
 */

import React from 'react';
import { 
  HeartPulse, 
  Cpu, 
  Layers, 
  Wrench, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Activity,
  ArrowRight
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { ComponentHealth } from '../../types';

export const EngineHealthView: React.FC = () => {
  const { componentHealth, setActiveView } = useSimulation();

  const components: ComponentHealth[] = [
    componentHealth.cylinderSystem,
    componentHealth.bearingSystem,
    componentHealth.lubricationSystem,
    componentHealth.coolingSystem,
    componentHealth.fuelSystem,
    componentHealth.ignitionSystem,
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Overview Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              COMPONENT-LEVEL DIGITAL TWIN HEALTH MATRIX
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
              6 CORE SUBSYSTEMS
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Hierarchical multi-subsystem degradation monitoring and remaining useful life tracking
          </p>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center space-x-2">
            <span className="text-slate-400">Total Propulsion Health:</span>
            <strong className={`font-display text-base ${
              componentHealth.overallScore > 85 ? 'text-emerald-400' :
              componentHealth.overallScore > 65 ? 'text-amber-400' : 'text-rose-400'
            }`}>
              {componentHealth.overallScore}%
            </strong>
          </div>
        </div>
      </div>

      {/* Subsystem Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {components.map((comp) => {
          const isCritical = comp.status === 'critical';
          const isWarning = comp.status === 'warning';
          const isMonitor = comp.status === 'monitor';

          const cardBorder = isCritical ? 'border-rose-500/60 bg-rose-950/20' :
                             isWarning ? 'border-amber-500/50 bg-amber-950/15' :
                             isMonitor ? 'border-cyan-500/40 bg-slate-900/90' :
                             'border-slate-800 bg-slate-900/80';

          return (
            <div
              key={comp.id}
              className={`rounded-2xl border ${cardBorder} p-5 backdrop-blur-md shadow-lg flex flex-col justify-between transition-all`}
            >
              <div>
                {/* Header & Status */}
                <div className="flex items-start justify-between pb-3 border-b border-slate-800/80">
                  <div>
                    <span className="text-[10px] font-mono uppercase text-slate-500">{comp.category} subsystem</span>
                    <h3 className="font-display font-bold text-base text-slate-100">{comp.name}</h3>
                  </div>
                  <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-full border ${
                    isCritical ? 'bg-rose-500/30 border-rose-500/50 text-rose-300 font-bold animate-pulse' :
                    isWarning ? 'bg-amber-500/20 border-amber-500/40 text-amber-300' :
                    isMonitor ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300' :
                    'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  }`}>
                    {comp.status}
                  </span>
                </div>

                {/* Main Health Meter */}
                <div className="my-4">
                  <div className="flex items-baseline justify-between font-mono mb-1.5">
                    <span className="text-xs text-slate-400">Health Index</span>
                    <span className="font-display text-2xl font-bold text-slate-100">
                      {comp.healthScore}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${
                        comp.healthScore > 80 ? 'bg-emerald-400' :
                        comp.healthScore > 55 ? 'bg-amber-400' : 'bg-rose-500'
                      }`}
                      style={{ width: `${comp.healthScore}%` }}
                    />
                  </div>
                </div>

                {/* Metrics & Physics Expected */}
                <div className="space-y-1.5 text-xs font-mono bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 mb-4">
                  <div className="flex justify-between text-slate-300">
                    <span className="text-slate-400">{comp.currentMetricLabel}:</span>
                    <strong className="text-cyan-300">{comp.currentMetricValue}</strong>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Physics Normal:</span>
                    <span>{comp.expectedMetricValue}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Degradation Rate:</span>
                    <span className={comp.degradationRate > 2.0 ? 'text-rose-400 font-bold' : 'text-slate-300'}>
                      {comp.degradationRate}% / hr
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Subsystem RUL:</span>
                    <strong className="text-amber-400">{comp.estimatedRULHours} Flight Hours</strong>
                  </div>
                </div>

                {/* Subcomponents List */}
                {comp.subcomponents && comp.subcomponents.length > 0 && (
                  <div className="space-y-1.5 mb-4">
                    <span className="text-[10px] font-mono uppercase text-slate-500 block">Sub-Assembly Nodes:</span>
                    {comp.subcomponents.map((sub, idx) => (
                      <div key={idx} className="flex items-center justify-between text-xs font-mono px-2 py-1 rounded bg-slate-950/40 border border-slate-800/60">
                        <span className="text-slate-300 truncate">{sub.name}</span>
                        <span className="text-cyan-400 font-semibold">{sub.health}%</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Maintenance Recommendation */}
              <div className="pt-3 border-t border-slate-800/80 text-xs font-sans text-slate-300">
                <div className="flex items-center justify-between mb-1 text-[10px] font-mono uppercase text-slate-400">
                  <span>Maintenance Priority:</span>
                  <strong className={
                    comp.maintenancePriority === 'URGENT' ? 'text-rose-400 font-bold' :
                    comp.maintenancePriority === 'HIGH' ? 'text-amber-400' : 'text-slate-300'
                  }>
                    {comp.maintenancePriority}
                  </strong>
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-2">
                  {comp.recommendedAction}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
