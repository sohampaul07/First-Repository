/**
 * AEROTWIN AI - Tactical Mission Planner & Feasibility Engine
 */

import React, { useState } from 'react';
import { 
  Crosshair, 
  CheckCircle2, 
  AlertTriangle, 
  Play, 
  Compass, 
  ShieldCheck, 
  Wind, 
  Thermometer, 
  Gauge, 
  Clock,
  Sparkles,
  Rocket
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';

export const MissionPlannerView: React.FC = () => {
  const { componentHealth, rul, launchMissionFromPlanner, setActiveView } = useSimulation();

  const [missionName, setMissionName] = useState<string>('Tactical Perimeter ISR-402');
  const [missionType, setMissionType] = useState<string>('Border Surveillance');
  const [targetDurationHours, setTargetDurationHours] = useState<number>(4.5);
  const [altitude, setAltitude] = useState<number>(8500);
  const [weatherCondition, setWeatherCondition] = useState<string>('Hot High Desert (+38°C)');
  const [isLaunched, setIsLaunched] = useState<boolean>(false);

  // AI Feasibility Calculation
  const healthAdequate = componentHealth.overallScore > 75;
  const rulAdequate = rul.remainingFlightHours >= targetDurationHours * 1.5;
  const isGo = healthAdequate && rulAdequate;

  const handleLaunch = () => {
    launchMissionFromPlanner({
      name: missionName,
      type: 'Perimeter Patrol',
      distanceKm: Math.round(targetDurationHours * 115 * 1.852),
      targetAltitudeFt: altitude,
      expectedDurationHours: targetDurationHours,
      payloadWeightKg: 12.5,
      cruiseSpeedKnots: 115,
      environmentalConditions: 'High Ambient Heat',
    });
    setIsLaunched(true);
    setTimeout(() => {
      setActiveView('dashboard');
    }, 1200);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              MISSION PLANNER & FEASIBILITY ASSESSMENT
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-300">
              PROPULSION GO / NO-GO ENGINE
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Configure UAV mission parameters and validate feasibility against Digital Twin health reserves
          </p>
        </div>

        {/* Go / No-Go Pill */}
        <div className={`px-4 py-2 rounded-xl border flex items-center space-x-2 text-xs font-mono font-bold ${
          isGo ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-rose-500/20 border-rose-500/40 text-rose-300 animate-pulse'
        }`}>
          {isGo ? <ShieldCheck className="h-4 w-4 text-emerald-400" /> : <AlertTriangle className="h-4 w-4 text-rose-400" />}
          <span>PROPULSION STATUS: {isGo ? 'MISSION GO' : 'NO-GO / RISK DETECTED'}</span>
        </div>
      </div>

      {/* Main 2-Column: Planner Form + AI Assessment */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Configuration Form */}
        <div className="lg:col-span-7 rounded-2xl border border-slate-800 bg-slate-900/90 p-5 backdrop-blur-md shadow-xl space-y-4">
          <h3 className="font-display font-bold text-base text-slate-100 pb-3 border-b border-slate-800">
            FLIGHT PROFILE PARAMETERS
          </h3>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <label className="text-slate-400 uppercase text-[10px] block mb-1">Mission Identifier / Name:</label>
              <input
                type="text"
                value={missionName}
                onChange={e => setMissionName(e.target.value)}
                className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2.5 text-slate-100 focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 uppercase text-[10px] block mb-1">Mission Profile Type:</label>
                <select
                  value={missionType}
                  onChange={e => setMissionType(e.target.value)}
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2.5 text-slate-100 focus:border-cyan-500 focus:outline-none"
                >
                  <option>Border Surveillance</option>
                  <option>Maritime Reconnaissance</option>
                  <option>High-Altitude ISR</option>
                  <option>Tactical Convoy Escort</option>
                  <option>Disaster Search & Rescue</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 uppercase text-[10px] block mb-1">Ambient Weather Profile:</label>
                <select
                  value={weatherCondition}
                  onChange={e => setWeatherCondition(e.target.value)}
                  className="w-full rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2.5 text-slate-100 focus:border-cyan-500 focus:outline-none"
                >
                  <option>Hot High Desert (+38°C)</option>
                  <option>ISA Standard Atmosphere (+15°C)</option>
                  <option>Sub-Zero Cold Weather (-18°C)</option>
                  <option>Tropical Maritime (95% Humidity)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 uppercase text-[10px] block mb-1">
                  Target Duration: <strong className="text-cyan-400">{targetDurationHours} Hours</strong>
                </label>
                <input
                  type="range"
                  min="1"
                  max="12"
                  step="0.5"
                  value={targetDurationHours}
                  onChange={e => setTargetDurationHours(parseFloat(e.target.value))}
                  className="w-full accent-cyan-400"
                />
              </div>

              <div>
                <label className="text-slate-400 uppercase text-[10px] block mb-1">
                  Cruise Altitude: <strong className="text-cyan-400">{altitude} FT</strong>
                </label>
                <input
                  type="range"
                  min="2000"
                  max="16000"
                  step="500"
                  value={altitude}
                  onChange={e => setAltitude(parseInt(e.target.value))}
                  className="w-full accent-cyan-400"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex justify-end">
            <button
              id="btn-launch-mission-planner"
              onClick={handleLaunch}
              disabled={isLaunched}
              className="flex items-center space-x-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/25 transition-all"
            >
              <Rocket className="h-4 w-4" />
              <span>{isLaunched ? 'INITIALIZING MISSION...' : 'CONFIRM & LAUNCH MISSION'}</span>
            </button>
          </div>
        </div>

        {/* Right: AI Feasibility Checklist */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-800 bg-slate-900/90 p-5 backdrop-blur-md shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 pb-3 border-b border-slate-800 mb-4">
              <Sparkles className="h-5 w-5 text-cyan-400" />
              <h3 className="font-display font-bold text-base text-slate-100">
                AI FEASIBILITY ASSESSMENT
              </h3>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">Engine Health Reserve:</span>
                <span className={healthAdequate ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {componentHealth.overallScore}% ({healthAdequate ? 'SUFFICIENT' : 'MARGINAL'})
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">RUL vs Required:</span>
                <span className={rulAdequate ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {rul.remainingFlightHours}h / {targetDurationHours}h Required
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">Estimated Fuel Burn:</span>
                <span className="text-cyan-300 font-bold">
                  {(targetDurationHours * 5.4).toFixed(1)} Liters (68% Tank Cap)
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between">
                <span className="text-slate-400">Thermal Overheat Risk:</span>
                <span className="text-emerald-400 font-bold">LOW (12% Probability)</span>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-xs text-slate-300">
            <strong className="text-cyan-400 block mb-0.5 font-mono text-[10px] uppercase">AI Flight Recommendation:</strong>
            Engine health satisfies safety safety factor requirements (1.5x RUL headroom). Cleared for takeoff.
          </div>
        </div>
      </div>
    </div>
  );
};
