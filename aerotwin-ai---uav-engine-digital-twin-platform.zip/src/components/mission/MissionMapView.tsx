/**
 * AEROTWIN AI - Tactical UAV Mission Map & Navigation View
 */

import React, { useState } from 'react';
import { 
  Map, 
  Compass, 
  Plane, 
  MapPin, 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowLeftRight, 
  PlaneLanding, 
  Radio, 
  Navigation,
  Wind,
  Gauge
} from 'lucide-react';
import { useSimulation } from '../../context/SimulationContext';
import { DecisionModal } from '../common/DecisionModal';

export const MissionMapView: React.FC = () => {
  const { missionState, componentHealth, aiAnalysis, executeOperatorAction } = useSimulation();
  const [selectedEmergencySite, setSelectedEmergencySite] = useState<string | null>(null);
  const [isDecisionOpen, setIsDecisionOpen] = useState<boolean>(false);

  const emergencyAirfields = [
    { id: 'ea-1', name: 'Forward Recovery Strip Alpha (FARP-A)', dist: '18 km', runway: '800m Paved', coords: '34.88°N, 117.92°W' },
    { id: 'ea-2', name: 'Tactical Outpost Bravo Heli-Pad', dist: '29 km', runway: '450m Compact Dirt', coords: '34.95°N, 117.75°W' },
    { id: 'ea-3', name: 'Desert Dry Lake Bed Alternate', dist: '42 km', runway: '2,400m Natural Salt', coords: '35.08°N, 117.82°W' },
  ];

  // SVG Tactical Flight Route Map
  const renderTacticalMap = () => {
    const width = 760;
    const height = 400;

    // Waypoint Coordinates on 2D tactical grid
    const waypoints = [
      { x: 90, y: 320, label: 'WP-0: AIRBASE BASE', num: 0 },
      { x: 190, y: 220, label: 'WP-1: ASCENT CORRIDOR', num: 1 },
      { x: 340, y: 140, label: 'WP-2: CRUISE RIDGE', num: 2 },
      { x: 490, y: 160, label: 'WP-3: RECONNAISSANCE PATROL', num: 3 },
      { x: 640, y: 280, label: 'WP-4: EXTRACTION POINT', num: 4 },
    ];

    // Current UAV Position interpolated along waypoint path
    const uavProgress = missionState.progressPercentage / 100;
    const totalSegments = waypoints.length - 1;
    const currentSegmentIndex = Math.min(
      Math.floor(uavProgress * totalSegments),
      totalSegments - 1
    );
    const segmentFrac = (uavProgress * totalSegments) - currentSegmentIndex;

    const p1 = waypoints[currentSegmentIndex];
    const p2 = waypoints[currentSegmentIndex + 1];
    const uavX = p1.x + (p2.x - p1.x) * segmentFrac;
    const uavY = p1.y + (p2.y - p1.y) * segmentFrac;

    // Path string
    const pathString = waypoints.map((w, idx) => (idx === 0 ? `M ${w.x} ${w.y}` : `L ${w.x} ${w.y}`)).join(' ');

    return (
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto select-none bg-slate-950 rounded-2xl border border-slate-800">
        <defs>
          {/* Radar Scan Gradient */}
          <radialGradient id="radarGrad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.2" />
            <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
          </radialGradient>
          <filter id="uavGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Tactical Grid Lines */}
        {[80, 160, 240, 320].map((y) => (
          <line key={`gy-${y}`} x1="40" y1={y} x2={width - 40} y2={y} stroke="#1e293b" strokeDasharray="3 3" />
        ))}
        {[100, 200, 300, 400, 500, 600, 700].map((x) => (
          <line key={`gx-${x}`} x1={x} y1="40" x2={x} y2={height - 40} stroke="#1e293b" strokeDasharray="3 3" />
        ))}

        {/* Range Rings from Base */}
        <circle cx={waypoints[0].x} cy={waypoints[0].y} r="120" fill="none" stroke="#06b6d4" strokeDasharray="4 4" opacity="0.2" />
        <circle cx={waypoints[0].x} cy={waypoints[0].y} r="240" fill="none" stroke="#06b6d4" strokeDasharray="4 4" opacity="0.15" />
        <text x={waypoints[0].x + 125} y={waypoints[0].y} fill="#06b6d4" fontSize="9" fontFamily="monospace" opacity="0.6">50 KM</text>
        <text x={waypoints[0].x + 245} y={waypoints[0].y} fill="#06b6d4" fontSize="9" fontFamily="monospace" opacity="0.6">100 KM</text>

        {/* Flight Path Polyline */}
        <path d={pathString} fill="none" stroke="#334155" strokeWidth="4" strokeLinecap="round" />
        <path d={pathString} fill="none" stroke="#06b6d4" strokeWidth="2" strokeDasharray="8 4" strokeLinecap="round" />

        {/* Direct RTB Vector line from UAV to Base */}
        <line
          x1={uavX}
          y1={uavY}
          x2={waypoints[0].x}
          y2={waypoints[0].y}
          stroke={missionState.returnToBaseRisk === 'HIGH' || missionState.returnToBaseRisk === 'CRITICAL' ? '#f43f5e' : '#38bdf8'}
          strokeWidth="1.5"
          strokeDasharray="4 4"
          opacity="0.8"
        />

        {/* Waypoint Nodes */}
        {waypoints.map((w) => {
          const isPassed = missionState.currentWaypointIndex >= w.num;
          return (
            <g key={w.num} transform={`translate(${w.x}, ${w.y})`}>
              <circle
                cx="0"
                cy="0"
                r="7"
                fill={isPassed ? '#06b6d4' : '#1e293b'}
                stroke="#38bdf8"
                strokeWidth="2"
              />
              <text x="0" y="-12" fill="#94a3b8" fontSize="9" fontFamily="monospace" textAnchor="middle" fontWeight="bold">
                {w.label}
              </text>
            </g>
          );
        })}

        {/* Emergency Airfields Points */}
        <g transform="translate(380, 290)" className="cursor-pointer" onClick={() => setSelectedEmergencySite('ea-1')}>
          <polygon points="0,-8 7,6 -7,6" fill="#f59e0b" stroke="#0f172a" strokeWidth="1" />
          <text x="0" y="18" fill="#f59e0b" fontSize="8" fontFamily="monospace" textAnchor="middle">FARP-ALPHA (18km)</text>
        </g>
        <g transform="translate(560, 110)" className="cursor-pointer" onClick={() => setSelectedEmergencySite('ea-2')}>
          <polygon points="0,-8 7,6 -7,6" fill="#f59e0b" stroke="#0f172a" strokeWidth="1" />
          <text x="0" y="18" fill="#f59e0b" fontSize="8" fontFamily="monospace" textAnchor="middle">OUTPOST-BRAVO (29km)</text>
        </g>

        {/* UAV Tactical Icon & Pulse */}
        <g transform={`translate(${uavX}, ${uavY})`} filter="url(#uavGlow)">
          <circle cx="0" cy="0" r="16" fill="none" stroke="#38bdf8" strokeWidth="1.5" className="animate-ping" />
          <circle cx="0" cy="0" r="10" fill="#0284c7" stroke="#38bdf8" strokeWidth="2" />
          <polygon points="0,-6 5,5 -5,5" fill="#ffffff" />
          <text x="0" y="24" fill="#38bdf8" fontSize="10" fontFamily="monospace" textAnchor="middle" fontWeight="bold">
            UAV-150 ({missionState.groundSpeedKnots} kts)
          </text>
        </g>
      </svg>
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl border border-slate-800 bg-slate-900/80 backdrop-blur-md">
        <div>
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-blue-400 animate-ping" />
            <h2 className="font-display font-bold text-lg text-slate-100">
              TACTICAL MISSION MAP & PROPULSION ENVELOPE
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-950 border border-blue-500/40 text-blue-300">
              LIVE POSITIONING & RECOVERY
            </span>
          </div>
          <p className="text-xs font-mono text-slate-400 mt-0.5">
            Real-time geospatial trajectory tracking, RTB risk modeling, and emergency diversions
          </p>
        </div>

        {/* RTB Risk Pill */}
        <div className={`px-4 py-2 rounded-xl border flex items-center space-x-2 text-xs font-mono font-bold ${
          missionState.returnToBaseRisk === 'LOW' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' :
          missionState.returnToBaseRisk === 'MEDIUM' ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300' :
          missionState.returnToBaseRisk === 'HIGH' ? 'bg-amber-500/20 border-amber-500/40 text-amber-300' :
          'bg-rose-500/30 border-rose-500/50 text-rose-300 animate-pulse'
        }`}>
          <ShieldAlert className="h-4 w-4" />
          <span>RETURN-TO-BASE RISK: {missionState.returnToBaseRisk}</span>
        </div>
      </div>

      {/* Flight Telemetry Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs">
        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center space-x-3">
          <Gauge className="h-5 w-5 text-cyan-400" />
          <div>
            <span className="text-[10px] text-slate-400 uppercase">Altitude</span>
            <div className="font-bold text-slate-100 text-sm">{missionState.altitudeFt} FT MSL</div>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center space-x-3">
          <Wind className="h-5 w-5 text-cyan-400" />
          <div>
            <span className="text-[10px] text-slate-400 uppercase">Ground Speed</span>
            <div className="font-bold text-slate-100 text-sm">{missionState.groundSpeedKnots} KNOTS</div>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center space-x-3">
          <Navigation className="h-5 w-5 text-cyan-400" />
          <div>
            <span className="text-[10px] text-slate-400 uppercase">Heading</span>
            <div className="font-bold text-slate-100 text-sm">{missionState.headingDeg ?? 142}° TRUE</div>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center space-x-3">
          <Compass className="h-5 w-5 text-cyan-400" />
          <div>
            <span className="text-[10px] text-slate-400 uppercase">Distance to Base</span>
            <div className="font-bold text-slate-100 text-sm">{missionState.distanceToBaseKm} KM</div>
          </div>
        </div>
      </div>

      {/* Interactive Map Component */}
      <div className="relative">
        {renderTacticalMap()}
      </div>

      {/* Emergency Diversions & Tactical Decision Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {emergencyAirfields.map((ea) => (
          <div
            key={ea.id}
            onClick={() => setSelectedEmergencySite(ea.id)}
            className={`p-4 rounded-2xl border cursor-pointer transition-all ${
              selectedEmergencySite === ea.id
                ? 'border-amber-500 bg-amber-950/20 text-amber-300 ring-2 ring-amber-400'
                : 'border-slate-800 bg-slate-900/80 text-slate-300 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center space-x-2 mb-1">
              <PlaneLanding className="h-4 w-4 text-amber-400" />
              <h4 className="font-display font-bold text-xs">{ea.name}</h4>
            </div>
            <div className="text-[11px] font-mono text-slate-400 space-y-0.5 mt-2">
              <div>Distance: <strong className="text-slate-200">{ea.dist}</strong></div>
              <div>Runway: {ea.runway}</div>
              <div>GPS: {ea.coords}</div>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsDecisionOpen(true);
              }}
              className="mt-3 w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] font-mono text-cyan-300 font-bold transition-colors"
            >
              Divert to Airfield →
            </button>
          </div>
        ))}
      </div>

      <DecisionModal
        isOpen={isDecisionOpen}
        onClose={() => setIsDecisionOpen(false)}
        defaultAction="RETURN_TO_BASE"
      />
    </div>
  );
};
